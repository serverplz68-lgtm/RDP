const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Set your AFK status')
    .addStringOption(o => o.setName('reason').setDescription('AFK reason').setRequired(false)),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const reason = interaction.options.getString('reason') || 'AFK';
    const guildId = interaction.guildId;
    const userId = interaction.user.id;

    await prisma.aFKUser.upsert({
      where: { guildId_userId: { guildId, userId } },
      update: { reason, setAt: new Date() },
      create: { guildId, userId, reason },
    });

    // Update cache
    const cache = client.configCache.get(guildId);
    if (cache) {
      if (!cache.afkUsers) cache.afkUsers = new Map();
      cache.afkUsers.set(userId, { reason, setAt: new Date() });
      client.configCache.set(guildId, cache);
    }

    await interaction.editReply({ embeds: [successEmbed('AFK Set', `You are now AFK: **${reason}**`)] });
  },
};
