const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');

const router = express.Router();
const prisma = new PrismaClient();
const GUILD_ID = process.env.DISCORD_GUILD_ID;

router.use(isAuthenticated, isAdmin);

router.get('/config', async (req, res) => {
  try {
    const config = await prisma.securityConfig.findUnique({ where: { guildId: GUILD_ID } });
    res.json(config || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/config', [
  body('antiNukeEnabled').optional().isBoolean(),
  body('antiNukeThreshold').optional().isInt({ min: 1, max: 20 }),
  body('antiNukeAction').optional().isIn(['ban', 'kick', 'strip_roles']),
  body('autoRevertEnabled').optional().isBoolean(),
  body('antiSpamEnabled').optional().isBoolean(),
  body('spamThreshold').optional().isInt({ min: 2, max: 20 }),
  body('spamInterval').optional().isInt({ min: 1000, max: 60000 }),
  body('spamAction').optional().isIn(['delete', 'timeout', 'kick', 'ban']),
  body('badWordsEnabled').optional().isBoolean(),
  body('badWordsList').optional().isArray(),
  body('badWordsAction').optional().isIn(['delete', 'timeout', 'warn']),
  body('whitelistedUsers').optional().isArray(),
  body('whitelistedRoles').optional().isArray(),
  body('logChannelId').optional().isString(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const config = await prisma.securityConfig.upsert({
      where: { guildId: GUILD_ID },
      update: req.body,
      create: { guildId: GUILD_ID, ...req.body },
    });

    // Push update to bot via Socket.io
    if (global.botSocket) {
      global.botSocket.emit('config:security:update', { guildId: GUILD_ID, config });
    }
    global.io?.emit('config:security:update', { guildId: GUILD_ID, config });

    res.json(config);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
