const express = require('express');
const axios = require('axios');
const { PrismaClient } = require('@prisma/client');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');
const { getPerfBuffer, getActivityLog } = require('../socket/handlers');

const router = express.Router();
const prisma = new PrismaClient();

router.use(isAuthenticated, isAdmin);

// ─── Bot Stats ────────────────────────────────────────────────────────────
router.get('/stats', async (req, res) => {
  try {
    const guildId = process.env.DISCORD_GUILD_ID;

    const guildRes = await axios.get(
      `https://discord.com/api/v10/guilds/${guildId}?with_counts=true`,
      { headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` } }
    ).catch(() => null);

    const guild = guildRes?.data;
    const perf = getPerfBuffer();
    const latest = perf[perf.length - 1];

    res.json({
      ping: latest?.ping ?? -1,
      status: latest ? (latest.ping < 100 ? 'online' : latest.ping < 300 ? 'idle' : 'dnd') : 'offline',
      uptime: latest?.uptime ?? 0,
      guildName: guild?.name ?? 'Unknown',
      guildIcon: guild?.icon ?? null,
      memberCount: guild?.approximate_member_count ?? 0,
      owner: guild?.owner_id ?? null,
      botConnected: !!global.botSocket,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Performance Data ──────────────────────────────────────────────────────
router.get('/performance', (req, res) => {
  res.json(getPerfBuffer());
});

// ─── Activity Log ──────────────────────────────────────────────────────────
router.get('/activity', (req, res) => {
  res.json(getActivityLog());
});

module.exports = router;
