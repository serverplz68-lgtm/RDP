export { Community as default } from './CommunityPages.jsx';
