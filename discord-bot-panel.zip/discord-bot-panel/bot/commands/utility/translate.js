const { SlashCommandBuilder } = require('discord.js');
const { createEmbed, errorEmbed } = require('../../utils/embed');
const axios = require('axios');

const LANGUAGES = [
  { name: 'English', value: 'en' }, { name: 'Spanish', value: 'es' },
  { name: 'French', value: 'fr' }, { name: 'German', value: 'de' },
  { name: 'Italian', value: 'it' }, { name: 'Portuguese', value: 'pt' },
  { name: 'Russian', value: 'ru' }, { name: 'Japanese', value: 'ja' },
  { name: 'Korean', value: 'ko' }, { name: 'Chinese (Simplified)', value: 'zh' },
  { name: 'Arabic', value: 'ar' }, { name: 'Hindi', value: 'hi' },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('translate')
    .setDescription('Translate text to another language')
    .addStringOption(o => o.setName('text').setDescription('Text to translate').setRequired(true))
    .addStringOption(o =>
      o.setName('to').setDescription('Target language').setRequired(true)
        .addChoices(...LANGUAGES)
    )
    .addStringOption(o =>
      o.setName('from').setDescription('Source language (auto-detect if not specified)')
        .addChoices({ name: 'Auto', value: 'auto' }, ...LANGUAGES)
    ),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const text = interaction.options.getString('text');
    const to = interaction.options.getString('to');
    const from = interaction.options.getString('from') || 'auto';

    try {
      // Using MyMemory free translation API (no key needed, up to 5000 chars/day)
      const langPair = from === 'auto' ? `en|${to}` : `${from}|${to}`;
      const { data } = await axios.get(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${langPair}`
      );

      if (data.responseStatus !== 200) throw new Error(data.responseMessage);

      const translated = data.responseData.translatedText;
      const langName = LANGUAGES.find(l => l.value === to)?.name || to;

      const embed = createEmbed({
        title: `🌐 Translation → ${langName}`,
        fields: [
          { name: 'Original', value: text.length > 1024 ? text.slice(0, 1021) + '...' : text },
          { name: 'Translated', value: translated.length > 1024 ? translated.slice(0, 1021) + '...' : translated },
        ],
        color: 0x3b82f6,
        footer: 'Powered by MyMemory',
      });

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Translation Failed', err.message)] });
    }
  },
};
