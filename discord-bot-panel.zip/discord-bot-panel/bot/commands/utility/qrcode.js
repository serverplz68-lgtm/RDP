const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { createEmbed, errorEmbed } = require('../../utils/embed');
const QRCode = require('qrcode');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('qr')
    .setDescription('Generate a QR code')
    .addStringOption(o => o.setName('content').setDescription('Text or URL to encode').setRequired(true)),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const content = interaction.options.getString('content');

    try {
      const buffer = await QRCode.toBuffer(content, {
        errorCorrectionLevel: 'H',
        type: 'png',
        width: 400,
        margin: 2,
        color: { dark: '#0f172a', light: '#f1f5f9' },
      });

      const attachment = new AttachmentBuilder(buffer, { name: 'qrcode.png' });

      const embed = createEmbed({
        title: '🔲 QR Code Generated',
        description: `Content: \`${content.slice(0, 100)}${content.length > 100 ? '...' : ''}\``,
        color: 0x3b82f6,
      });
      embed.setImage('attachment://qrcode.png');

      await interaction.editReply({ embeds: [embed], files: [attachment] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('QR Failed', err.message)] });
    }
  },
};
