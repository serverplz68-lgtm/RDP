import React, { useState, useEffect } from 'react';
import { Toggle, ChannelSelector, RoleSelector, SaveButton, Table, Modal } from '../components/UI.jsx';
import { useApi, useSave } from '../hooks/useApi.js';
import { showToast } from '../components/Toast.jsx';

export default function Moderation() {
  const { data: cfgData, loading: cfgLoading } = useApi('/api/moderation/config');
  const { data: warnData, loading: warnLoading, refetch: refetchWarnings } = useApi('/api/moderation/warnings?limit=50');
  const { save, saving, saved } = useSave('/api/moderation/config');

  const [cfg, setCfg] = useState({ logChannelId: '', muteRoleId: '', maxWarnings: 3, warnAction: 'timeout' });
  const [deleteModal, setDeleteModal] = useState(null);
  const [quickAction, setQuickAction] = useState({ type: 'ban', userId: '', reason: '', duration: 300, deleteMessageDays: 0, channelId: '', count: 10 });
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => { if (cfgData) setCfg({ ...cfg, ...cfgData }); }, [cfgData]);

  const set = (k, v) => setCfg(prev => ({ ...prev, [k]: v }));
  const setQA = (k, v) => setQuickAction(prev => ({ ...prev, [k]: v }));

  const deleteWarning = async (id) => {
    try {
      const r = await fetch(`/api/moderation/warnings/${id}`, { method: 'DELETE', credentials: 'include' });
      if (!r.ok) throw new Error();
      showToast('Warning deleted', 'success');
      refetchWarnings();
    } catch { showToast('Failed to delete warning', 'error'); }
    setDeleteModal(null);
  };

  const runAction = async () => {
    setActionLoading(true);
    try {
      const endpoint = `/api/moderation/${quickAction.type}`;
      const body = { userId: quickAction.userId, reason: quickAction.reason };
      if (quickAction.type === 'ban') body.deleteMessageDays = quickAction.deleteMessageDays;
      if (quickAction.type === 'timeout') body.duration = quickAction.duration;
      if (quickAction.type === 'purge') { body.channelId = quickAction.channelId; body.count = quickAction.count; delete body.userId; }

      const r = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify(body) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      showToast(`${quickAction.type} action executed successfully`, 'success');
      setQuickAction(prev => ({ ...prev, userId: '', reason: '' }));
    } catch (err) {
      showToast(`Action failed: ${err.message}`, 'error');
    } finally { setActionLoading(false); }
  };

  const warnColumns = [
    { key: 'userId', label: 'User', render: (v) => <span style={{ color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'reason', label: 'Reason' },
    { key: 'moderatorId', label: 'Moderator', render: (v) => <span style={{ color: 'var(--text-muted)', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'createdAt', label: 'Date', render: (v) => new Date(v).toLocaleDateString() },
    { key: 'id', label: 'Actions', render: (_, row) => (
      <button className="btn btn-danger btn-sm" onClick={() => setDeleteModal(row)}>Delete</button>
    )},
  ];

  return (
    <div>
      <div className="page-header">
        <h1>⚖️ Moderation Tools</h1>
        <p>Configure moderation settings and take quick actions.</p>
      </div>

      {/* Config */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>⚙️ Moderation Config</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Log Channel</label>
              <ChannelSelector value={cfg.logChannelId} onChange={v => set('logChannelId', v)} />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Mute Role</label>
              <RoleSelector value={cfg.muteRoleId} onChange={v => set('muteRoleId', v)} placeholder="Select mute role..." />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Max Warnings Before Action</label>
              <input type="number" className="form-control" min={1} max={20} value={cfg.maxWarnings} onChange={e => set('maxWarnings', parseInt(e.target.value))} />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Action on Max Warnings</label>
              <select className="form-control" value={cfg.warnAction} onChange={e => set('warnAction', e.target.value)}>
                <option value="timeout">⏱️ Timeout</option>
                <option value="kick">👢 Kick</option>
                <option value="ban">🔨 Ban</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header"><h2>⚡ Quick Actions</h2></div>
        <div className="card-body">
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
            {['ban', 'kick', 'timeout', 'purge'].map(t => (
              <button key={t} className={`btn ${quickAction.type === t ? 'btn-primary' : 'btn-ghost'}`} onClick={() => setQA('type', t)}>
                {{ ban: '🔨 Ban', kick: '👢 Kick', timeout: '⏱️ Timeout', purge: '🗑️ Purge' }[t]}
              </button>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            {quickAction.type !== 'purge' && (
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">User ID</label>
                <input className="form-control" value={quickAction.userId} onChange={e => setQA('userId', e.target.value)} placeholder="Discord User ID" />
              </div>
            )}
            {quickAction.type !== 'purge' && (
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Reason</label>
                <input className="form-control" value={quickAction.reason} onChange={e => setQA('reason', e.target.value)} placeholder="Reason..." />
              </div>
            )}
            {quickAction.type === 'ban' && (
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Delete Message Days (0–7)</label>
                <input type="number" className="form-control" min={0} max={7} value={quickAction.deleteMessageDays} onChange={e => setQA('deleteMessageDays', parseInt(e.target.value))} />
              </div>
            )}
            {quickAction.type === 'timeout' && (
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Duration (seconds)</label>
                <input type="number" className="form-control" min={60} value={quickAction.duration} onChange={e => setQA('duration', parseInt(e.target.value))} />
              </div>
            )}
            {quickAction.type === 'purge' && (
              <>
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Channel</label>
                  <ChannelSelector value={quickAction.channelId} onChange={v => setQA('channelId', v)} />
                </div>
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Message Count (1–100)</label>
                  <input type="number" className="form-control" min={1} max={100} value={quickAction.count} onChange={e => setQA('count', parseInt(e.target.value))} />
                </div>
              </>
            )}
          </div>

          <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'flex-end' }}>
            <button className="btn btn-danger" onClick={runAction} disabled={actionLoading || (!quickAction.userId && quickAction.type !== 'purge')}>
              {actionLoading ? 'Executing...' : `Execute ${quickAction.type}`}
            </button>
          </div>
        </div>
      </div>

      {/* Warnings Table */}
      <div className="card">
        <div className="card-header"><h2>⚠️ Warnings</h2></div>
        <div className="card-body">
          <Table columns={warnColumns} data={warnData?.warnings || []} loading={warnLoading} pagination pageSize={10} emptyMessage="No warnings found." />
        </div>
      </div>

      {/* Delete confirm modal */}
      <Modal isOpen={!!deleteModal} onClose={() => setDeleteModal(null)} title="Delete Warning"
        footer={<>
          <button className="btn btn-ghost" onClick={() => setDeleteModal(null)}>Cancel</button>
          <button className="btn btn-danger" onClick={() => deleteWarning(deleteModal?.id)}>Delete</button>
        </>}
      >
        <p style={{ color: 'var(--text-secondary)' }}>Are you sure you want to delete this warning?</p>
        {deleteModal && (
          <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)', fontSize: '0.875rem' }}>
            <p><strong>Reason:</strong> {deleteModal.reason}</p>
          </div>
        )}
      </Modal>
    </div>
  );
}
