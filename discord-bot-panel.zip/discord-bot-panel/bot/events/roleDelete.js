const { snapshotRole, revertActions } = require('../utils/revertAction');
const { emitAction } = require('../utils/socketEmitter');
const logger = require('../utils/logger');

const actionTracker = new Map();

function trackUserAction(guildId, userId, threshold, interval) {
  const key = `${guildId}:${userId}:role`;
  const now = Date.now();
  const tracker = actionTracker.get(key) || { timestamps: [] };
  tracker.timestamps = tracker.timestamps.filter(t => now - t < interval);
  tracker.timestamps.push(now);
  actionTracker.set(key, tracker);
  return tracker.timestamps.length >= threshold;
}

module.exports = {
  name: 'roleDelete',
  async execute(role, client, prisma) {
    if (!role.guild) return;

    const guildId = role.guild.id;
    const cache = client.configCache.get(guildId);
    const security = cache?.security;

    snapshotRole(role);

    if (!security?.antiNukeEnabled) return;

    let perpetratorId = null;
    try {
      const logs = await role.guild.fetchAuditLogs({ type: 32, limit: 1 }); // ROLE_DELETE = 32
      const entry = logs.entries.first();
      if (entry && Date.now() - entry.createdTimestamp < 5000) {
        perpetratorId = entry.executor?.id;
      }
    } catch (_) {}

    if (!perpetratorId || perpetratorId === client.user.id) return;

    const isWhitelisted =
      security.whitelistedUsers.includes(perpetratorId) ||
      role.guild.members.cache.get(perpetratorId)?.roles.cache.some(r =>
        security.whitelistedRoles.includes(r.id)
      );

    if (isWhitelisted) return;

    const exceeded = trackUserAction(guildId, perpetratorId, security.antiNukeThreshold, 10000);

    if (exceeded) {
      logger.warn(`Anti-nuke triggered (roleDelete): ${perpetratorId} in ${guildId}`);

      const member = role.guild.members.cache.get(perpetratorId);
      if (member) {
        try {
          switch (security.antiNukeAction) {
            case 'ban':
              await role.guild.members.ban(perpetratorId, { reason: 'Anti-nuke: excessive role deletions' });
              break;
            case 'kick':
              await member.kick('Anti-nuke: excessive role deletions');
              break;
            case 'strip_roles':
              const roles = member.roles.cache.filter(r => r.id !== role.guild.roles.everyone.id);
              await member.roles.remove(roles, 'Anti-nuke: role strip');
              break;
          }
        } catch (err) {
          logger.error('Anti-nuke action failed:', err.message);
        }
      }

      if (security.autoRevertEnabled) {
        await revertActions(role.guild, perpetratorId);
      }

      if (security.logChannelId) {
        const logChannel = role.guild.channels.cache.get(security.logChannelId);
        logChannel?.send({ content: `🛡️ **Anti-Nuke** — <@${perpetratorId}> mass-deleted roles. Action: **${security.antiNukeAction}**` }).catch(() => {});
      }

      emitAction({ type: 'anti_nuke', guildId, perpetratorId, action: security.antiNukeAction, description: 'Mass role deletion detected' });
      actionTracker.delete(`${guildId}:${perpetratorId}:role`);
    }
  },
};
