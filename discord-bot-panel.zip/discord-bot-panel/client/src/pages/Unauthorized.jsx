import React from 'react';
import { Link } from 'react-router-dom';

export default function Unauthorized() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)', padding: '1.5rem' }}>
      <div style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-xl)', padding: '2.5rem', width: '100%', maxWidth: '420px', textAlign: 'center', boxShadow: 'var(--shadow-lg)' }}>
        <div style={{ fontSize: '3.5rem', marginBottom: '1rem' }}>🔒</div>
        <h1 style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--danger)', marginBottom: '0.75rem' }}>Access Denied</h1>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem', fontWeight: 600 }}>Only Admins Allowed Here!</p>
        <p style={{ color: 'var(--text-muted)', marginBottom: '2rem', fontSize: '0.9375rem' }}>
          You do not have permission to access this dashboard. Administrator privileges are required.
        </p>
        <Link
          to="/login"
          style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            padding: '0.75rem 1.5rem', background: 'var(--primary-500)', color: '#fff',
            borderRadius: 'var(--radius-md)', fontWeight: '600', textDecoration: 'none',
            transition: 'background var(--transition-base)',
          }}
        >
          ← Return to Login
        </Link>
      </div>
    </div>
  );
}
