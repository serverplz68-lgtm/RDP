const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Configure the verification system')
    .addSubcommand(s => s.setName('enable').setDescription('Enable verification'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable verification'))
    .addSubcommand(s =>
      s.setName('config')
        .setDescription('Configure verification settings')
        .addRoleOption(o => o.setName('verified_role').setDescription('Role given after verification').setRequired(false))
        .addRoleOption(o => o.setName('unverified_role').setDescription('Role given on join (pre-verification)').setRequired(false))
        .addChannelOption(o => o.setName('channel').setDescription('Verification channel').setRequired(false))
        .addStringOption(o => o.setName('message').setDescription('Verification message').setRequired(false))
    )
    .addSubcommand(s => s.setName('panel').setDescription('Send the verification panel'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;

    if (sub === 'enable') {
      await prisma.roleConfig.upsert({ where: { guildId }, update: { verificationEnabled: true }, create: { guildId, verificationEnabled: true } });
      await refreshCache(client, prisma, guildId);
      return interaction.editReply({ embeds: [successEmbed('Verification Enabled', 'The verification system is now active.')] });
    }

    if (sub === 'disable') {
      await prisma.roleConfig.upsert({ where: { guildId }, update: { verificationEnabled: false }, create: { guildId } });
      await refreshCache(client, prisma, guildId);
      return interaction.editReply({ embeds: [successEmbed('Verification Disabled', 'Verification has been turned off.')] });
    }

    if (sub === 'config') {
      const verifiedRole = interaction.options.getRole('verified_role');
      const unverifiedRole = interaction.options.getRole('unverified_role');
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('message');

      const updateData = {};
      if (verifiedRole) updateData.verifiedRoleId = verifiedRole.id;
      if (unverifiedRole) updateData.unverifiedRoleId = unverifiedRole.id;
      if (channel) updateData.verifyChannelId = channel.id;
      if (message) updateData.verifyMessage = message;

      await prisma.roleConfig.upsert({ where: { guildId }, update: updateData, create: { guildId, ...updateData } });
      await refreshCache(client, prisma, guildId);
      return interaction.editReply({ embeds: [successEmbed('Verification Configured', 'Settings updated.')] });
    }

    if (sub === 'panel') {
      const cfg = await prisma.roleConfig.findUnique({ where: { guildId } });
      if (!cfg?.verifyChannelId) return interaction.editReply({ embeds: [errorEmbed('Not Configured', 'Set a verification channel first with `/verify config`.')] });

      const channel = interaction.guild.channels.cache.get(cfg.verifyChannelId);
      if (!channel) return interaction.editReply({ embeds: [errorEmbed('Channel Not Found', 'Verification channel no longer exists.')] });

      const embed = new EmbedBuilder()
        .setTitle('✅ Server Verification')
        .setDescription(cfg.verifyMessage || 'Click the button below to verify yourself and gain access to the server.')
        .setColor(0x10b981)
        .setFooter({ text: interaction.guild.name });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('verify').setLabel('Verify Me').setStyle(ButtonStyle.Success).setEmoji('✅')
      );

      await channel.send({ embeds: [embed], components: [row] });
      return interaction.editReply({ embeds: [successEmbed('Panel Sent', `Verification panel sent to ${channel}.`)] });
    }
  },
};

async function refreshCache(client, prisma, guildId) {
  const cfg = await prisma.roleConfig.findUnique({ where: { guildId } });
  const cache = client.configCache.get(guildId) || {};
  client.configCache.set(guildId, { ...cache, roles: cfg });
}
