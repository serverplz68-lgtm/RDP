const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { successEmbed, errorEmbed, createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View warnings for a user')
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const target = interaction.options.getUser('user');

    const warnings = await prisma.warning.findMany({
      where: { guildId: interaction.guildId, userId: target.id },
      orderBy: { createdAt: 'desc' },
    });

    if (!warnings.length) {
      return interaction.editReply({ embeds: [createEmbed({ title: `Warnings for ${target.username}`, description: 'No warnings found.', color: 0x10b981 })] });
    }

    const fields = warnings.slice(0, 10).map((w, i) => ({
      name: `#${i + 1} — ${new Date(w.createdAt).toLocaleDateString()}`,
      value: `**Reason:** ${w.reason}\n**By:** <@${w.moderatorId}>`,
    }));

    await interaction.editReply({
      embeds: [createEmbed({ title: `⚠️ Warnings for ${target.username}`, description: `Total: **${warnings.length}**`, fields, color: 0xf59e0b })],
    });
  },
};
