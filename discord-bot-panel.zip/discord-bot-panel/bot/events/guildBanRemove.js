module.exports = {
  name: 'guildBanRemove',
  async execute(ban, client, prisma) {
    // Future: log unban actions
  },
};
