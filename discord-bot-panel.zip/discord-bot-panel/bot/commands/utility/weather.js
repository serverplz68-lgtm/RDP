const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { createEmbed, errorEmbed } = require('../../utils/embed');
const axios = require('axios');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('weather')
    .setDescription('Get current weather for a location')
    .addStringOption(o => o.setName('location').setDescription('City name or zip code').setRequired(true)),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const location = interaction.options.getString('location');

    if (!config.openWeatherKey) {
      return interaction.editReply({ embeds: [errorEmbed('Not Configured', 'OpenWeather API key is not set.')] });
    }

    try {
      const { data } = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&appid=${config.openWeatherKey}&units=metric`
      );

      const embed = new EmbedBuilder()
        .setTitle(`🌤️ Weather in ${data.name}, ${data.sys.country}`)
        .setColor(0x3b82f6)
        .addFields(
          { name: '🌡️ Temperature', value: `${data.main.temp}°C (feels like ${data.main.feels_like}°C)`, inline: true },
          { name: '💧 Humidity', value: `${data.main.humidity}%`, inline: true },
          { name: '💨 Wind', value: `${data.wind.speed} m/s`, inline: true },
          { name: '☁️ Condition', value: data.weather[0].description, inline: true },
          { name: '🔼 High', value: `${data.main.temp_max}°C`, inline: true },
          { name: '🔽 Low', value: `${data.main.temp_min}°C`, inline: true },
        )
        .setThumbnail(`https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`)
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Not Found', `Could not find weather for **${location}**.`)] });
    }
  },
};
