import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useSocket } from '../context/SocketContext.jsx';

const NAV_ITEMS = [
  { section: 'Overview', items: [{ path: '/dashboard', icon: '📊', label: 'Dashboard' }] },
  { section: 'Security', items: [{ path: '/security', icon: '🛡️', label: 'Advanced Security' }] },
  { section: 'Moderation', items: [{ path: '/moderation', icon: '⚖️', label: 'Moderation Tools' }] },
  { section: 'Messaging', items: [{ path: '/dm', icon: '✉️', label: 'DM System' }] },
  {
    section: 'Features',
    items: [
      { path: '/tickets', icon: '🎫', label: 'Ticket System' },
      { path: '/community', icon: '👥', label: 'Community' },
      { path: '/utility', icon: '🔧', label: 'Utility Commands' },
    ],
  },
  {
    section: 'Server',
    items: [
      { path: '/information', icon: 'ℹ️', label: 'Information' },
      { path: '/roles', icon: '🎭', label: 'Role Management' },
    ],
  },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const { connected } = useSocket();
  const [mobileOpen, setMobileOpen] = useState(false);

  const avatarUrl = user?.avatar
    ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64`
    : `https://cdn.discordapp.com/embed/avatars/0.png`;

  return (
    <>
      {/* Mobile hamburger */}
      <button
        className="hamburger-btn"
        onClick={() => setMobileOpen(true)}
        aria-label="Open menu"
        style={{
          display: 'none',
          position: 'fixed',
          top: '1rem',
          left: '1rem',
          zIndex: 300,
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-md)',
          padding: '0.5rem',
          cursor: 'pointer',
          fontSize: '1.25rem',
          color: 'var(--text-primary)',
          width: '44px',
          height: '44px',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        ☰
      </button>

      {/* Overlay */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            zIndex: 400,
            display: 'none',
          }}
          className="mobile-overlay"
        />
      )}

      {/* Sidebar */}
      <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
        {/* Bot identity */}
        <div className="sidebar-brand">
          <div className="sidebar-bot-icon">🤖</div>
          <div>
            <div className="sidebar-bot-name">Bot Dashboard</div>
            <div className="sidebar-status">
              <span
                className="status-dot"
                style={{ background: connected ? 'var(--success)' : 'var(--danger)' }}
              />
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                {connected ? 'Bot Online' : 'Bot Offline'}
              </span>
            </div>
          </div>
          {mobileOpen && (
            <button
              onClick={() => setMobileOpen(false)}
              style={{
                marginLeft: 'auto',
                background: 'none',
                border: 'none',
                color: 'var(--text-muted)',
                cursor: 'pointer',
                fontSize: '1.25rem',
                padding: '0.25rem',
                minHeight: '44px',
              }}
            >
              ✕
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="sidebar-nav">
          {NAV_ITEMS.map(({ section, items }) => (
            <div key={section} className="nav-section">
              <div className="nav-section-label">{section}</div>
              {items.map(({ path, icon, label }) => (
                <NavLink
                  key={path}
                  to={path}
                  className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
                  onClick={() => setMobileOpen(false)}
                >
                  <span className="nav-icon">{icon}</span>
                  <span>{label}</span>
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        {/* User footer */}
        <div className="sidebar-footer">
          <img
            src={avatarUrl}
            alt={user?.username}
            className="user-avatar"
            onError={e => { e.target.src = 'https://cdn.discordapp.com/embed/avatars/0.png'; }}
          />
          <div className="user-info">
            <div className="user-name">{user?.username}</div>
            <div className="user-role">Administrator</div>
          </div>
          <button className="btn btn-ghost btn-sm logout-btn" onClick={logout} title="Logout">
            ↩
          </button>
        </div>
      </aside>

      <style>{`
        .sidebar {
          position: fixed;
          left: 0;
          top: 0;
          bottom: 0;
          width: var(--sidebar-width);
          background: var(--bg-secondary);
          border-right: 1px solid var(--border-color);
          display: flex;
          flex-direction: column;
          z-index: 200;
          overflow-y: auto;
          transition: transform var(--transition-base);
        }

        .sidebar-brand {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 1.25rem 1rem;
          border-bottom: 1px solid var(--border-color);
        }

        .sidebar-bot-icon {
          font-size: 1.75rem;
          width: 44px;
          height: 44px;
          background: var(--bg-tertiary);
          border-radius: var(--radius-lg);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .sidebar-bot-name {
          font-size: 0.9375rem;
          font-weight: 700;
          color: var(--text-primary);
        }

        .sidebar-status {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          margin-top: 0.125rem;
        }

        .status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          flex-shrink: 0;
        }

        .sidebar-nav {
          flex: 1;
          padding: 0.75rem 0;
          overflow-y: auto;
        }

        .nav-section { margin-bottom: 0.5rem; }

        .nav-section-label {
          padding: 0.375rem 1rem;
          font-size: 0.6875rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-muted);
          margin-top: 0.5rem;
        }

        .nav-item {
          display: flex;
          align-items: center;
          gap: 0.625rem;
          padding: 0.5625rem 1rem;
          color: var(--text-secondary);
          font-size: 0.875rem;
          font-weight: 500;
          text-decoration: none;
          transition: all var(--transition-base);
          border-left: 2px solid transparent;
          min-height: 44px;
        }

        .nav-item:hover {
          color: var(--text-primary);
          background: rgba(255,255,255,0.04);
        }

        .nav-item.active {
          color: var(--primary-500);
          background: rgba(59,130,246,0.08);
          border-left-color: var(--primary-500);
        }

        .nav-icon { font-size: 1rem; width: 1.25rem; text-align: center; flex-shrink: 0; }

        .sidebar-footer {
          display: flex;
          align-items: center;
          gap: 0.625rem;
          padding: 0.875rem 1rem;
          border-top: 1px solid var(--border-color);
          background: var(--bg-secondary);
        }

        .user-avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          flex-shrink: 0;
          object-fit: cover;
        }

        .user-info { flex: 1; min-width: 0; }

        .user-name {
          font-size: 0.875rem;
          font-weight: 600;
          color: var(--text-primary);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .user-role {
          font-size: 0.75rem;
          color: var(--text-muted);
        }

        .logout-btn {
          flex-shrink: 0;
          font-size: 1rem;
        }

        @media (max-width: 768px) {
          .sidebar {
            transform: translateX(-100%);
          }
          .sidebar.sidebar-open {
            transform: translateX(0);
            box-shadow: var(--shadow-lg);
          }
          .hamburger-btn {
            display: flex !important;
          }
          .mobile-overlay {
            display: block !important;
          }
        }
      `}</style>
    </>
  );
}
