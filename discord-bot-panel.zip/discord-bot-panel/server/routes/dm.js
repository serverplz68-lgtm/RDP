const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const axios = require('axios');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');
const { dmLimiter } = require('../middleware/rateLimiter');

const router = express.Router();
const prisma = new PrismaClient();
const GUILD_ID = process.env.DISCORD_GUILD_ID;

router.use(isAuthenticated, isAdmin);

const discordApi = axios.create({
  baseURL: 'https://discord.com/api/v10',
  headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` },
});

// ─── DM Logs ──────────────────────────────────────────────────────────────
router.get('/logs', async (req, res) => {
  try {
    const { type, page = 1, limit = 20 } = req.query;
    const where = { guildId: GUILD_ID };
    if (type) where.targetType = type;

    const [logs, total] = await Promise.all([
      prisma.dMLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (parseInt(page) - 1) * parseInt(limit),
        take: parseInt(limit),
      }),
      prisma.dMLog.count({ where }),
    ]);

    res.json({ logs, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Send DM via Dashboard ───────────────────────────────────────────────
router.post('/send', dmLimiter, [
  body('targetType').isIn(['user', 'role', 'all']),
  body('targetId').optional().isString(),
  body('content').notEmpty().isString().isLength({ max: 2000 }),
  body('embedData').optional().isObject(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { targetType, targetId, content, embedData } = req.body;

  // Emit to bot via socket to handle the actual DM sending
  if (global.botSocket) {
    global.botSocket.emit('dashboard:action', {
      type: 'send_dm',
      targetType,
      targetId,
      content,
      embedData,
      guildId: GUILD_ID,
      requestedBy: req.session.user.id,
    });
    res.json({ success: true, message: 'DM job sent to bot.' });
  } else {
    res.status(503).json({ error: 'Bot is not connected.' });
  }
});

module.exports = router;
