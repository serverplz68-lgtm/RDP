module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState, client, prisma) {
    // Future: voice channel tracking, auto-VC creation, etc.
  },
};
