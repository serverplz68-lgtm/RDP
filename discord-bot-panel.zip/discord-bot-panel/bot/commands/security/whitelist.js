const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('Manage security whitelist')
    .addSubcommand(s => s.setName('adduser').setDescription('Whitelist a user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand(s => s.setName('removeuser').setDescription('Remove user from whitelist').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand(s => s.setName('addrole').setDescription('Whitelist a role').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true)))
    .addSubcommand(s => s.setName('removerole').setDescription('Remove role from whitelist').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('View whitelist'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;

    const current = await prisma.securityConfig.findUnique({ where: { guildId } });
    const users = current?.whitelistedUsers || [];
    const roles = current?.whitelistedRoles || [];

    if (sub === 'list') {
      const userMentions = users.length ? users.map(id => `<@${id}>`).join(', ') : 'None';
      const roleMentions = roles.length ? roles.map(id => `<@&${id}>`).join(', ') : 'None';
      return interaction.editReply({
        embeds: [createEmbed({
          title: '✅ Security Whitelist',
          fields: [{ name: 'Users', value: userMentions }, { name: 'Roles', value: roleMentions }],
          color: 0x10b981,
        })],
      });
    }

    let updateData = {};
    if (sub === 'adduser') {
      const user = interaction.options.getUser('user');
      if (!users.includes(user.id)) updateData = { whitelistedUsers: [...users, user.id] };
    } else if (sub === 'removeuser') {
      const user = interaction.options.getUser('user');
      updateData = { whitelistedUsers: users.filter(id => id !== user.id) };
    } else if (sub === 'addrole') {
      const role = interaction.options.getRole('role');
      if (!roles.includes(role.id)) updateData = { whitelistedRoles: [...roles, role.id] };
    } else if (sub === 'removerole') {
      const role = interaction.options.getRole('role');
      updateData = { whitelistedRoles: roles.filter(id => id !== role.id) };
    }

    await prisma.securityConfig.upsert({ where: { guildId }, update: updateData, create: { guildId, ...updateData } });
    const cfg = await prisma.securityConfig.findUnique({ where: { guildId } });
    const cache = client.configCache.get(guildId) || {};
    client.configCache.set(guildId, { ...cache, security: cfg });

    await interaction.editReply({ embeds: [successEmbed('Whitelist Updated', 'The whitelist has been updated.')] });
  },
};
