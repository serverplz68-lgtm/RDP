import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { useSocket } from '../context/SocketContext.jsx';
import { useApi } from '../hooks/useApi.js';
import { StatCard } from '../components/UI.jsx';
import {
  ComposedChart, Area, Line, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';

function formatUptime(seconds) {
  if (!seconds) return '—';
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}

function formatTime(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

const ACTION_ICONS = { ban: '🔨', kick: '👢', timeout: '⏱️', warn: '⚠️', anti_nuke: '🛡️', purge: '🗑️', default: '⚙️' };

export default function Dashboard() {
  const { user } = useAuth();
  const { perfData, activityLog, latestStats, connected } = useSocket();
  const { data: statsData, loading: statsLoading } = useApi('/api/dashboard/stats');

  const ping = latestStats?.ping ?? statsData?.ping ?? -1;
  const pingColor = ping < 0 ? 'var(--text-muted)' : ping < 100 ? 'var(--success)' : ping < 300 ? 'var(--warning)' : 'var(--danger)';
  const health = ping < 0 ? 'Unknown' : ping < 100 ? 'Excellent' : ping < 300 ? 'Good' : 'Degraded';
  const healthColor = ping < 0 ? 'var(--text-muted)' : ping < 100 ? 'var(--success)' : ping < 300 ? 'var(--warning)' : 'var(--danger)';

  const chartData = perfData.map(p => ({
    time: formatTime(p.time || p.timestamp),
    memory: p.memoryMB || 0,
    ping: p.ping || 0,
    eventLoop: p.eventLoopLag || 0,
  }));

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '0.625rem 0.875rem', fontSize: '0.8125rem' }}>
        <p style={{ color: 'var(--text-muted)', marginBottom: '0.25rem' }}>{label}</p>
        {payload.map(p => (
          <p key={p.name} style={{ color: p.color }}>{p.name}: <strong>{p.value}</strong></p>
        ))}
      </div>
    );
  };

  return (
    <div>
      <div className="page-header">
        <h1>👋 Welcome back, {user?.username}!</h1>
        <p>Here's what's happening with your bot today.</p>
      </div>

      {/* Stats Row */}
      <div className="stats-grid">
        <StatCard
          icon="⚡"
          label="Bot Ping"
          value={ping < 0 ? 'Offline' : `${ping}ms`}
          color={pingColor}
          loading={statsLoading && !latestStats}
        />
        <StatCard
          icon="💚"
          label="Bot Health"
          value={health}
          color={healthColor}
          loading={statsLoading && !latestStats}
        />
        <StatCard
          icon="🌐"
          label="Uptime"
          value={formatUptime(latestStats?.uptime ?? statsData?.uptime)}
          color="var(--info)"
          loading={statsLoading && !latestStats}
        />
        <StatCard
          icon="👥"
          label="Members"
          value={statsData?.memberCount?.toLocaleString() ?? '—'}
          color="var(--primary-500)"
          loading={statsLoading}
        />
        <StatCard
          icon={connected ? '🟢' : '🔴'}
          label="Socket Status"
          value={connected ? 'Connected' : 'Disconnected'}
          color={connected ? 'var(--success)' : 'var(--danger)'}
          loading={false}
        />
      </div>

      {/* Performance Charts */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header"><h2>📈 Bot Performance</h2></div>
        <div className="card-body">
          {chartData.length === 0 ? (
            <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
              Waiting for bot data...
            </div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={220}>
                <ComposedChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                  <XAxis dataKey="time" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
                  <YAxis yAxisId="left" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
                  <YAxis yAxisId="right" orientation="right" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ color: 'var(--text-secondary)', fontSize: '0.8125rem' }} />
                  <Area yAxisId="left" type="monotone" dataKey="memory" name="Memory (MB)" stroke="var(--primary-500)" fill="rgba(59,130,246,0.15)" strokeWidth={2} dot={false} />
                  <Line yAxisId="right" type="monotone" dataKey="ping" name="Ping (ms)" stroke="var(--success)" strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>

              <div style={{ marginTop: '1rem' }}>
                <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>Event Loop Lag (ms)</div>
                <ResponsiveContainer width="100%" height={100}>
                  <BarChart data={chartData} margin={{ top: 0, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                    <XAxis dataKey="time" tick={{ fill: 'var(--text-muted)', fontSize: 10 }} />
                    <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 10 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="eventLoop" name="Event Loop (ms)" fill="var(--warning)" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="card">
        <div className="card-header"><h2>📋 Recent Activity</h2></div>
        <div className="card-body" style={{ padding: 0 }}>
          {activityLog.length === 0 ? (
            <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>No recent activity.</div>
          ) : (
            <div>
              {activityLog.slice(0, 10).map((item, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: '0.75rem',
                  padding: '0.75rem 1.25rem',
                  borderBottom: i < activityLog.slice(0, 10).length - 1 ? '1px solid var(--border-color)' : 'none',
                }}>
                  <span style={{ fontSize: '1.25rem', flexShrink: 0 }}>{ACTION_ICONS[item.type] || ACTION_ICONS.default}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: '0.875rem', color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.description}</div>
                    {item.moderatorId && (
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>by {item.moderatorId}</div>
                    )}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', flexShrink: 0 }}>
                    {item.timestamp ? new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
