const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const axios = require('axios');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');

const router = express.Router();
const prisma = new PrismaClient();
const GUILD_ID = process.env.DISCORD_GUILD_ID;

router.use(isAuthenticated, isAdmin);

// ─── Config ───────────────────────────────────────────────────────────────
router.get('/config', async (req, res) => {
  try {
    const config = await prisma.moderationConfig.findUnique({ where: { guildId: GUILD_ID } });
    res.json(config || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/config', [
  body('logChannelId').optional().isString(),
  body('muteRoleId').optional().isString(),
  body('maxWarnings').optional().isInt({ min: 1, max: 20 }),
  body('warnAction').optional().isIn(['timeout', 'kick', 'ban']),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const config = await prisma.moderationConfig.upsert({
      where: { guildId: GUILD_ID },
      update: req.body,
      create: { guildId: GUILD_ID, ...req.body },
    });

    if (global.botSocket) {
      global.botSocket.emit('config:moderation:update', { guildId: GUILD_ID, config });
    }

    res.json(config);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Warnings ────────────────────────────────────────────────────────────
router.get('/warnings', async (req, res) => {
  try {
    const { userId, page = 1, limit = 10 } = req.query;
    const where = { guildId: GUILD_ID };
    if (userId) where.userId = userId;

    const [warnings, total] = await Promise.all([
      prisma.warning.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (parseInt(page) - 1) * parseInt(limit),
        take: parseInt(limit),
      }),
      prisma.warning.count({ where }),
    ]);

    res.json({ warnings, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/warnings/:id', async (req, res) => {
  try {
    await prisma.warning.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/warnings/user/:userId', async (req, res) => {
  try {
    const result = await prisma.warning.deleteMany({
      where: { guildId: GUILD_ID, userId: req.params.userId },
    });
    res.json({ deleted: result.count });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Quick Actions (via Discord API) ─────────────────────────────────────
const discordApi = axios.create({
  baseURL: 'https://discord.com/api/v10',
  headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` },
});

router.post('/ban', [
  body('userId').notEmpty().isString(),
  body('reason').optional().isString(),
  body('deleteMessageDays').optional().isInt({ min: 0, max: 7 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const { userId, reason = 'Banned via dashboard', deleteMessageDays = 0 } = req.body;
    await discordApi.put(`/guilds/${GUILD_ID}/bans/${userId}`, {
      delete_message_days: deleteMessageDays,
      reason: `${req.session.user.username} (Dashboard): ${reason}`,
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.response?.data?.message || err.message });
  }
});

router.post('/kick', [
  body('userId').notEmpty().isString(),
  body('reason').optional().isString(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const { userId, reason = 'Kicked via dashboard' } = req.body;
    await discordApi.delete(`/guilds/${GUILD_ID}/members/${userId}`, {
      headers: { 'X-Audit-Log-Reason': `${req.session.user.username} (Dashboard): ${reason}` },
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.response?.data?.message || err.message });
  }
});

router.post('/timeout', [
  body('userId').notEmpty().isString(),
  body('duration').notEmpty().isInt({ min: 1 }),
  body('reason').optional().isString(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const { userId, duration, reason = 'Timed out via dashboard' } = req.body;
    const until = new Date(Date.now() + duration * 1000).toISOString();
    await discordApi.patch(`/guilds/${GUILD_ID}/members/${userId}`, {
      communication_disabled_until: until,
    }, { headers: { 'X-Audit-Log-Reason': reason } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.response?.data?.message || err.message });
  }
});

router.post('/purge', [
  body('channelId').notEmpty().isString(),
  body('count').notEmpty().isInt({ min: 1, max: 100 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const { channelId, count } = req.body;

    // Fetch messages
    const msgsRes = await discordApi.get(`/channels/${channelId}/messages?limit=${count}`);
    const messages = msgsRes.data;

    const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
    const valid = messages.filter(m => new Date(m.timestamp).getTime() > twoWeeksAgo).map(m => m.id);

    if (valid.length === 0) return res.status(400).json({ error: 'No messages within the 14-day limit.' });

    await discordApi.post(`/channels/${channelId}/messages/bulk-delete`, { messages: valid });
    res.json({ deleted: valid.length });
  } catch (err) {
    res.status(500).json({ error: err.response?.data?.message || err.message });
  }
});

module.exports = router;
