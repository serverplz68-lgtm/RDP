const express = require('express');
const DiscordStrategy = require('passport-discord').Strategy;
const axios = require('axios');

const router = express.Router();

function setupPassport(passport) {
  passport.use(new DiscordStrategy({
    clientID: process.env.DISCORD_CLIENT_ID,
    clientSecret: process.env.DISCORD_CLIENT_SECRET,
    callbackURL: process.env.DISCORD_CALLBACK_URL,
    scope: ['identify', 'guilds'],
  }, (accessToken, refreshToken, profile, done) => {
    return done(null, { ...profile, accessToken });
  }));

  passport.serializeUser((user, done) => done(null, user));
  passport.deserializeUser((user, done) => done(null, user));
}

function authRoutes(passport) {
  // ─── Initiate OAuth2 ──────────────────────────────────────────────────
  router.get('/discord', passport.authenticate('discord'));

  // ─── OAuth2 Callback ──────────────────────────────────────────────────
  router.get('/discord/callback',
    passport.authenticate('discord', { failureRedirect: `${process.env.CLIENT_URL}/unauthorized` }),
    async (req, res) => {
      try {
        const guildId = process.env.DISCORD_GUILD_ID;
        const botToken = process.env.DISCORD_TOKEN;
        const userId = req.user.id;

        // Check if user is a member of the target guild and has Administrator permission
        const memberRes = await axios.get(
          `https://discord.com/api/v10/guilds/${guildId}/members/${userId}`,
          { headers: { Authorization: `Bot ${botToken}` } }
        );

        const member = memberRes.data;
        const permissions = BigInt(member.permissions || '0');
        const ADMINISTRATOR = BigInt(0x8);
        const isAdmin = (permissions & ADMINISTRATOR) === ADMINISTRATOR;

        req.session.user = {
          id: req.user.id,
          username: req.user.username,
          discriminator: req.user.discriminator,
          avatar: req.user.avatar,
          email: req.user.email,
        };
        req.session.isAdmin = isAdmin;

        if (isAdmin) {
          return res.redirect(`${process.env.CLIENT_URL}/dashboard`);
        } else {
          return res.redirect(`${process.env.CLIENT_URL}/unauthorized`);
        }
      } catch (err) {
        // User is not in the guild
        req.session.user = {
          id: req.user.id,
          username: req.user.username,
          avatar: req.user.avatar,
        };
        req.session.isAdmin = false;
        return res.redirect(`${process.env.CLIENT_URL}/unauthorized`);
      }
    }
  );

  // ─── Current User ────────────────────────────────────────────────────
  router.get('/me', (req, res) => {
    if (!req.session.user) {
      return res.json({ user: null, isAdmin: false });
    }
    res.json({ user: req.session.user, isAdmin: req.session.isAdmin || false });
  });

  // ─── Logout ────────────────────────────────────────────────────────────
  router.get('/logout', (req, res) => {
    req.session.destroy(() => {
      res.clearCookie('connect.sid');
      res.redirect(process.env.CLIENT_URL || 'http://localhost:5173');
    });
  });

  return router;
}

module.exports = authRoutes;
module.exports.setupPassport = setupPassport;
