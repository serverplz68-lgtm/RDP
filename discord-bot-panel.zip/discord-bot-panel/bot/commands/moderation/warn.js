const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { emitAction, emitWarningEvent } = require('../../utils/socketEmitter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the warning').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    try {
      const warning = await prisma.warning.create({
        data: {
          guildId: interaction.guildId,
          userId: target.id,
          moderatorId: interaction.user.id,
          reason,
        },
      });

      // Check warning count vs moderation config
      const cache = client.configCache.get(interaction.guildId);
      const modConfig = cache?.moderation;

      const warnCount = await prisma.warning.count({ where: { guildId: interaction.guildId, userId: target.id } });

      emitWarningEvent({ guildId: interaction.guildId, userId: target.id, moderatorId: interaction.user.id, reason, warningId: warning.id });
      emitAction({ type: 'warn', guildId: interaction.guildId, targetId: target.id, moderatorId: interaction.user.id, reason, description: `${interaction.user.username} warned ${target.username}: ${reason}` });

      // Notify user via DM
      await target.send({ embeds: [errorEmbed(`Warning in ${interaction.guild.name}`, `You have received a warning.\n**Reason:** ${reason}\n**Total warnings:** ${warnCount}`)] }).catch(() => {});

      // Take action if max warnings exceeded
      if (modConfig && warnCount >= modConfig.maxWarnings) {
        const member = interaction.guild.members.cache.get(target.id);
        if (member) {
          switch (modConfig.warnAction) {
            case 'timeout': await member.timeout(60 * 60 * 1000, `Max warnings reached (${warnCount})`).catch(() => {}); break;
            case 'kick': await member.kick(`Max warnings reached (${warnCount})`).catch(() => {}); break;
            case 'ban': await interaction.guild.members.ban(target.id, { reason: `Max warnings reached (${warnCount})` }).catch(() => {}); break;
          }
        }
      }

      await interaction.editReply({
        embeds: [successEmbed('Warning Issued', `**${target.tag}** has been warned.\n**Reason:** ${reason}\n**Total warnings:** ${warnCount}${modConfig && warnCount >= modConfig.maxWarnings ? `\n⚠️ Max warnings reached — ${modConfig.warnAction} applied.` : ''}`)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Warn Failed', err.message)] });
    }
  },
};
