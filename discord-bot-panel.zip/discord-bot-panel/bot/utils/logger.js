const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
};

function timestamp() {
  return new Date().toISOString().replace('T', ' ').substring(0, 19);
}

const logger = {
  info: (msg, ...args) => console.log(`${colors.cyan}[${timestamp()}] [INFO]${colors.reset} ${msg}`, ...args),
  success: (msg, ...args) => console.log(`${colors.green}[${timestamp()}] [OK]${colors.reset} ${msg}`, ...args),
  warn: (msg, ...args) => console.warn(`${colors.yellow}[${timestamp()}] [WARN]${colors.reset} ${msg}`, ...args),
  error: (msg, ...args) => console.error(`${colors.red}[${timestamp()}] [ERROR]${colors.reset} ${msg}`, ...args),
  debug: (msg, ...args) => {
    if (process.env.NODE_ENV !== 'production') {
      console.log(`${colors.magenta}[${timestamp()}] [DEBUG]${colors.reset} ${msg}`, ...args);
    }
  },
  bot: (msg, ...args) => console.log(`${colors.blue}[${timestamp()}] [BOT]${colors.reset} ${msg}`, ...args),
};

module.exports = logger;
