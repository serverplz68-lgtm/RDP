const logger = require('../utils/logger');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client, _prismaIgnored, prisma) {
    logger.success(`Logged in as ${client.user.tag}`);
    logger.info(`Serving ${client.guilds.cache.size} guilds`);

    // Load all guild configs into memory cache
    await loadConfigCache(client, prisma);

    // Set bot status
    client.user.setActivity('your server | /help', { type: 3 }); // WATCHING
  },
};

async function loadConfigCache(client, prisma) {
  try {
    const guilds = await prisma.guild.findMany({
      include: {
        securityConfig: true,
        moderationConfig: true,
        ticketConfig: true,
        communityConfig: true,
        roleConfig: true,
        customCommands: true,
        afkUsers: true,
        autoPublishChannels: true,
      },
    });

    for (const guild of guilds) {
      client.configCache.set(guild.id, {
        guild,
        security: guild.securityConfig,
        moderation: guild.moderationConfig,
        tickets: guild.ticketConfig,
        community: guild.communityConfig,
        roles: guild.roleConfig,
        customCommands: guild.customCommands,
        afkUsers: new Map(guild.afkUsers.map(a => [a.userId, a])),
        autoPublishChannels: new Set(guild.autoPublishChannels.map(a => a.channelId)),
      });
    }

    // Ensure all Discord guilds have a DB entry
    for (const [guildId, guild] of client.guilds.cache) {
      if (!client.configCache.has(guildId)) {
        const fetchedGuild = await guild.fetch();
        const created = await prisma.guild.upsert({
          where: { id: guildId },
          update: { name: fetchedGuild.name, ownerId: fetchedGuild.ownerId },
          create: {
            id: guildId,
            name: fetchedGuild.name,
            ownerId: fetchedGuild.ownerId,
          },
        });
        client.configCache.set(guildId, {
          guild: created,
          security: null,
          moderation: null,
          tickets: null,
          community: null,
          roles: null,
          customCommands: [],
          afkUsers: new Map(),
          autoPublishChannels: new Set(),
        });
        logger.info(`Auto-created DB entry for guild: ${fetchedGuild.name}`);
      }
    }

    logger.success(`Config cache loaded for ${client.configCache.size} guilds`);
  } catch (err) {
    logger.error('Failed to load config cache:', err);
  }
}
