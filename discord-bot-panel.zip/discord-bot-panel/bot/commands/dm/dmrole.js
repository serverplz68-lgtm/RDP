const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { emitDMLog } = require('../../utils/socketEmitter');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dmrole')
    .setDescription('DM all members with a specific role')
    .addRoleOption(o => o.setName('role').setDescription('Target role').setRequired(true))
    .addStringOption(o => o.setName('message').setDescription('Message to send').setRequired(true))
    .addStringOption(o => o.setName('embed_title').setDescription('Optional embed title'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });

    const role = interaction.options.getRole('role');
    const message = interaction.options.getString('message');
    const embedTitle = interaction.options.getString('embed_title');

    const members = role.members;
    let sent = 0, failed = 0;

    await interaction.editReply({ content: `📤 Sending DMs to ${members.size} members with ${role}...` });

    const membersArray = [...members.values()];

    // Send in batches of 10 with 1s delay
    for (let i = 0; i < membersArray.length; i += 10) {
      const batch = membersArray.slice(i, i + 10);

      await Promise.all(batch.map(async (member) => {
        try {
          if (member.user.bot) return;

          const payload = {};
          if (embedTitle) {
            payload.embeds = [new EmbedBuilder().setTitle(embedTitle).setDescription(message).setColor(0x3b82f6).setFooter({ text: interaction.guild.name }).setTimestamp()];
          } else {
            payload.content = message;
          }

          await member.send(payload);
          sent++;
        } catch {
          failed++;
        }
      }));

      if (i + 10 < membersArray.length) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }

    await prisma.dMLog.create({
      data: {
        guildId: interaction.guildId,
        senderId: interaction.user.id,
        targetType: 'role',
        targetId: role.id,
        content: message,
        sentCount: sent,
        failedCount: failed,
      },
    });

    emitDMLog({ guildId: interaction.guildId, targetType: 'role', targetId: role.id, content: message, sentCount: sent, failedCount: failed });

    await interaction.editReply({
      embeds: [successEmbed('DM Role Complete', `Sent to **${sent}** members.\nFailed: **${failed}**`)],
    });
  },
};
