const { trackBan, revertActions } = require('../utils/revertAction');
const { emitAction } = require('../utils/socketEmitter');
const logger = require('../utils/logger');

const banTracker = new Map();

function trackUserAction(guildId, userId, threshold, interval) {
  const key = `${guildId}:${userId}:ban`;
  const now = Date.now();
  const tracker = banTracker.get(key) || { timestamps: [] };
  tracker.timestamps = tracker.timestamps.filter(t => now - t < interval);
  tracker.timestamps.push(now);
  banTracker.set(key, tracker);
  return tracker.timestamps.length >= threshold;
}

module.exports = {
  name: 'guildBanAdd',
  async execute(ban, client, prisma) {
    const guildId = ban.guild.id;
    const cache = client.configCache.get(guildId);
    const security = cache?.security;

    // Track for potential revert
    trackBan(guildId, ban.user.id);

    if (!security?.antiNukeEnabled) return;

    let perpetratorId = null;
    try {
      const logs = await ban.guild.fetchAuditLogs({ type: 22, limit: 1 }); // MEMBER_BAN_ADD = 22
      const entry = logs.entries.first();
      if (entry && Date.now() - entry.createdTimestamp < 5000) {
        perpetratorId = entry.executor?.id;
      }
    } catch (_) {}

    if (!perpetratorId || perpetratorId === client.user.id) return;

    const isWhitelisted =
      security.whitelistedUsers.includes(perpetratorId) ||
      ban.guild.members.cache.get(perpetratorId)?.roles.cache.some(r =>
        security.whitelistedRoles.includes(r.id)
      );

    if (isWhitelisted) return;

    const exceeded = trackUserAction(guildId, perpetratorId, security.antiNukeThreshold, 10000);

    if (exceeded) {
      logger.warn(`Anti-nuke triggered (guildBanAdd): ${perpetratorId} in ${guildId}`);

      const member = ban.guild.members.cache.get(perpetratorId);
      if (member) {
        try {
          switch (security.antiNukeAction) {
            case 'ban':
              await ban.guild.members.ban(perpetratorId, { reason: 'Anti-nuke: mass ban detected' });
              break;
            case 'kick':
              await member.kick('Anti-nuke: mass ban detected');
              break;
            case 'strip_roles':
              const roles = member.roles.cache.filter(r => r.id !== ban.guild.roles.everyone.id);
              await member.roles.remove(roles, 'Anti-nuke: strip roles');
              break;
          }
        } catch (err) {
          logger.error('Anti-nuke action failed:', err.message);
        }
      }

      if (security.autoRevertEnabled) {
        const reverted = await revertActions(ban.guild, perpetratorId);
        logger.info(`Reverted: ${reverted.join(', ')}`);
      }

      if (security.logChannelId) {
        const logChannel = ban.guild.channels.cache.get(security.logChannelId);
        logChannel?.send({ content: `🛡️ **Anti-Nuke** — <@${perpetratorId}> mass-banned members. Action: **${security.antiNukeAction}**` }).catch(() => {});
      }

      emitAction({ type: 'anti_nuke', guildId, perpetratorId, action: security.antiNukeAction, description: 'Mass ban detected' });
      banTracker.delete(`${guildId}:${perpetratorId}:ban`);
    }
  },
};
