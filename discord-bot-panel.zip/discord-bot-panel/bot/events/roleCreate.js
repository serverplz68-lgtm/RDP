module.exports = {
  name: 'roleCreate',
  async execute(role, client, prisma) {
    // Future: track rapid role creation for anti-nuke
  },
};
