const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('badwords')
    .setDescription('Manage the bad words filter')
    .addSubcommand(s => s.setName('enable').setDescription('Enable filter'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable filter'))
    .addSubcommand(s => s.setName('list').setDescription('List filtered words'))
    .addSubcommand(s => s.setName('add').setDescription('Add a word').addStringOption(o => o.setName('word').setDescription('Word to add').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a word').addStringOption(o => o.setName('word').setDescription('Word to remove').setRequired(true)))
    .addSubcommand(s =>
      s.setName('action').setDescription('Set action')
        .addStringOption(o =>
          o.setName('type').setDescription('Action').setRequired(true)
            .addChoices({ name: 'Delete', value: 'delete' }, { name: 'Timeout', value: 'timeout' }, { name: 'Warn', value: 'warn' })
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;

    const current = await prisma.securityConfig.findUnique({ where: { guildId } });
    const currentList = current?.badWordsList || [];

    if (sub === 'enable') {
      await upsert(prisma, guildId, { badWordsEnabled: true });
    } else if (sub === 'disable') {
      await upsert(prisma, guildId, { badWordsEnabled: false });
    } else if (sub === 'list') {
      return interaction.editReply({
        embeds: [createEmbed({ title: '🚫 Bad Words List', description: currentList.length ? currentList.map(w => `\`${w}\``).join(', ') : 'No words added.', color: 0x3b82f6 })],
      });
    } else if (sub === 'add') {
      const word = interaction.options.getString('word').toLowerCase();
      if (!currentList.includes(word)) {
        await upsert(prisma, guildId, { badWordsList: [...currentList, word] });
      }
    } else if (sub === 'remove') {
      const word = interaction.options.getString('word').toLowerCase();
      await upsert(prisma, guildId, { badWordsList: currentList.filter(w => w !== word) });
    } else if (sub === 'action') {
      const type = interaction.options.getString('type');
      await upsert(prisma, guildId, { badWordsAction: type });
    }

    const cfg = await prisma.securityConfig.findUnique({ where: { guildId } });
    const cache = client.configCache.get(guildId) || {};
    client.configCache.set(guildId, { ...cache, security: cfg });

    await interaction.editReply({ embeds: [successEmbed('Bad Words Updated', 'Filter settings have been updated.')] });
  },
};

async function upsert(prisma, guildId, data) {
  await prisma.securityConfig.upsert({ where: { guildId }, update: data, create: { guildId, ...data } });
}
