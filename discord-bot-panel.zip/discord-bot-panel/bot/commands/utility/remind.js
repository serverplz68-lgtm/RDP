const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed, createEmbed } = require('../../utils/embed');

function parseDuration(str) {
  const match = str.match(/^(\d+)(s|m|h|d|w)$/);
  if (!match) return null;
  const [, num, unit] = match;
  const map = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000 };
  return parseInt(num) * map[unit];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Set a reminder')
    .addSubcommand(s =>
      s.setName('set')
        .setDescription('Create a reminder')
        .addStringOption(o => o.setName('time').setDescription('When? (e.g. 30m, 2h, 1d)').setRequired(true))
        .addStringOption(o => o.setName('message').setDescription('Reminder message').setRequired(true))
    )
    .addSubcommand(s => s.setName('list').setDescription('View your active reminders'))
    .addSubcommand(s =>
      s.setName('cancel')
        .setDescription('Cancel a reminder')
        .addStringOption(o => o.setName('id').setDescription('Reminder ID').setRequired(true))
    ),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const timeStr = interaction.options.getString('time');
      const message = interaction.options.getString('message');

      const ms = parseDuration(timeStr);
      if (!ms) return interaction.editReply({ embeds: [errorEmbed('Invalid Time', 'Use formats like `30m`, `2h`, `1d`.')] });

      const remindAt = new Date(Date.now() + ms);

      await prisma.reminder.create({
        data: {
          guildId: interaction.guildId,
          userId: interaction.user.id,
          channelId: interaction.channelId,
          message,
          remindAt,
        },
      });

      await interaction.editReply({
        embeds: [successEmbed('Reminder Set', `I'll remind you in **${timeStr}**.\n**Message:** ${message}\n**At:** <t:${Math.floor(remindAt.getTime() / 1000)}:F>`)],
      });
    }

    if (sub === 'list') {
      const reminders = await prisma.reminder.findMany({
        where: { userId: interaction.user.id, guildId: interaction.guildId, sent: false },
        orderBy: { remindAt: 'asc' },
      });

      if (!reminders.length) {
        return interaction.editReply({ embeds: [createEmbed({ title: '⏰ Reminders', description: 'You have no active reminders.', color: 0x3b82f6 })] });
      }

      const fields = reminders.map(r => ({
        name: `ID: \`${r.id.slice(-8)}\``,
        value: `**Message:** ${r.message}\n**Due:** <t:${Math.floor(new Date(r.remindAt).getTime() / 1000)}:R>`,
      }));

      await interaction.editReply({ embeds: [createEmbed({ title: '⏰ Your Reminders', fields, color: 0x3b82f6 })] });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getString('id');
      const reminder = await prisma.reminder.findFirst({
        where: { userId: interaction.user.id, guildId: interaction.guildId, id: { endsWith: id } },
      });

      if (!reminder) return interaction.editReply({ embeds: [errorEmbed('Not Found', 'Reminder not found.')] });

      await prisma.reminder.delete({ where: { id: reminder.id } });
      await interaction.editReply({ embeds: [successEmbed('Reminder Cancelled', 'The reminder has been deleted.')] });
    }
  },
};
