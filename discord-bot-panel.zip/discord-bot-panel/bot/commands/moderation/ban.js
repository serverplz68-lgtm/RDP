const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { emitAction } = require('../../utils/socketEmitter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for ban').setRequired(false))
    .addIntegerOption(o => o.setName('delete_days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7).setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const deleteDays = interaction.options.getInteger('delete_days') ?? 0;

    if (target.id === interaction.user.id) {
      return interaction.editReply({ embeds: [errorEmbed('Cannot Ban', 'You cannot ban yourself.')] });
    }

    if (target.id === client.user.id) {
      return interaction.editReply({ embeds: [errorEmbed('Cannot Ban', 'I cannot ban myself.')] });
    }

    try {
      const member = interaction.guild.members.cache.get(target.id);
      if (member) {
        if (!member.bannable) {
          return interaction.editReply({ embeds: [errorEmbed('Cannot Ban', 'I do not have permission to ban this user.')] });
        }
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
          return interaction.editReply({ embeds: [errorEmbed('Cannot Ban', 'You cannot ban someone with an equal or higher role.')] });
        }
      }

      await interaction.guild.members.ban(target.id, {
        reason: `${interaction.user.tag}: ${reason}`,
        deleteMessageDays: deleteDays,
      });

      await prisma.warning.create({
        data: {
          guildId: interaction.guildId,
          userId: target.id,
          moderatorId: interaction.user.id,
          reason: `[BAN] ${reason}`,
        },
      }).catch(() => {});

      emitAction({
        type: 'ban',
        guildId: interaction.guildId,
        targetId: target.id,
        moderatorId: interaction.user.id,
        reason,
        description: `${interaction.user.username} banned ${target.username}: ${reason}`,
      });

      await interaction.editReply({
        embeds: [successEmbed('User Banned', `**${target.tag}** has been banned.\n**Reason:** ${reason}`)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Ban Failed', err.message)] });
    }
  },
};
