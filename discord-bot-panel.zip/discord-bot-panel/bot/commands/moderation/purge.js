const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { emitAction } = require('../../utils/socketEmitter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Bulk delete messages')
    .addIntegerOption(o => o.setName('count').setDescription('Number of messages to delete (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('Only delete messages from this user').setRequired(false))
    .addChannelOption(o => o.setName('channel').setDescription('Channel to purge (defaults to current)').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });

    const count = interaction.options.getInteger('count');
    const targetUser = interaction.options.getUser('user');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    try {
      let messages = await channel.messages.fetch({ limit: 100 });

      // Filter to messages younger than 14 days (Discord limit for bulk delete)
      const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
      messages = messages.filter(m => m.createdTimestamp > twoWeeksAgo);

      if (targetUser) {
        messages = messages.filter(m => m.author.id === targetUser.id);
      }

      const toDelete = [...messages.values()].slice(0, count);

      if (!toDelete.length) {
        return interaction.editReply({ embeds: [errorEmbed('No Messages', 'No messages found to delete within the 14-day limit.')] });
      }

      const deleted = await channel.bulkDelete(toDelete, true);

      emitAction({
        type: 'purge',
        guildId: interaction.guildId,
        moderatorId: interaction.user.id,
        description: `${interaction.user.username} purged ${deleted.size} messages in #${channel.name}`,
      });

      await interaction.editReply({
        embeds: [successEmbed('Messages Purged', `Deleted **${deleted.size}** message(s) from ${channel}${targetUser ? ` by **${targetUser.tag}**` : ''}.`)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Purge Failed', err.message)] });
    }
  },
};
