const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Get info about a user')
    .addUserOption(o => o.setName('user').setDescription('User (defaults to you)').setRequired(false)),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const target = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(target.id);

    const warnings = await prisma.warning.count({ where: { guildId: interaction.guildId, userId: target.id } });
    const statuses = { online: '🟢', idle: '🟡', dnd: '🔴', offline: '⚫' };

    const embed = new EmbedBuilder()
      .setTitle(target.tag)
      .setThumbnail(target.displayAvatarURL({ dynamic: true, size: 256 }))
      .setColor(member?.displayColor || 0x3b82f6)
      .addFields(
        { name: '🆔 ID', value: target.id, inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(target.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '⚠️ Warnings', value: warnings.toString(), inline: true },
      )
      .setTimestamp();

    if (member) {
      embed.addFields(
        { name: '📥 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true },
        { name: '🎭 Highest Role', value: member.roles.highest.toString(), inline: true },
        { name: '🔇 Timed Out', value: member.communicationDisabledUntil ? `Until <t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>` : 'No', inline: true },
      );

      const roles = member.roles.cache.filter(r => r.id !== interaction.guild.roles.everyone.id);
      if (roles.size > 0) {
        embed.addFields({ name: `🎭 Roles [${roles.size}]`, value: [...roles.values()].slice(0, 10).join(' ') + (roles.size > 10 ? `\n+${roles.size - 10} more` : '') });
      }
    }

    await interaction.editReply({ embeds: [embed] });
  },
};
