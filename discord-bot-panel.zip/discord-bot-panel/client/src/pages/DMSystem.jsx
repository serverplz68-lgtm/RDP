export { DMSystem as default } from './CommunityPages.jsx';
