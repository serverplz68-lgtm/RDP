#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# start.sh — Universal launcher (Termux / Linux / macOS / Render)
# Uses run.js (zero npm deps) — no concurrently needed
# ─────────────────────────────────────────────────────────────────────────────
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; MAGENTA='\033[0;35m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo -e "${CYAN}╔══════════════════════════════════════╗"
echo -e "║     Discord Bot Panel Launcher       ║"
echo -e "╚══════════════════════════════════════╝${NC}"
echo ""

# ─── Guards ──────────────────────────────────────────────────────────────────
if [ ! -f ".env" ]; then
  echo -e "${RED}❌  .env not found — copy .env.example and fill in your values${NC}"
  echo -e "    ${YELLOW}cp .env.example .env${NC}"
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo -e "${YELLOW}📦  node_modules missing — running npm install...${NC}"
  npm install
fi

if [ ! -d "client/node_modules" ]; then
  echo -e "${YELLOW}📦  client/node_modules missing — running install...${NC}"
  (cd client && npm install)
fi

if [ ! -d "node_modules/.prisma" ]; then
  echo -e "${YELLOW}🔧  Generating Prisma client...${NC}"
  npx prisma generate
fi

echo ""

# ─── Mode: tmux (best for Termux) ────────────────────────────────────────────
if command -v tmux &>/dev/null; then
  echo -e "${GREEN}✅ tmux found — launching in split panes${NC}"

  SESSION="bot-panel"
  tmux kill-session -t "$SESSION" 2>/dev/null || true
  tmux new-session   -d -s "$SESSION" -x 220 -y 50

  # Top-left: Server
  tmux send-keys -t "$SESSION:0.0" \
    "echo -e '\e[36m[SERVER]\e[0m'; node server/index.js" Enter

  # Top-right: Bot
  tmux split-window -h -t "$SESSION:0.0"
  tmux send-keys -t "$SESSION:0.1" \
    "echo -e '\e[35m[BOT]\e[0m'; node bot/index.js" Enter

  # Bottom: Frontend
  tmux split-window -v -t "$SESSION:0.0"
  tmux send-keys -t "$SESSION:0.2" \
    "echo -e '\e[33m[CLIENT]\e[0m'; cd client && npm run dev" Enter

  tmux select-layout -t "$SESSION:0" main-vertical

  echo ""
  echo -e "  ${CYAN}Server:${NC}    http://localhost:3001"
  echo -e "  ${YELLOW}Dashboard:${NC} http://localhost:5173"
  echo ""
  echo -e "  Detach : ${YELLOW}Ctrl-B then D${NC}"
  echo -e "  Reattach: ${YELLOW}tmux attach -t $SESSION${NC}"
  echo -e "  Kill all: ${RED}tmux kill-session -t $SESSION${NC}"
  echo ""
  tmux attach -t "$SESSION"

# ─── Mode: node run.js (zero extra deps) ─────────────────────────────────────
else
  echo -e "${GREEN}✅ Launching via run.js (no extra packages needed)${NC}"
  echo ""
  echo -e "  ${CYAN}Server:${NC}    http://localhost:3001"
  echo -e "  ${YELLOW}Dashboard:${NC} http://localhost:5173"
  echo ""
  echo -e "${YELLOW}Press Ctrl+C to stop all services${NC}"
  echo ""
  node run.js
fi
