const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { emitAction } = require('../../utils/socketEmitter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const member = interaction.guild.members.cache.get(target.id);
    if (!member) return interaction.editReply({ embeds: [errorEmbed('Not Found', 'Member not found in server.')] });
    if (!member.kickable) return interaction.editReply({ embeds: [errorEmbed('Cannot Kick', 'I cannot kick this user.')] });

    try {
      await member.kick(`${interaction.user.tag}: ${reason}`);
      emitAction({ type: 'kick', guildId: interaction.guildId, targetId: target.id, moderatorId: interaction.user.id, reason, description: `${interaction.user.username} kicked ${target.username}` });
      await interaction.editReply({ embeds: [successEmbed('User Kicked', `**${target.tag}** has been kicked.\n**Reason:** ${reason}`)] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Kick Failed', err.message)] });
    }
  },
};
