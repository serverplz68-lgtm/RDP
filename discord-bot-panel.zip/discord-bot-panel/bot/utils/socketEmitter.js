let _socket = null;

function setSocket(socket) {
  _socket = socket;
}

function getSocket() {
  return _socket;
}

/**
 * Emit a bot action event to the dashboard
 */
function emitAction(action) {
  if (_socket && _socket.connected) {
    _socket.emit('bot:action', {
      ...action,
      timestamp: new Date().toISOString(),
    });
  }
}

/**
 * Emit a ticket event to dashboard
 */
function emitTicketEvent(event, data) {
  if (_socket && _socket.connected) {
    _socket.emit(`bot:ticket:${event}`, { ...data, timestamp: new Date().toISOString() });
  }
}

/**
 * Emit a warning event to dashboard
 */
function emitWarningEvent(data) {
  if (_socket && _socket.connected) {
    _socket.emit('bot:warning:add', { ...data, timestamp: new Date().toISOString() });
  }
}

/**
 * Emit a DM log event
 */
function emitDMLog(data) {
  if (_socket && _socket.connected) {
    _socket.emit('bot:dm:log', { ...data, timestamp: new Date().toISOString() });
  }
}

module.exports = { setSocket, getSocket, emitAction, emitTicketEvent, emitWarningEvent, emitDMLog };
