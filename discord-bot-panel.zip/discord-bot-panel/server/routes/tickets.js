const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');

const router = express.Router();
const prisma = new PrismaClient();
const GUILD_ID = process.env.DISCORD_GUILD_ID;

router.use(isAuthenticated, isAdmin);

router.get('/config', async (req, res) => {
  try {
    const config = await prisma.ticketConfig.findUnique({ where: { guildId: GUILD_ID } });
    res.json(config || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/config', async (req, res) => {
  try {
    const config = await prisma.ticketConfig.upsert({
      where: { guildId: GUILD_ID },
      update: req.body,
      create: { guildId: GUILD_ID, ...req.body },
    });
    if (global.botSocket) {
      global.botSocket.emit('config:tickets:update', { guildId: GUILD_ID, config });
    }
    res.json(config);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/list', async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const where = { guildId: GUILD_ID };
    if (status) where.status = status;

    const [tickets, total] = await Promise.all([
      prisma.ticket.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (parseInt(page) - 1) * parseInt(limit),
        take: parseInt(limit),
      }),
      prisma.ticket.count({ where }),
    ]);

    res.json({ tickets, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/stats', async (req, res) => {
  try {
    const today = new Date(); today.setHours(0, 0, 0, 0);

    const [total, open, closedToday, ratings] = await Promise.all([
      prisma.ticket.count({ where: { guildId: GUILD_ID } }),
      prisma.ticket.count({ where: { guildId: GUILD_ID, status: { in: ['open', 'claimed'] } } }),
      prisma.ticket.count({ where: { guildId: GUILD_ID, status: 'closed', closedAt: { gte: today } } }),
      prisma.ticket.aggregate({ where: { guildId: GUILD_ID, rating: { not: null } }, _avg: { rating: true } }),
    ]);

    res.json({ total, open, closedToday, avgRating: ratings._avg.rating?.toFixed(1) ?? null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/panel/setup', async (req, res) => {
  if (global.botSocket) {
    global.botSocket.emit('dashboard:action', { type: 'setup_ticket_panel', guildId: GUILD_ID });
    res.json({ success: true });
  } else {
    res.status(503).json({ error: 'Bot not connected.' });
  }
});

router.post('/close/:id', async (req, res) => {
  try {
    await prisma.ticket.update({
      where: { id: req.params.id },
      data: { status: 'closed', closedAt: new Date() },
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
