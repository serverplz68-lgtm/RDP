const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription("Get a user's avatar")
    .addUserOption(o => o.setName('user').setDescription('User (defaults to you)').setRequired(false)),

  async execute(interaction, client, prisma) {
    const target = interaction.options.getUser('user') || interaction.user;
    const avatarUrl = target.displayAvatarURL({ dynamic: true, size: 1024 });

    const embed = new EmbedBuilder()
      .setTitle(`${target.username}'s Avatar`)
      .setImage(avatarUrl)
      .setColor(0x3b82f6)
      .addFields(
        { name: '🔗 Links', value: `[PNG](${target.displayAvatarURL({ format: 'png', size: 1024 })}) | [JPG](${target.displayAvatarURL({ format: 'jpg', size: 1024 })}) | [WEBP](${target.displayAvatarURL({ format: 'webp', size: 1024 })})` },
      );

    await interaction.reply({ embeds: [embed] });
  },
};
