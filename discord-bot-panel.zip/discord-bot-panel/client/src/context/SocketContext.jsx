import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const SocketContext = createContext(null);

export function SocketProvider({ children }) {
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [perfData, setPerfData] = useState([]);
  const [activityLog, setActivityLog] = useState([]);
  const [latestStats, setLatestStats] = useState(null);

  useEffect(() => {
    const socket = io('/', { withCredentials: true, transports: ['websocket', 'polling'] });
    socketRef.current = socket;

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    socket.on('perf:snapshot', (data) => setPerfData(data));
    socket.on('activity:snapshot', (data) => setActivityLog(data));

    socket.on('bot:stats:update', (data) => {
      setLatestStats(data);
      setPerfData(prev => {
        const next = [...prev, { ...data, time: new Date().toISOString() }];
        return next.slice(-30);
      });
    });

    socket.on('bot:action:new', (data) => {
      setActivityLog(prev => [data, ...prev].slice(0, 20));
    });

    return () => socket.disconnect();
  }, []);

  return (
    <SocketContext.Provider value={{ socket: socketRef.current, connected, perfData, activityLog, latestStats }}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  return useContext(SocketContext);
}
