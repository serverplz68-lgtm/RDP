const express = require('express');
const { PrismaClient } = require('@prisma/client');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');

const router = express.Router();
const prisma = new PrismaClient();
const GUILD_ID = process.env.DISCORD_GUILD_ID;

router.use(isAuthenticated, isAdmin);

router.get('/config', async (req, res) => {
  try {
    const config = await prisma.communityConfig.findUnique({ where: { guildId: GUILD_ID } });
    res.json(config || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/config', async (req, res) => {
  try {
    const config = await prisma.communityConfig.upsert({
      where: { guildId: GUILD_ID },
      update: req.body,
      create: { guildId: GUILD_ID, ...req.body },
    });
    if (global.botSocket) global.botSocket.emit('config:community:update', { guildId: GUILD_ID, config });
    res.json(config);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/suggestions', async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const where = { guildId: GUILD_ID };
    if (status) where.status = status;

    const [suggestions, total] = await Promise.all([
      prisma.suggestion.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (parseInt(page) - 1) * parseInt(limit), take: parseInt(limit) }),
      prisma.suggestion.count({ where }),
    ]);
    res.json({ suggestions, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/suggestions/:id', async (req, res) => {
  try {
    const { status } = req.body;
    if (!['pending', 'approved', 'denied'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const suggestion = await prisma.suggestion.update({ where: { id: req.params.id }, data: { status } });
    res.json(suggestion);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/afk', async (req, res) => {
  try {
    const afk = await prisma.aFKUser.findMany({ where: { guildId: GUILD_ID }, orderBy: { setAt: 'desc' } });
    res.json(afk);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/afk/:userId', async (req, res) => {
  try {
    await prisma.aFKUser.deleteMany({ where: { guildId: GUILD_ID, userId: req.params.userId } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/birthdays', async (req, res) => {
  try {
    const birthdays = await prisma.birthday.findMany({ where: { guildId: GUILD_ID }, orderBy: [{ month: 'asc' }, { day: 'asc' }] });
    res.json(birthdays);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
