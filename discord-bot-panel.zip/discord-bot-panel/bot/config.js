require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  guildId: process.env.DISCORD_GUILD_ID,
  serverUrl: process.env.SERVER_URL || 'http://localhost:3001',
  botSocketSecret: process.env.BOT_SOCKET_SECRET,
  openWeatherKey: process.env.OPENWEATHER_API_KEY,
  exchangeRateKey: process.env.EXCHANGE_RATE_API_KEY,
  port: process.env.PORT || 3001,
};
