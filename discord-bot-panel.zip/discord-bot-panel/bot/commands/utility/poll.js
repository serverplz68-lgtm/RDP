const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a poll')
    .addStringOption(o => o.setName('question').setDescription('Poll question').setRequired(true))
    .addStringOption(o => o.setName('option1').setDescription('Option 1').setRequired(true))
    .addStringOption(o => o.setName('option2').setDescription('Option 2').setRequired(true))
    .addStringOption(o => o.setName('option3').setDescription('Option 3').setRequired(false))
    .addStringOption(o => o.setName('option4').setDescription('Option 4').setRequired(false)),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();

    const question = interaction.options.getString('question');
    const options = [
      interaction.options.getString('option1'),
      interaction.options.getString('option2'),
      interaction.options.getString('option3'),
      interaction.options.getString('option4'),
    ].filter(Boolean);

    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
    const description = options.map((opt, i) => `${emojis[i]} **${opt}**`).join('\n\n');

    const embed = new EmbedBuilder()
      .setTitle(`📊 ${question}`)
      .setDescription(description)
      .setColor(0x3b82f6)
      .setFooter({ text: `Poll by ${interaction.user.username}` })
      .setTimestamp();

    const rows = [];
    const chunkSize = 4;
    for (let i = 0; i < options.length; i += chunkSize) {
      const row = new ActionRowBuilder();
      for (let j = i; j < Math.min(i + chunkSize, options.length); j++) {
        row.addComponents(
          new ButtonBuilder()
            .setCustomId(`poll_vote:${j}`)
            .setLabel(options[j])
            .setEmoji(emojis[j])
            .setStyle(ButtonStyle.Primary)
        );
      }
      rows.push(row);
    }

    const msg = await interaction.editReply({ embeds: [embed], components: rows });

    // Add emoji reactions as alternative
    for (let i = 0; i < options.length; i++) {
      await msg.react(emojis[i]).catch(() => {});
    }
  },
};
