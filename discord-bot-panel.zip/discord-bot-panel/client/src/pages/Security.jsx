import React, { useState, useEffect } from 'react';
import { Toggle, ChannelSelector, SaveButton } from '../components/UI.jsx';
import { useApi, useSave } from '../hooks/useApi.js';

function Section({ title, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="card" style={{ marginBottom: '1rem' }}>
      <div className="card-header" style={{ cursor: 'pointer' }} onClick={() => setOpen(o => !o)}>
        <h3>{title}</h3>
        <span style={{ color: 'var(--text-muted)', fontSize: '1rem' }}>{open ? '▲' : '▼'}</span>
      </div>
      {open && <div className="card-body">{children}</div>}
    </div>
  );
}

export default function Security() {
  const { data, loading } = useApi('/api/security/config');
  const { save, saving, saved } = useSave('/api/security/config');

  const [cfg, setCfg] = useState({
    antiNukeEnabled: false, antiNukeThreshold: 5, antiNukeAction: 'ban', autoRevertEnabled: true,
    antiSpamEnabled: false, spamThreshold: 5, spamInterval: 5000, spamAction: 'timeout',
    badWordsEnabled: false, badWordsList: [], badWordsAction: 'delete',
    whitelistedUsers: [], whitelistedRoles: [], logChannelId: '',
  });

  const [badWordInput, setBadWordInput] = useState('');

  useEffect(() => { if (data) setCfg({ ...cfg, ...data }); }, [data]);

  const set = (key, val) => setCfg(prev => ({ ...prev, [key]: val }));

  const addBadWord = () => {
    const w = badWordInput.trim().toLowerCase();
    if (w && !cfg.badWordsList.includes(w)) {
      set('badWordsList', [...cfg.badWordsList, w]);
    }
    setBadWordInput('');
  };

  const removeBadWord = (w) => set('badWordsList', cfg.badWordsList.filter(x => x !== w));

  if (loading) return <div style={{ color: 'var(--text-muted)', padding: '2rem' }}>Loading security config...</div>;

  return (
    <div>
      <div className="page-header">
        <h1>🛡️ Advanced Security</h1>
        <p>Configure anti-nuke, anti-spam, bad words filter and whitelists.</p>
      </div>

      {/* Anti-Nuke */}
      <Section title="🔒 Anti-Nuke System">
        <div style={{ display: 'grid', gap: '1rem' }}>
          <Toggle enabled={cfg.antiNukeEnabled} onChange={v => set('antiNukeEnabled', v)} label="Enable Anti-Nuke Protection" />

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Action Threshold</label>
              <input type="number" className="form-control" min={1} max={20} value={cfg.antiNukeThreshold} onChange={e => set('antiNukeThreshold', parseInt(e.target.value))} />
              <p className="text-sm text-muted mt-2">Destructive actions before trigger</p>
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Action to Take</label>
              <select className="form-control" value={cfg.antiNukeAction} onChange={e => set('antiNukeAction', e.target.value)}>
                <option value="ban">🔨 Ban</option>
                <option value="kick">👢 Kick</option>
                <option value="strip_roles">🎭 Strip Roles</option>
              </select>
            </div>
          </div>

          <Toggle enabled={cfg.autoRevertEnabled} onChange={v => set('autoRevertEnabled', v)} label="Auto-Revert Destructive Actions (restore deleted channels/roles, unban members)" />

          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Security Log Channel</label>
            <ChannelSelector value={cfg.logChannelId} onChange={v => set('logChannelId', v)} />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
          </div>
        </div>
      </Section>

      {/* Anti-Spam */}
      <Section title="🚫 Anti-Spam System">
        <div style={{ display: 'grid', gap: '1rem' }}>
          <Toggle enabled={cfg.antiSpamEnabled} onChange={v => set('antiSpamEnabled', v)} label="Enable Anti-Spam" />

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Message Threshold</label>
              <input type="number" className="form-control" min={2} max={20} value={cfg.spamThreshold} onChange={e => set('spamThreshold', parseInt(e.target.value))} />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Time Window (ms)</label>
              <input type="number" className="form-control" min={1000} max={30000} step={500} value={cfg.spamInterval} onChange={e => set('spamInterval', parseInt(e.target.value))} />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Action</label>
              <select className="form-control" value={cfg.spamAction} onChange={e => set('spamAction', e.target.value)}>
                <option value="delete">🗑️ Delete</option>
                <option value="timeout">⏱️ Timeout</option>
                <option value="kick">👢 Kick</option>
                <option value="ban">🔨 Ban</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
          </div>
        </div>
      </Section>

      {/* Bad Words */}
      <Section title="🤬 Bad Words Filter">
        <div style={{ display: 'grid', gap: '1rem' }}>
          <Toggle enabled={cfg.badWordsEnabled} onChange={v => set('badWordsEnabled', v)} label="Enable Bad Words Filter" />

          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Filtered Words</label>
            <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <input
                className="form-control"
                value={badWordInput}
                onChange={e => setBadWordInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addBadWord()}
                placeholder="Type a word and press Enter..."
              />
              <button className="btn btn-ghost" onClick={addBadWord} style={{ flexShrink: 0 }}>Add</button>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem', minHeight: '36px' }}>
              {cfg.badWordsList.map(w => (
                <span key={w} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.2rem 0.625rem', background: 'rgba(239,68,68,0.15)', color: 'var(--danger)', borderRadius: '9999px', fontSize: '0.8125rem', border: '1px solid rgba(239,68,68,0.3)' }}>
                  {w}
                  <button onClick={() => removeBadWord(w)} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', padding: '0', fontSize: '0.875rem', lineHeight: 1 }}>×</button>
                </span>
              ))}
              {cfg.badWordsList.length === 0 && <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>No words added yet.</span>}
            </div>
          </div>

          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Action</label>
            <select className="form-control" value={cfg.badWordsAction} onChange={e => set('badWordsAction', e.target.value)} style={{ maxWidth: '200px' }}>
              <option value="delete">🗑️ Delete Message</option>
              <option value="timeout">⏱️ Timeout User</option>
              <option value="warn">⚠️ Warn User</option>
            </select>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
          </div>
        </div>
      </Section>

      {/* Whitelist */}
      <Section title="✅ Whitelist System">
        <div style={{ display: 'grid', gap: '1rem' }}>
          <p className="text-sm text-muted">Whitelisted users and roles are immune to all security checks.</p>

          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Security Log Channel</label>
            <ChannelSelector value={cfg.logChannelId} onChange={v => set('logChannelId', v)} />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
          </div>
        </div>
      </Section>
    </div>
  );
}
