const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clearwarnings')
    .setDescription('Clear all warnings for a user')
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const target = interaction.options.getUser('user');

    const result = await prisma.warning.deleteMany({ where: { guildId: interaction.guildId, userId: target.id } });

    await interaction.editReply({
      embeds: [successEmbed('Warnings Cleared', `Cleared **${result.count}** warning(s) for **${target.tag}**.`)],
    });
  },
};
