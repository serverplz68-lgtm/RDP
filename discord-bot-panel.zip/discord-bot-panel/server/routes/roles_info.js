const express = require('express');
const { PrismaClient } = require('@prisma/client');
const axios = require('axios');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');

const routerRoles = express.Router();
const routerInfo = express.Router();
const prisma = new PrismaClient();
const GUILD_ID = process.env.DISCORD_GUILD_ID;

const discordApi = axios.create({
  baseURL: 'https://discord.com/api/v10',
  headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` },
});

// ════ ROLES ROUTER ════════════════════════════════════════════════════════

routerRoles.use(isAuthenticated, isAdmin);

routerRoles.get('/config', async (req, res) => {
  try {
    const config = await prisma.roleConfig.findUnique({ where: { guildId: GUILD_ID } });
    res.json(config || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerRoles.patch('/config', async (req, res) => {
  try {
    const config = await prisma.roleConfig.upsert({
      where: { guildId: GUILD_ID },
      update: req.body,
      create: { guildId: GUILD_ID, ...req.body },
    });
    if (global.botSocket) global.botSocket.emit('config:roles:update', { guildId: GUILD_ID, config });
    res.json(config);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerRoles.get('/starboard', async (req, res) => {
  try {
    const posts = await prisma.starboardPost.findMany({
      where: { guildId: GUILD_ID },
      orderBy: { starCount: 'desc' },
      take: 20,
    });
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerRoles.get('/autopublish', async (req, res) => {
  try {
    const channels = await prisma.autoPublishChannel.findMany({ where: { guildId: GUILD_ID } });
    res.json(channels.map(c => c.channelId));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerRoles.post('/autopublish/:channelId', async (req, res) => {
  try {
    await prisma.autoPublishChannel.upsert({
      where: { guildId_channelId: { guildId: GUILD_ID, channelId: req.params.channelId } },
      update: {},
      create: { guildId: GUILD_ID, channelId: req.params.channelId },
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerRoles.delete('/autopublish/:channelId', async (req, res) => {
  try {
    await prisma.autoPublishChannel.deleteMany({ where: { guildId: GUILD_ID, channelId: req.params.channelId } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════ INFO ROUTER ══════════════════════════════════════════════════════════

routerInfo.use(isAuthenticated, isAdmin);

routerInfo.get('/guild', async (req, res) => {
  try {
    const { data } = await discordApi.get(`/guilds/${GUILD_ID}?with_counts=true`);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerInfo.get('/channels', async (req, res) => {
  try {
    const { data } = await discordApi.get(`/guilds/${GUILD_ID}/channels`);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerInfo.get('/roles', async (req, res) => {
  try {
    const { data } = await discordApi.get(`/guilds/${GUILD_ID}/roles`);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerInfo.get('/members', async (req, res) => {
  try {
    const { limit = 100, after } = req.query;
    const url = `/guilds/${GUILD_ID}/members?limit=${limit}${after ? `&after=${after}` : ''}`;
    const { data } = await discordApi.get(url);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

routerInfo.get('/member-snapshots', async (req, res) => {
  try {
    const days = parseInt(req.query.days || '30');
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const snapshots = await prisma.memberSnapshot.findMany({
      where: { guildId: GUILD_ID, recordedAt: { gte: since } },
      orderBy: { recordedAt: 'asc' },
    });
    res.json(snapshots);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = { routerRoles, routerInfo };
