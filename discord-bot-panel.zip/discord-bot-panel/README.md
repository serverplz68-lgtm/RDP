# 🤖 Discord Bot Management System

A full-stack Discord bot management system with a real-time web dashboard, built with Node.js, Discord.js v14, React, and PostgreSQL.

---

## 🏗️ Architecture

```
┌─────────────────┐     Socket.io     ┌──────────────────┐     Socket.io     ┌──────────────┐
│  React Dashboard│ ◄───────────────► │  Express Server  │ ◄───────────────► │ Discord Bot  │
│  (Vite + React) │   REST API calls  │  (Node.js + pg)  │   real-time sync  │ (Discord.js) │
└─────────────────┘                   └──────────────────┘                   └──────────────┘
                                               │
                                               ▼
                                       ┌──────────────┐
                                       │  PostgreSQL  │
                                       │  + Prisma    │
                                       └──────────────┘
```

---

## 📁 Project Structure

```
discord-bot-panel/
├── bot/                        # Discord Bot (Discord.js v14)
│   ├── index.js                # Bot entry, slash command registration
│   ├── config.js               # Env config
│   ├── events/                 # Discord event handlers
│   │   ├── ready.js            # Config cache loader
│   │   ├── interactionCreate.js# Slash cmds, buttons, modals
│   │   ├── messageCreate.js    # Anti-spam, bad words, custom cmds, AFK
│   │   ├── guildMemberAdd.js   # Auto-role, welcome, unverified role
│   │   ├── guildMemberRemove.js# Goodbye messages
│   │   ├── channelDelete.js    # Anti-nuke detection + revert
│   │   ├── roleDelete.js       # Anti-nuke detection + revert
│   │   └── guildBanAdd.js      # Anti-nuke mass ban detection
│   ├── commands/
│   │   ├── moderation/         # /ban /kick /timeout /warn /warnings /clearwarnings /purge
│   │   ├── security/           # /antinuke /antispam /badwords /whitelist
│   │   ├── dm/                 # /dm /dmrole /dmall
│   │   ├── community/          # /afk /birthday /suggest /giveaway
│   │   ├── utility/            # /weather /translate /currency /qr /poll /remind
│   │   ├── info/               # /serverinfo /userinfo /roleinfo /avatar /botstats
│   │   └── roles/              # /autorole /verify /starboard
│   └── utils/
│       ├── embed.js            # Embed builder helpers
│       ├── logger.js           # Colored console logger
│       ├── socketEmitter.js    # Bot → server event emitter
│       └── revertAction.js     # Anti-nuke revert logic
│
├── server/                     # Express Backend
│   ├── index.js                # Server entry, Socket.io, sessions
│   ├── routes/
│   │   ├── auth.js             # Discord OAuth2 login/logout/me
│   │   ├── dashboard.js        # Stats, performance, activity
│   │   ├── security.js         # Security config CRUD
│   │   ├── moderation.js       # Moderation config + quick actions
│   │   ├── dm.js               # DM logs + send
│   │   ├── tickets.js          # Ticket config + management
│   │   ├── community.js        # Community config, AFK, suggestions
│   │   ├── utility.js          # Custom cmds, monitors, giveaways
│   │   ├── roles.js            # Role config, starboard, auto-publish
│   │   └── info.js             # Guild info, channels, roles, members
│   ├── middleware/
│   │   ├── isAuthenticated.js
│   │   ├── isAdmin.js
│   │   └── rateLimiter.js
│   └── socket/
│       └── handlers.js         # Bot ↔ Dashboard real-time bridge
│
├── prisma/
│   └── schema.prisma           # Full PostgreSQL schema
│
├── client/                     # React Frontend (Vite)
│   └── src/
│       ├── context/
│       │   ├── AuthContext.jsx # Session/user state
│       │   └── SocketContext.jsx# Socket.io + live data
│       ├── hooks/
│       │   └── useApi.js       # useFetch + useSave hooks
│       ├── components/
│       │   ├── Sidebar.jsx     # Navigation sidebar
│       │   ├── Toast.jsx       # Global toast notifications
│       │   └── UI.jsx          # Toggle, StatCard, Modal, Table, EmbedBuilder...
│       └── pages/
│           ├── Login.jsx       ├── Unauthorized.jsx
│           ├── Dashboard.jsx   ├── Security.jsx
│           ├── Moderation.jsx  ├── DMSystem.jsx
│           ├── Tickets.jsx     ├── Community.jsx
│           ├── UtilityCommands.jsx ├── Information.jsx
│           └── RoleManagement.jsx
│
├── .env.example
├── package.json
└── README.md
```

---

## 🚀 Setup Guide

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- A Discord Application with a bot token

### 1. Clone & Install

```bash
git clone <your-repo>
cd discord-bot-panel
npm install
cd client && npm install && cd ..
```

### 2. Environment Variables

```bash
cp .env.example .env
```

Fill in your `.env`:

```env
# Discord Bot
DISCORD_TOKEN=            # Bot token from Discord Developer Portal
DISCORD_CLIENT_ID=        # Application ID
DISCORD_CLIENT_SECRET=    # OAuth2 secret
DISCORD_CALLBACK_URL=http://localhost:3001/auth/discord/callback
DISCORD_GUILD_ID=         # Your server ID

# Database
DATABASE_URL=postgresql://postgres:password@localhost:5432/discordbot

# Security
SESSION_SECRET=change_this_random_string_32chars
BOT_SOCKET_SECRET=another_random_secret_for_bot_socket

# APIs (optional)
OPENWEATHER_API_KEY=      # For /weather command
EXCHANGE_RATE_API_KEY=    # For /currency command
```

### 3. Discord Developer Portal Setup

1. Go to https://discord.com/developers/applications
2. Create a new application
3. Under **Bot**: Enable all Privileged Gateway Intents (Presence, Server Members, Message Content)
4. Under **OAuth2 → Redirects**: Add `http://localhost:3001/auth/discord/callback`
5. Invite the bot with these permissions:
   - Administrator (recommended) or individual permissions:
   - Manage Guild, Manage Channels, Manage Roles, Ban Members, Kick Members, Moderate Members, Manage Messages, Read Messages, Send Messages, Embed Links, Attach Files, Use Slash Commands

### 4. Database Setup

```bash
# Create the database
createdb discordbot

# Run migrations
npx prisma migrate dev --name init

# Generate Prisma client
npx prisma generate
```

### 5. Run the Project

Open three terminals:

```bash
# Terminal 1: Start the backend server
node server/index.js

# Terminal 2: Start the Discord bot
node bot/index.js

# Terminal 3: Start the frontend dev server
cd client && npm run dev
```

Open http://localhost:5173 and log in with Discord.

---

## 🌟 Features

### 🛡️ Security
- **Anti-Nuke**: Detects mass channel/role deletions and bans, auto-reverts destructive actions
- **Anti-Spam**: Rate-limiting with configurable thresholds and actions
- **Bad Words Filter**: Custom word list with delete/timeout/warn actions
- **Whitelist**: Exempt trusted users and roles from all security checks

### ⚖️ Moderation
- `/ban`, `/kick`, `/timeout`, `/warn`, `/warnings`, `/clearwarnings`, `/purge`
- Warning system with configurable auto-action on max warnings
- Dashboard quick actions: ban/kick/timeout/purge via web UI
- Audit log channel support

### ✉️ DM System
- DM individual users with optional rich embeds
- DM all members with a specific role (batched, rate-limit safe)
- DM all server members (requires CONFIRM)
- Full DM log history in dashboard

### 🎫 Ticket System
- Multi-type ticket panel with buttons
- Auto-create private channels with role permissions
- Staff claim/close/transcript features
- Post-close rating system (1-5 stars via DM)
- Dashboard stats: open count, avg rating, tickets per day

### 👥 Community
- Welcome/goodbye messages with variable substitution (`{user}`, `{server}`, `{count}`)
- Birthday tracking with daily announcements and optional birthday role
- AFK system with mention notifications
- Suggestion system with up/downvote buttons and approve/deny workflow

### 🔧 Utility
- `/weather` — OpenWeather API integration
- `/translate` — MyMemory API (free, no key needed)
- `/currency` — Exchange rate conversion
- `/qr` — QR code generation with custom colors
- `/poll` — Multi-option polls with button voting
- `/remind` — Persistent reminders stored in DB
- Custom prefix commands via dashboard
- Website uptime monitors with Discord alerts

### 🎭 Roles
- Auto-role assignment on member join
- Full verification system (unverified → verify → verified role)
- Starboard with configurable star threshold
- Auto-publish for announcement channels

### 📊 Real-time Dashboard
- Live bot ping, uptime, memory, CPU charts
- WebSocket-powered: all config changes propagate to bot in < 500ms
- Recent activity feed
- Responsive sidebar navigation

---

## 🔄 Real-time Flow

```
Config change in Dashboard:
  PATCH /api/security/config
    → DB updated
    → io.emit('config:security:update', { guildId, config })
      → Bot receives via socket, updates in-memory cache
        → socket.emit('bot:config:confirmed')
          → Toast: "Changes applied to bot ✓"

Bot event (e.g. new ticket):
  Bot creates ticket channel
    → socketEmitter.emitTicketEvent('create', ticketData)
      → Server stores in DB
        → io.emit('ticket:created', ticketData)
          → Dashboard table updates live
```

---

## 🔒 Security Features

- All API routes protected with `isAuthenticated` + `isAdmin` middleware
- Admin check uses Discord API (guild member permissions) on OAuth callback
- Rate limiting: 100 req/15min global, 10 req/hour for DM endpoints
- Bot socket authentication via secret token
- HttpOnly session cookies with CSRF protection
- Input validation on all PATCH/POST endpoints via `express-validator`

---

## 🤝 Contributing

PRs welcome. Please ensure:
- No hardcoded secrets
- All new commands registered via `SlashCommandBuilder`
- New DB models added to `prisma/schema.prisma` with migration
- Frontend components use CSS variables only (no hardcoded hex colors)
