const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit a suggestion for the server'),

  async execute(interaction, client, prisma) {
    const cache = client.configCache.get(interaction.guildId);
    if (!cache?.community?.suggestionEnabled) {
      return interaction.reply({ embeds: [errorEmbed('Disabled', 'Suggestions are not enabled on this server.')], ephemeral: true });
    }

    const modal = new ModalBuilder()
      .setCustomId('suggest_modal')
      .setTitle('Submit a Suggestion');

    const input = new TextInputBuilder()
      .setCustomId('suggestion')
      .setLabel('Your suggestion')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1000)
      .setPlaceholder('Describe your suggestion in detail...');

    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },
};
