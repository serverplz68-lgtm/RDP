#!/usr/bin/env bash
# stop.sh — Kill all background processes started by start.sh (bg mode)

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'

echo -e "${RED}Stopping Discord Bot Panel...${NC}"

for svc in server bot client; do
  PID_FILE=".pid_$svc"
  if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill "$PID" 2>/dev/null; then
      echo -e "  ${GREEN}Stopped $svc (PID $PID)${NC}"
    else
      echo -e "  $svc was not running"
    fi
    rm -f "$PID_FILE"
  fi
done

echo -e "${GREEN}Done.${NC}"
