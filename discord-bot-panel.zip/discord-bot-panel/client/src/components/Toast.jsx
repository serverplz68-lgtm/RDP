import React, { useState, useEffect, useCallback } from 'react';

// Global toast event bus
const listeners = new Set();

export function showToast(message, type = 'info') {
  const toast = { id: Date.now() + Math.random(), message, type };
  listeners.forEach(fn => fn(toast));
}

export default function Toast() {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    const handler = (toast) => {
      setToasts(prev => [...prev, toast]);
      setTimeout(() => {
        setToasts(prev => prev.filter(t => t.id !== toast.id));
      }, 3500);
    };
    listeners.add(handler);
    return () => listeners.delete(handler);
  }, []);

  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };

  return (
    <div className="toast-container">
      {toasts.map(toast => (
        <div key={toast.id} className={`toast ${toast.type}`}>
          <span>{icons[toast.type] || 'ℹ️'}</span>
          <span>{toast.message}</span>
          <button
            onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
            style={{ marginLeft: 'auto', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '1rem', padding: '0 0.25rem', minHeight: '44px', minWidth: '44px' }}
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}
