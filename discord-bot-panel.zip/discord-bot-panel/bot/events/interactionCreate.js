const { InteractionType, ComponentType } = require('discord.js');
const { errorEmbed } = require('../utils/embed');
const logger = require('../utils/logger');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client, prisma) {
    // ─── Slash Commands ─────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction, client, prisma);
      } catch (err) {
        logger.error(`Error executing /${interaction.commandName}:`, err);
        const embed = errorEmbed('Command Error', 'An unexpected error occurred while executing this command.');
        try {
          if (interaction.replied || interaction.deferred) {
            await interaction.editReply({ embeds: [embed], ephemeral: true });
          } else {
            await interaction.reply({ embeds: [embed], ephemeral: true });
          }
        } catch (_) {}
      }
      return;
    }

    // ─── Button Interactions ────────────────────────────────────────────────
    if (interaction.isButton()) {
      const [action, ...args] = interaction.customId.split(':');

      switch (action) {
        case 'ticket_create':
          await handleTicketCreate(interaction, client, prisma, args);
          break;
        case 'ticket_close':
          await handleTicketClose(interaction, client, prisma, args);
          break;
        case 'ticket_claim':
          await handleTicketClaim(interaction, client, prisma, args);
          break;
        case 'ticket_transcript':
          await handleTicketTranscript(interaction, client, prisma, args);
          break;
        case 'ticket_rate':
          await handleTicketRate(interaction, client, prisma, args);
          break;
        case 'giveaway_enter':
          await handleGiveawayEnter(interaction, client, prisma, args);
          break;
        case 'verify':
          await handleVerify(interaction, client, prisma);
          break;
        case 'suggest_vote':
          await handleSuggestionVote(interaction, client, prisma, args);
          break;
        case 'poll_vote':
          await handlePollVote(interaction, client, prisma, args);
          break;
        default:
          break;
      }
      return;
    }

    // ─── Select Menu ────────────────────────────────────────────────────────
    if (interaction.isStringSelectMenu()) {
      if (interaction.customId.startsWith('ticket_type:')) {
        await handleTicketTypeSelect(interaction, client, prisma);
      }
    }

    // ─── Modal Submit ────────────────────────────────────────────────────────
    if (interaction.type === InteractionType.ModalSubmit) {
      if (interaction.customId.startsWith('ticket_modal:')) {
        await handleTicketModal(interaction, client, prisma);
      } else if (interaction.customId.startsWith('suggest_modal')) {
        await handleSuggestModal(interaction, client, prisma);
      } else if (interaction.customId.startsWith('giveaway_modal')) {
        await handleGiveawayModal(interaction, client, prisma);
      }
    }
  },
};

// ─── Button Handlers ──────────────────────────────────────────────────────

async function handleTicketClose(interaction, client, prisma, args) {
  try {
    const ticket = await prisma.ticket.findUnique({
      where: { channelId: interaction.channelId },
    });

    if (!ticket) {
      return interaction.reply({ content: 'This is not a ticket channel.', ephemeral: true });
    }

    await interaction.reply({ content: '🔒 Closing ticket in 5 seconds...', ephemeral: false });

    setTimeout(async () => {
      try {
        await prisma.ticket.update({
          where: { id: ticket.id },
          data: { status: 'closed', closedAt: new Date() },
        });

        // Send rating DM
        const user = await client.users.fetch(ticket.userId).catch(() => null);
        if (user) {
          const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
          const ratingEmbed = new EmbedBuilder()
            .setTitle('How was your support experience?')
            .setDescription('Please rate your ticket experience from 1-5 stars.')
            .setColor(0x3b82f6);

          const row = new ActionRowBuilder().addComponents(
            [1, 2, 3, 4, 5].map(n =>
              new ButtonBuilder()
                .setCustomId(`ticket_rate:${ticket.id}:${n}`)
                .setLabel(`${'⭐'.repeat(n)}`)
                .setStyle(ButtonStyle.Secondary)
            )
          );

          await user.send({ embeds: [ratingEmbed], components: [row] }).catch(() => {});
        }

        await interaction.channel.delete('Ticket closed').catch(() => {});
      } catch (err) {
        logger.error('Error during ticket close:', err);
      }
    }, 5000);
  } catch (err) {
    logger.error('handleTicketClose error:', err);
    await interaction.reply({ content: 'Failed to close ticket.', ephemeral: true });
  }
}

async function handleTicketClaim(interaction, client, prisma, args) {
  try {
    const ticket = await prisma.ticket.findUnique({
      where: { channelId: interaction.channelId },
    });

    if (!ticket) return interaction.reply({ content: 'Not a ticket channel.', ephemeral: true });
    if (ticket.claimedBy) {
      return interaction.reply({ content: `This ticket is already claimed by <@${ticket.claimedBy}>.`, ephemeral: true });
    }

    await prisma.ticket.update({
      where: { id: ticket.id },
      data: { claimedBy: interaction.user.id, status: 'claimed' },
    });

    await interaction.reply({ content: `✅ Ticket claimed by <@${interaction.user.id}>.` });
  } catch (err) {
    logger.error('handleTicketClaim error:', err);
    await interaction.reply({ content: 'Failed to claim ticket.', ephemeral: true });
  }
}

async function handleTicketTranscript(interaction, client, prisma, args) {
  await interaction.deferReply({ ephemeral: true });
  try {
    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    const sorted = [...messages.values()].reverse();

    const transcript = sorted
      .map(m => `[${m.createdAt.toISOString()}] ${m.author.username}: ${m.content}${m.embeds.length ? ' [embed]' : ''}`)
      .join('\n');

    const { AttachmentBuilder } = require('discord.js');
    const buffer = Buffer.from(transcript, 'utf-8');
    const attachment = new AttachmentBuilder(buffer, { name: `transcript-${interaction.channelId}.txt` });

    await prisma.ticket.update({
      where: { channelId: interaction.channelId },
      data: { transcript },
    });

    await interaction.editReply({ content: '📄 Transcript generated.', files: [attachment] });
  } catch (err) {
    logger.error('handleTicketTranscript error:', err);
    await interaction.editReply({ content: 'Failed to generate transcript.' });
  }
}

async function handleTicketRate(interaction, client, prisma, [ticketId, rating]) {
  try {
    await prisma.ticket.update({
      where: { id: ticketId },
      data: { rating: parseInt(rating) },
    });
    await interaction.reply({ content: `Thank you for rating your experience ${'⭐'.repeat(parseInt(rating))}!`, ephemeral: true });
  } catch (err) {
    await interaction.reply({ content: 'Failed to submit rating.', ephemeral: true });
  }
}

async function handleVerify(interaction, client, prisma) {
  try {
    const cache = client.configCache.get(interaction.guildId);
    const roleConfig = cache?.roles;

    if (!roleConfig?.verificationEnabled || !roleConfig?.verifiedRoleId) {
      return interaction.reply({ content: 'Verification is not configured.', ephemeral: true });
    }

    const member = interaction.member;
    await member.roles.add(roleConfig.verifiedRoleId);

    if (roleConfig.unverifiedRoleId) {
      await member.roles.remove(roleConfig.unverifiedRoleId).catch(() => {});
    }

    await interaction.reply({ content: '✅ You have been verified! Welcome!', ephemeral: true });
  } catch (err) {
    logger.error('handleVerify error:', err);
    await interaction.reply({ content: 'Failed to verify. Please contact an admin.', ephemeral: true });
  }
}

async function handleGiveawayEnter(interaction, client, prisma, [giveawayId]) {
  try {
    const giveaway = await prisma.giveaway.findUnique({ where: { id: giveawayId } });
    if (!giveaway || giveaway.ended) {
      return interaction.reply({ content: 'This giveaway has ended.', ephemeral: true });
    }

    if (giveaway.requiredRole) {
      const member = interaction.member;
      if (!member.roles.cache.has(giveaway.requiredRole)) {
        const role = interaction.guild.roles.cache.get(giveaway.requiredRole);
        return interaction.reply({
          content: `You need the ${role?.name || 'required'} role to enter this giveaway.`,
          ephemeral: true,
        });
      }
    }

    await interaction.reply({
      content: '🎉 You have entered the giveaway! Good luck!',
      ephemeral: true,
    });
  } catch (err) {
    await interaction.reply({ content: 'Failed to enter giveaway.', ephemeral: true });
  }
}

async function handleSuggestionVote(interaction, client, prisma, [suggestionId, vote]) {
  try {
    const update = vote === 'up' ? { upvotes: { increment: 1 } } : { downvotes: { increment: 1 } };
    await prisma.suggestion.update({ where: { id: suggestionId }, data: update });
    await interaction.reply({ content: `Your ${vote === 'up' ? '👍' : '👎'} vote has been recorded!`, ephemeral: true });
  } catch (err) {
    await interaction.reply({ content: 'Failed to record vote.', ephemeral: true });
  }
}

async function handlePollVote(interaction, client, prisma, args) {
  // Poll votes are tracked via message reactions in this implementation
  await interaction.reply({ content: '✅ Vote recorded!', ephemeral: true });
}

async function handleTicketCreate(interaction, client, prisma, args) {
  // Opens ticket type select menu
  const { ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
  const cache = client.configCache.get(interaction.guildId);
  const ticketConfig = cache?.tickets;

  if (!ticketConfig?.enabled) {
    return interaction.reply({ content: 'Ticket system is not enabled.', ephemeral: true });
  }

  const types = ticketConfig.ticketTypes || [{ name: 'General', value: 'general', emoji: '📋' }];

  const row = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`ticket_type:${interaction.guildId}`)
      .setPlaceholder('Select ticket type...')
      .addOptions(types.map(t => ({
        label: t.name,
        value: t.value || t.name.toLowerCase(),
        emoji: t.emoji || '📋',
        description: t.description || `Open a ${t.name} ticket`,
      })))
  );

  await interaction.reply({ content: 'Select the type of ticket:', components: [row], ephemeral: true });
}

async function handleTicketTypeSelect(interaction, client, prisma) {
  const ticketType = interaction.values[0];

  const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
  const modal = new ModalBuilder()
    .setCustomId(`ticket_modal:${ticketType}`)
    .setTitle('Open a Ticket');

  const issueInput = new TextInputBuilder()
    .setCustomId('issue')
    .setLabel('Describe your issue')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1000);

  modal.addComponents(new ActionRowBuilder().addComponents(issueInput));
  await interaction.showModal(modal);
}

async function handleTicketModal(interaction, client, prisma) {
  await interaction.deferReply({ ephemeral: true });

  try {
    const ticketType = interaction.customId.split(':')[1];
    const issue = interaction.fields.getTextInputValue('issue');
    const guildId = interaction.guildId;
    const userId = interaction.user.id;

    const cache = client.configCache.get(guildId);
    const ticketConfig = cache?.tickets;

    if (!ticketConfig?.categoryId) {
      return interaction.editReply({ content: 'Ticket category is not configured. Please contact an admin.' });
    }

    // Count existing tickets for numbering
    const count = await prisma.ticket.count({ where: { guildId } });
    const channelName = `ticket-${interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '')}-${count + 1}`;

    const { PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

    const channel = await interaction.guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: ticketConfig.categoryId,
      permissionOverwrites: [
        { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
        { id: userId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        ...((ticketConfig.supportRoleIds || []).map(roleId => ({
          id: roleId,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        }))),
      ],
    });

    const ticket = await prisma.ticket.create({
      data: { guildId, channelId: channel.id, userId, type: ticketType, status: 'open' },
    });

    const embed = new EmbedBuilder()
      .setTitle(`Ticket #${count + 1} — ${ticketType}`)
      .setDescription(`**User:** <@${userId}>\n\n**Issue:**\n${issue}`)
      .setColor(0x3b82f6)
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`ticket_close:${ticket.id}`).setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
      new ButtonBuilder().setCustomId(`ticket_claim:${ticket.id}`).setLabel('Claim').setStyle(ButtonStyle.Primary).setEmoji('✋'),
      new ButtonBuilder().setCustomId(`ticket_transcript:${ticket.id}`).setLabel('Transcript').setStyle(ButtonStyle.Secondary).setEmoji('📄'),
    );

    await channel.send({ content: `<@${userId}>`, embeds: [embed], components: [row] });
    await interaction.editReply({ content: `✅ Ticket created: ${channel}` });
  } catch (err) {
    logger.error('handleTicketModal error:', err);
    await interaction.editReply({ content: 'Failed to create ticket.' });
  }
}

async function handleSuggestModal(interaction, client, prisma) {
  const content = interaction.fields.getTextInputValue('suggestion');
  await interaction.deferReply({ ephemeral: true });

  try {
    const cache = client.configCache.get(interaction.guildId);
    const commConfig = cache?.community;

    if (!commConfig?.suggestionEnabled || !commConfig?.suggestionChannelId) {
      return interaction.editReply({ content: 'Suggestion system is not configured.' });
    }

    const channel = interaction.guild.channels.cache.get(commConfig.suggestionChannelId);
    if (!channel) return interaction.editReply({ content: 'Suggestion channel not found.' });

    const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

    const suggestion = await prisma.suggestion.create({
      data: {
        guildId: interaction.guildId,
        userId: interaction.user.id,
        content,
      },
    });

    const embed = new EmbedBuilder()
      .setTitle('💡 New Suggestion')
      .setDescription(content)
      .setColor(0x3b82f6)
      .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp()
      .addFields(
        { name: '👍 Upvotes', value: '0', inline: true },
        { name: '👎 Downvotes', value: '0', inline: true },
        { name: 'Status', value: '⏳ Pending', inline: true }
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`suggest_vote:${suggestion.id}:up`).setLabel('👍 Upvote').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`suggest_vote:${suggestion.id}:down`).setLabel('👎 Downvote').setStyle(ButtonStyle.Danger),
    );

    const msg = await channel.send({ embeds: [embed], components: [row] });
    await prisma.suggestion.update({ where: { id: suggestion.id }, data: { messageId: msg.id } });

    await interaction.editReply({ content: '✅ Suggestion submitted!' });
  } catch (err) {
    logger.error('handleSuggestModal error:', err);
    await interaction.editReply({ content: 'Failed to submit suggestion.' });
  }
}

async function handleGiveawayModal(interaction, client, prisma) {
  // Handled by giveaway command
}
