module.exports = {
  name: 'channelCreate',
  async execute(channel, client, prisma) {
    // Future: handle anti-nuke for rapid channel creation if needed
  },
};
