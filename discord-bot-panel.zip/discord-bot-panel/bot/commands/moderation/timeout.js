const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { emitAction } = require('../../utils/socketEmitter');

const DURATIONS = {
  '60s': 60 * 1000,
  '5m': 5 * 60 * 1000,
  '10m': 10 * 60 * 1000,
  '1h': 60 * 60 * 1000,
  '12h': 12 * 60 * 60 * 1000,
  '1d': 24 * 60 * 60 * 1000,
  '1w': 7 * 24 * 60 * 60 * 1000,
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a member')
    .addUserOption(o => o.setName('user').setDescription('User to timeout').setRequired(true))
    .addStringOption(o =>
      o.setName('duration')
        .setDescription('Duration')
        .setRequired(true)
        .addChoices(
          { name: '60 Seconds', value: '60s' },
          { name: '5 Minutes', value: '5m' },
          { name: '10 Minutes', value: '10m' },
          { name: '1 Hour', value: '1h' },
          { name: '12 Hours', value: '12h' },
          { name: '1 Day', value: '1d' },
          { name: '1 Week', value: '1w' },
        )
    )
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const target = interaction.options.getUser('user');
    const duration = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const member = interaction.guild.members.cache.get(target.id);
    if (!member) return interaction.editReply({ embeds: [errorEmbed('Not Found', 'Member not found.')] });
    if (!member.moderatable) return interaction.editReply({ embeds: [errorEmbed('Cannot Timeout', 'I cannot timeout this user.')] });

    try {
      await member.timeout(DURATIONS[duration], `${interaction.user.tag}: ${reason}`);
      emitAction({ type: 'timeout', guildId: interaction.guildId, targetId: target.id, moderatorId: interaction.user.id, reason, description: `${interaction.user.username} timed out ${target.username} for ${duration}` });
      await interaction.editReply({ embeds: [successEmbed('User Timed Out', `**${target.tag}** timed out for **${duration}**.\n**Reason:** ${reason}`)] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Timeout Failed', err.message)] });
    }
  },
};
