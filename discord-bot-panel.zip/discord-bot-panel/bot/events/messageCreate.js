const logger = require('../utils/logger');

// ─── Anti-Spam Tracking ───────────────────────────────────────────────────
const spamTracker = new Map(); // userId -> { count, timer }

module.exports = {
  name: 'messageCreate',
  async execute(message, client, prisma) {
    if (message.author.bot || !message.guild) return;

    const guildId = message.guild.id;
    const cache = client.configCache.get(guildId);
    if (!cache) return;

    const { security, moderation, customCommands, afkUsers, autoPublishChannels } = cache;

    // ─── Anti-Spam ──────────────────────────────────────────────────────────
    if (security?.antiSpamEnabled) {
      const isWhitelisted =
        security.whitelistedUsers.includes(message.author.id) ||
        message.member?.roles.cache.some(r => security.whitelistedRoles.includes(r.id));

      if (!isWhitelisted) {
        const key = `${guildId}:${message.author.id}`;
        const now = Date.now();
        const tracker = spamTracker.get(key) || { count: 0, firstMessage: now, messages: [] };

        tracker.count++;
        tracker.messages.push(message);

        // Reset window
        if (now - tracker.firstMessage > security.spamInterval) {
          tracker.count = 1;
          tracker.firstMessage = now;
          tracker.messages = [message];
        }

        spamTracker.set(key, tracker);

        if (tracker.count >= security.spamThreshold) {
          spamTracker.delete(key);

          // Delete spam messages
          try {
            for (const msg of tracker.messages) {
              await msg.delete().catch(() => {});
            }
          } catch (_) {}

          switch (security.spamAction) {
            case 'timeout':
              await message.member.timeout(5 * 60 * 1000, 'Anti-spam: message flood').catch(() => {});
              break;
            case 'kick':
              await message.member.kick('Anti-spam: message flood').catch(() => {});
              break;
            case 'ban':
              await message.guild.members.ban(message.author.id, { reason: 'Anti-spam: message flood' }).catch(() => {});
              break;
          }

          await message.channel.send({
            content: `⚠️ <@${message.author.id}> has been ${security.spamAction}ned for spamming.`,
          }).catch(() => {});

          return; // Stop processing this message
        }
      }
    }

    // ─── Bad Words Filter ───────────────────────────────────────────────────
    if (security?.badWordsEnabled && security.badWordsList?.length > 0) {
      const isWhitelisted =
        security.whitelistedUsers.includes(message.author.id) ||
        message.member?.roles.cache.some(r => security.whitelistedRoles.includes(r.id));

      if (!isWhitelisted) {
        const lower = message.content.toLowerCase();
        const hasBadWord = security.badWordsList.some(word => lower.includes(word.toLowerCase()));

        if (hasBadWord) {
          switch (security.badWordsAction) {
            case 'delete':
              await message.delete().catch(() => {});
              break;
            case 'timeout':
              await message.delete().catch(() => {});
              await message.member.timeout(60 * 1000, 'Bad word filter').catch(() => {});
              break;
            case 'warn':
              await message.delete().catch(() => {});
              // Add a warning
              await prisma.warning.create({
                data: {
                  guildId,
                  userId: message.author.id,
                  moderatorId: client.user.id,
                  reason: 'Automatic: bad word filter',
                },
              }).catch(() => {});
              break;
          }
          return;
        }
      }
    }

    // ─── AFK Mentions ───────────────────────────────────────────────────────
    if (afkUsers?.size > 0) {
      // Check if mentioned users are AFK
      for (const mentioned of message.mentions.users.values()) {
        if (afkUsers.has(mentioned.id)) {
          const afkData = afkUsers.get(mentioned.id);
          const timeAgo = Math.round((Date.now() - new Date(afkData.setAt).getTime()) / 60000);
          await message.reply({
            content: `💤 **${mentioned.username}** is AFK${afkData.reason ? `: ${afkData.reason}` : ''} (${timeAgo} min ago)`,
          }).catch(() => {});
        }
      }

      // Check if message author is AFK → remove AFK
      if (afkUsers.has(message.author.id)) {
        afkUsers.delete(message.author.id);
        cache.afkUsers = afkUsers;
        client.configCache.set(guildId, cache);

        await prisma.aFKUser.deleteMany({
          where: { guildId, userId: message.author.id },
        }).catch(() => {});

        await message.reply({ content: `Welcome back, ${message.author}! I've removed your AFK status.` }).catch(() => {});
      }
    }

    // ─── Auto-Publish ───────────────────────────────────────────────────────
    if (autoPublishChannels?.has(message.channelId) && message.channel.type === 5) {
      // ChannelType.GuildAnnouncement = 5
      await message.crosspost().catch(() => {});
    }

    // ─── Custom Commands ────────────────────────────────────────────────────
    if (customCommands?.length > 0) {
      const guildConfig = cache.guild;
      const prefix = guildConfig?.prefix || '!';

      if (message.content.startsWith(prefix)) {
        const trigger = message.content.slice(prefix.length).split(' ')[0].toLowerCase();
        const cmd = customCommands.find(c => c.trigger.toLowerCase() === trigger);

        if (cmd) {
          if (cmd.embedData) {
            try {
              const { EmbedBuilder } = require('discord.js');
              const ed = cmd.embedData;
              const embed = new EmbedBuilder()
                .setTitle(ed.title || null)
                .setDescription(ed.description || null)
                .setColor(ed.color ? parseInt(ed.color.replace('#', ''), 16) : 0x3b82f6);
              await message.channel.send({ embeds: [embed] });
            } catch (_) {
              await message.channel.send({ content: cmd.response });
            }
          } else {
            await message.channel.send({ content: cmd.response });
          }
        }
      }
    }
  },
};
