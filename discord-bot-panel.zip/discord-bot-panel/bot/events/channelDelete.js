const { snapshotChannel, revertActions } = require('../utils/revertAction');
const { emitAction } = require('../utils/socketEmitter');
const logger = require('../utils/logger');

// Per-user action tracking for anti-nuke
const actionTracker = new Map(); // userId -> { count, timestamps: [] }

function trackUserAction(guildId, userId, threshold, interval) {
  const key = `${guildId}:${userId}`;
  const now = Date.now();
  const tracker = actionTracker.get(key) || { count: 0, timestamps: [] };

  // Remove old timestamps outside the window
  tracker.timestamps = tracker.timestamps.filter(t => now - t < interval);
  tracker.timestamps.push(now);
  tracker.count = tracker.timestamps.length;

  actionTracker.set(key, tracker);

  return tracker.count >= threshold;
}

module.exports = {
  name: 'channelDelete',
  async execute(channel, client, prisma) {
    if (!channel.guild) return;

    const guildId = channel.guild.id;
    const cache = client.configCache.get(guildId);
    const security = cache?.security;

    // Always snapshot for potential revert
    snapshotChannel(channel);

    if (!security?.antiNukeEnabled) return;

    // Check who deleted (need audit log)
    let perpetratorId = null;
    try {
      const logs = await channel.guild.fetchAuditLogs({ type: 12, limit: 1 }); // CHANNEL_DELETE = 12
      const entry = logs.entries.first();
      if (entry && Date.now() - entry.createdTimestamp < 5000) {
        perpetratorId = entry.executor?.id;
      }
    } catch (err) {
      logger.warn('Failed to fetch audit log for channelDelete:', err.message);
    }

    if (!perpetratorId || perpetratorId === client.user.id) return;

    // Check whitelist
    const isWhitelisted =
      security.whitelistedUsers.includes(perpetratorId) ||
      channel.guild.members.cache.get(perpetratorId)?.roles.cache.some(r =>
        security.whitelistedRoles.includes(r.id)
      );

    if (isWhitelisted) return;

    const exceeded = trackUserAction(
      guildId,
      perpetratorId,
      security.antiNukeThreshold,
      10000 // 10 second window
    );

    if (exceeded) {
      logger.warn(`Anti-nuke triggered: ${perpetratorId} exceeded channel delete threshold in ${guildId}`);

      const member = channel.guild.members.cache.get(perpetratorId);
      if (member) {
        try {
          switch (security.antiNukeAction) {
            case 'ban':
              await channel.guild.members.ban(perpetratorId, { reason: 'Anti-nuke: excessive channel deletions' });
              break;
            case 'kick':
              await member.kick('Anti-nuke: excessive channel deletions');
              break;
            case 'strip_roles':
              const roles = member.roles.cache.filter(r => r.id !== channel.guild.roles.everyone.id);
              await member.roles.remove(roles, 'Anti-nuke: excessive channel deletions');
              break;
          }
        } catch (err) {
          logger.error('Anti-nuke action failed:', err.message);
        }
      }

      // Auto-revert
      if (security.autoRevertEnabled) {
        const reverted = await revertActions(channel.guild, perpetratorId);
        logger.info(`Anti-nuke revert: ${reverted.join(', ')}`);
      }

      // Log to security channel
      if (security.logChannelId) {
        const logChannel = channel.guild.channels.cache.get(security.logChannelId);
        if (logChannel) {
          await logChannel.send({
            content: `🛡️ **Anti-Nuke Triggered**\nUser <@${perpetratorId}> exceeded channel deletion threshold.\nAction taken: **${security.antiNukeAction}**`,
          }).catch(() => {});
        }
      }

      emitAction({
        type: 'anti_nuke',
        guildId,
        perpetratorId,
        action: security.antiNukeAction,
        description: `Anti-nuke triggered: user ${perpetratorId} mass-deleted channels`,
      });

      // Reset tracker
      actionTracker.delete(`${guildId}:${perpetratorId}`);
    }
  },
};
