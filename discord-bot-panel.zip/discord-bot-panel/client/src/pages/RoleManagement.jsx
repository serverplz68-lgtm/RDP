import React, { useState, useEffect } from 'react';
import { Toggle, ChannelSelector, RoleSelector, SaveButton, Table } from '../components/UI.jsx';
import { useApi, useSave } from '../hooks/useApi.js';
import { showToast } from '../components/Toast.jsx';

export default function RoleManagement() {
  const { data: cfgData, loading } = useApi('/api/roles/config');
  const { data: starboardData } = useApi('/api/roles/starboard');
  const { data: autopublishData, refetch: refetchAP } = useApi('/api/roles/autopublish');
  const { data: channelsData } = useApi('/api/info/channels');
  const { save, saving, saved } = useSave('/api/roles/config');

  const [cfg, setCfg] = useState({
    autoRoleIds: [],
    verificationEnabled: false, verifiedRoleId: '', unverifiedRoleId: '', verifyChannelId: '', verifyMessage: '',
    starboardEnabled: false, starboardChannelId: '', starboardThreshold: 3,
  });

  const set = (k, v) => setCfg(p => ({ ...p, [k]: v }));
  useEffect(() => { if (cfgData) setCfg(p => ({ ...p, ...cfgData })); }, [cfgData]);

  // Announcement channels for auto-publish
  const announcementChannels = (channelsData || []).filter(c => c.type === 5);
  const autoPublishSet = new Set(autopublishData || []);

  const toggleAutoPublish = async (channelId, enabled) => {
    const method = enabled ? 'POST' : 'DELETE';
    const r = await fetch(`/api/roles/autopublish/${channelId}`, { method, credentials: 'include' });
    if (r.ok) { showToast(enabled ? 'Auto-publish enabled' : 'Auto-publish disabled', 'success'); refetchAP(); }
    else showToast('Failed to update', 'error');
  };

  const starCols = [
    { key: 'originalMsgId', label: 'Message ID', render: v => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'authorId', label: 'Author', render: v => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'starCount', label: 'Stars', render: v => <span>⭐ {v}</span> },
    { key: 'createdAt', label: 'Posted', render: v => new Date(v).toLocaleDateString() },
    { key: 'starMsgId', label: 'Board Msg', render: v => v ? <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> : <span className="text-muted">—</span> },
  ];

  if (loading) return <div style={{ color: 'var(--text-muted)', padding: '2rem' }}>Loading role config...</div>;

  return (
    <div>
      <div className="page-header"><h1>🎭 Role Management</h1><p>Configure auto-roles, verification, starboard, and auto-publish.</p></div>

      {/* Auto Role */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>🤖 Auto-Role on Join</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Roles assigned automatically when a member joins</label>
            <RoleSelector value={cfg.autoRoleIds} onChange={v => set('autoRoleIds', v)} multi />
            <p className="text-sm text-muted mt-2">Click a role to toggle it on/off.</p>
          </div>
        </div>
      </div>

      {/* Verification */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>✅ Verification System</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gap: '1rem' }}>
            <Toggle enabled={cfg.verificationEnabled} onChange={v => set('verificationEnabled', v)} label="Enable Verification System" />

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Unverified Role (on join)</label>
                <RoleSelector value={cfg.unverifiedRoleId} onChange={v => set('unverifiedRoleId', v)} placeholder="Select unverified role..." />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Verified Role (after verify)</label>
                <RoleSelector value={cfg.verifiedRoleId} onChange={v => set('verifiedRoleId', v)} placeholder="Select verified role..." />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Verification Channel</label>
                <ChannelSelector value={cfg.verifyChannelId} onChange={v => set('verifyChannelId', v)} />
              </div>
            </div>

            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Verification Message</label>
              <textarea
                className="form-control"
                value={cfg.verifyMessage || ''}
                onChange={e => set('verifyMessage', e.target.value)}
                placeholder="Click the button below to verify and gain access to the server."
                rows={3}
              />
            </div>

            {/* Preview */}
            {cfg.verifyMessage && (
              <div style={{ borderLeft: '4px solid var(--success)', background: '#36393f', borderRadius: '0 var(--radius-md) var(--radius-md) 0', padding: '0.875rem 1rem' }}>
                <div style={{ fontSize: '0.75rem', color: '#b9bbbe', marginBottom: '0.25rem' }}>Preview</div>
                <div style={{ fontSize: '1rem', fontWeight: 700, color: '#fff', marginBottom: '0.25rem' }}>✅ Server Verification</div>
                <div style={{ fontSize: '0.875rem', color: '#dcddde' }}>{cfg.verifyMessage}</div>
                <div style={{ marginTop: '0.75rem' }}>
                  <span style={{ padding: '0.375rem 0.875rem', background: '#57f287', borderRadius: '4px', color: '#000', fontSize: '0.875rem', fontWeight: 600 }}>✅ Verify Me</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Starboard */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>⭐ Starboard</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gap: '1rem', marginBottom: '1.5rem' }}>
            <Toggle enabled={cfg.starboardEnabled} onChange={v => set('starboardEnabled', v)} label="Enable Starboard" />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Starboard Channel</label>
                <ChannelSelector value={cfg.starboardChannelId} onChange={v => set('starboardChannelId', v)} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Minimum Stars to Post</label>
                <input type="number" className="form-control" min={1} max={50} value={cfg.starboardThreshold} onChange={e => set('starboardThreshold', parseInt(e.target.value))} />
              </div>
            </div>
          </div>

          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '1rem' }}>
            <h3 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: '0.75rem' }}>Recent Starboard Posts</h3>
            <Table columns={starCols} data={starboardData || []} pagination pageSize={5} emptyMessage="No starboard posts yet." />
          </div>
        </div>
      </div>

      {/* Auto-Publish */}
      <div className="card">
        <div className="card-header"><h2>📢 Auto-Publish Channels</h2></div>
        <div className="card-body">
          <p className="text-sm text-muted" style={{ marginBottom: '1rem' }}>Messages in announcement channels with auto-publish enabled will be automatically crossposted.</p>
          {!announcementChannels.length ? (
            <div style={{ color: 'var(--text-muted)' }}>No announcement channels found in this server.</div>
          ) : (
            <div style={{ display: 'grid', gap: '0.625rem' }}>
              {announcementChannels.map(ch => (
                <div key={ch.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem 1rem', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                  <div>
                    <div style={{ fontWeight: 500, color: 'var(--text-primary)' }}>📢 #{ch.name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Announcement Channel</div>
                  </div>
                  <Toggle
                    enabled={autoPublishSet.has(ch.id)}
                    onChange={v => toggleAutoPublish(ch.id, v)}
                    label={autoPublishSet.has(ch.id) ? 'Enabled' : 'Disabled'}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
