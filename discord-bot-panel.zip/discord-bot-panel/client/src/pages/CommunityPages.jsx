import React, { useState, useEffect } from 'react';
import { Toggle, ChannelSelector, RoleSelector, SaveButton, EmbedBuilder, Table, Modal } from '../components/UI.jsx';
import { useApi, useSave } from '../hooks/useApi.js';
import { showToast } from '../components/Toast.jsx';

// ────────────────────────────────────────────────────────────────────────────
// DM SYSTEM
// ────────────────────────────────────────────────────────────────────────────
export function DMSystem() {
  const [tab, setTab] = useState('user');
  const { data: logsData, loading: logsLoading, refetch } = useApi('/api/dm/logs?limit=20');
  const [form, setForm] = useState({ userId: '', roleId: '', content: '', embedData: null, showEmbed: false, confirm: '' });
  const [sending, setSending] = useState(false);
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const send = async () => {
    if (!form.content.trim()) return showToast('Message content is required', 'error');
    if (tab === 'all' && form.confirm !== 'CONFIRM') return showToast('Type CONFIRM to send to everyone', 'error');

    setSending(true);
    try {
      const body = {
        targetType: tab,
        content: form.content,
        embedData: form.showEmbed ? form.embedData : null,
      };
      if (tab === 'user') body.targetId = form.userId;
      if (tab === 'role') body.targetId = form.roleId;

      const r = await fetch('/api/dm/send', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        credentials: 'include', body: JSON.stringify(body),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      showToast('DM job sent to bot!', 'success');
      setForm(p => ({ ...p, content: '', confirm: '' }));
      setTimeout(refetch, 2000);
    } catch (err) { showToast(`Failed: ${err.message}`, 'error'); }
    finally { setSending(false); }
  };

  const logCols = [
    { key: 'targetType', label: 'Type', render: v => <span className={`badge badge-${v === 'all' ? 'danger' : v === 'role' ? 'warning' : 'info'}`}>{v}</span> },
    { key: 'content', label: 'Preview', render: v => <span style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>{v}</span> },
    { key: 'sentCount', label: 'Sent', render: v => <span className="badge badge-success">✅ {v}</span> },
    { key: 'failedCount', label: 'Failed', render: v => v > 0 ? <span className="badge badge-danger">❌ {v}</span> : <span className="text-muted">—</span> },
    { key: 'createdAt', label: 'Time', render: v => new Date(v).toLocaleString() },
  ];

  return (
    <div>
      <div className="page-header"><h1>✉️ DM System</h1><p>Send direct messages to users, roles, or all members.</p></div>

      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header"><h2>📤 Compose Message</h2></div>
        <div className="card-body">
          <div className="tabs">
            {[['user','👤 DM User'],['role','🎭 DM By Role'],['all','📢 DM Everyone']].map(([key,label]) => (
              <button key={key} className={`tab-btn ${tab === key ? 'active' : ''}`} onClick={() => setTab(key)}>{label}</button>
            ))}
          </div>

          <div style={{ display: 'grid', gap: '1rem' }}>
            {tab === 'user' && (
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">User ID</label>
                <input className="form-control" value={form.userId} onChange={e => set('userId', e.target.value)} placeholder="Discord User ID..." />
              </div>
            )}
            {tab === 'role' && (
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Select Role</label>
                <RoleSelector value={form.roleId} onChange={v => set('roleId', v)} />
              </div>
            )}
            {tab === 'all' && (
              <div style={{ padding: '0.875rem', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 'var(--radius-md)' }}>
                <p style={{ color: 'var(--danger)', fontWeight: 600 }}>⚠️ This will DM ALL server members</p>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginTop: '0.25rem' }}>Use with extreme caution. Subject to Discord API rate limits.</p>
              </div>
            )}

            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Message Content</label>
              <textarea className="form-control" value={form.content} onChange={e => set('content', e.target.value)} placeholder="Enter your message..." rows={4} maxLength={2000} />
              <p className="text-sm text-muted mt-2">{form.content.length}/2000</p>
            </div>

            <Toggle enabled={form.showEmbed} onChange={v => set('showEmbed', v)} label="Include Embed" />
            {form.showEmbed && <EmbedBuilder value={form.embedData || {}} onChange={v => set('embedData', v)} />}

            {tab === 'all' && (
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Type CONFIRM to enable send</label>
                <input className="form-control" value={form.confirm} onChange={e => set('confirm', e.target.value)} placeholder="CONFIRM" style={{ maxWidth: '200px' }} />
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button
                className={`btn ${tab === 'all' ? 'btn-danger' : 'btn-primary'}`}
                onClick={send}
                disabled={sending || (tab === 'all' && form.confirm !== 'CONFIRM')}
              >
                {sending ? 'Sending...' : tab === 'all' ? '⚠️ Send to Everyone' : '📤 Send DM'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header"><h2>📋 DM Logs</h2></div>
        <div className="card-body">
          <Table columns={logCols} data={logsData?.logs || []} loading={logsLoading} pagination pageSize={10} emptyMessage="No DM logs yet." />
        </div>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// TICKETS
// ────────────────────────────────────────────────────────────────────────────
export function Tickets() {
  const { data: cfgData } = useApi('/api/tickets/config');
  const { data: statsData } = useApi('/api/tickets/stats');
  const { data: ticketsData, loading: ticketsLoading } = useApi('/api/tickets/list');
  const { save, saving, saved } = useSave('/api/tickets/config');

  const [cfg, setCfg] = useState({ enabled: false, categoryId: '', logChannelId: '', panelChannelId: '', supportRoleIds: [], transcriptsEnabled: true, ratingEnabled: true });
  const set = (k, v) => setCfg(p => ({ ...p, [k]: v }));
  useEffect(() => { if (cfgData) setCfg(p => ({ ...p, ...cfgData })); }, [cfgData]);

  const setupPanel = async () => {
    const r = await fetch('/api/tickets/panel/setup', { method: 'POST', credentials: 'include' });
    if (r.ok) showToast('Ticket panel sent!', 'success');
    else showToast('Failed to setup panel', 'error');
  };

  const ticketCols = [
    { key: 'id', label: '#', render: (_, r) => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{r.id.slice(-6)}</span> },
    { key: 'userId', label: 'User', render: v => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'type', label: 'Type', render: v => <span className="badge badge-info">{v}</span> },
    { key: 'status', label: 'Status', render: v => <span className={`badge badge-${v === 'open' ? 'success' : v === 'claimed' ? 'info' : 'muted'}`}>{v}</span> },
    { key: 'claimedBy', label: 'Claimed By', render: v => v ? <span style={{ fontSize: '0.8125rem' }}>{v}</span> : <span className="text-muted">—</span> },
    { key: 'createdAt', label: 'Created', render: v => new Date(v).toLocaleDateString() },
    { key: 'rating', label: 'Rating', render: v => v ? '⭐'.repeat(v) : <span className="text-muted">—</span> },
  ];

  return (
    <div>
      <div className="page-header"><h1>🎫 Ticket System</h1><p>Configure and manage support tickets.</p></div>

      {/* Stats */}
      <div className="stats-grid" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Total Tickets', value: statsData?.total ?? '—', icon: '🎫' },
          { label: 'Open Now', value: statsData?.open ?? '—', icon: '🟢' },
          { label: 'Closed Today', value: statsData?.closedToday ?? '—', icon: '✅' },
          { label: 'Avg Rating', value: statsData?.avgRating ? `${statsData.avgRating} ⭐` : '—', icon: '⭐' },
        ].map(s => (
          <div key={s.label} className="card" style={{ padding: '1.25rem' }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>{s.icon}</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{s.value}</div>
            <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Config */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>⚙️ Ticket Configuration</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gap: '1rem' }}>
            <Toggle enabled={cfg.enabled} onChange={v => set('enabled', v)} label="Enable Ticket System" />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Panel Channel</label>
                <ChannelSelector value={cfg.panelChannelId} onChange={v => set('panelChannelId', v)} />
              </div>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Log Channel</label>
                <ChannelSelector value={cfg.logChannelId} onChange={v => set('logChannelId', v)} />
              </div>
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Support Roles</label>
              <RoleSelector value={cfg.supportRoleIds} onChange={v => set('supportRoleIds', v)} multi />
            </div>
            <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
              <Toggle enabled={cfg.transcriptsEnabled} onChange={v => set('transcriptsEnabled', v)} label="Enable Transcripts" />
              <Toggle enabled={cfg.ratingEnabled} onChange={v => set('ratingEnabled', v)} label="Enable Rating System" />
            </div>
          </div>
        </div>
      </div>

      {/* Panel setup */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header"><h2>📌 Panel Setup</h2></div>
        <div className="card-body">
          <p className="text-sm text-muted" style={{ marginBottom: '1rem' }}>Send or re-send the ticket panel embed to the configured channel.</p>
          <button className="btn btn-primary" onClick={setupPanel}>📤 Send Ticket Panel</button>
        </div>
      </div>

      {/* Active Tickets */}
      <div className="card">
        <div className="card-header"><h2>📂 Active Tickets</h2></div>
        <div className="card-body">
          <Table columns={ticketCols} data={ticketsData?.tickets || []} loading={ticketsLoading} pagination pageSize={10} emptyMessage="No tickets found." />
        </div>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// COMMUNITY
// ────────────────────────────────────────────────────────────────────────────
export function Community() {
  const { data, loading } = useApi('/api/community/config');
  const { data: afkData, refetch: refetchAfk } = useApi('/api/community/afk');
  const { data: bdayData } = useApi('/api/community/birthdays');
  const { data: suggestData, refetch: refetchSuggestions } = useApi('/api/community/suggestions?limit=50');
  const { save, saving, saved } = useSave('/api/community/config');

  const [cfg, setCfg] = useState({ welcomeEnabled: false, welcomeChannelId: '', welcomeMessage: '', goodbyeEnabled: false, goodbyeChannelId: '', goodbyeMessage: '', birthdayEnabled: false, birthdayChannelId: '', birthdayRoleId: '', suggestionEnabled: false, suggestionChannelId: '' });
  const set = (k, v) => setCfg(p => ({ ...p, [k]: v }));
  useEffect(() => { if (data) setCfg(p => ({ ...p, ...data })); }, [data]);

  const removeAfk = async (userId) => {
    await fetch(`/api/community/afk/${userId}`, { method: 'DELETE', credentials: 'include' });
    showToast('AFK status removed', 'success');
    refetchAfk();
  };

  const updateSuggestion = async (id, status) => {
    const r = await fetch(`/api/community/suggestions/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify({ status }) });
    if (r.ok) { showToast(`Suggestion ${status}`, 'success'); refetchSuggestions(); }
  };

  const afkCols = [
    { key: 'userId', label: 'User', render: v => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'reason', label: 'Reason', render: v => v || <span className="text-muted">No reason</span> },
    { key: 'setAt', label: 'Since', render: v => new Date(v).toLocaleString() },
    { key: 'userId', label: 'Actions', render: (v) => <button className="btn btn-ghost btn-sm" onClick={() => removeAfk(v)}>Remove</button> },
  ];

  const bdayCols = [
    { key: 'userId', label: 'User', render: v => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'day', label: 'Day' },
    { key: 'month', label: 'Month', render: v => ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][v-1] },
  ];

  const suggestCols = [
    { key: 'content', label: 'Suggestion', render: v => <span style={{ maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>{v}</span> },
    { key: 'userId', label: 'User', render: v => <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{v}</span> },
    { key: 'upvotes', label: '👍', render: v => <span className="badge badge-success">{v}</span> },
    { key: 'downvotes', label: '👎', render: v => <span className="badge badge-danger">{v}</span> },
    { key: 'status', label: 'Status', render: v => <span className={`badge badge-${v === 'approved' ? 'success' : v === 'denied' ? 'danger' : 'warning'}`}>{v}</span> },
    { key: 'id', label: 'Actions', render: (_, row) => row.status === 'pending' ? (
      <div style={{ display: 'flex', gap: '0.375rem' }}>
        <button className="btn btn-success btn-sm" onClick={() => updateSuggestion(row.id, 'approved')}>✅</button>
        <button className="btn btn-danger btn-sm" onClick={() => updateSuggestion(row.id, 'denied')}>❌</button>
      </div>
    ) : null },
  ];

  return (
    <div>
      <div className="page-header"><h1>👥 Community</h1><p>Manage welcome messages, birthdays, AFK, and suggestions.</p></div>

      {/* Welcome/Goodbye */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>👋 Welcome & Goodbye</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            <div style={{ display: 'grid', gap: '0.75rem' }}>
              <Toggle enabled={cfg.welcomeEnabled} onChange={v => set('welcomeEnabled', v)} label="Enable Welcome Messages" />
              <div className="form-group" style={{ margin: 0 }}><label className="form-label">Channel</label><ChannelSelector value={cfg.welcomeChannelId} onChange={v => set('welcomeChannelId', v)} /></div>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Message <span className="text-muted">({'{user}'}, {'{server}'}, {'{count}'})</span></label>
                <textarea className="form-control" value={cfg.welcomeMessage || ''} onChange={e => set('welcomeMessage', e.target.value)} placeholder="Welcome {user} to {server}! We now have {count} members." rows={2} />
              </div>
            </div>
            <div style={{ display: 'grid', gap: '0.75rem' }}>
              <Toggle enabled={cfg.goodbyeEnabled} onChange={v => set('goodbyeEnabled', v)} label="Enable Goodbye Messages" />
              <div className="form-group" style={{ margin: 0 }}><label className="form-label">Channel</label><ChannelSelector value={cfg.goodbyeChannelId} onChange={v => set('goodbyeChannelId', v)} /></div>
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Message</label>
                <textarea className="form-control" value={cfg.goodbyeMessage || ''} onChange={e => set('goodbyeMessage', e.target.value)} placeholder="Goodbye {user}, we hope to see you again!" rows={2} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Birthday */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>🎂 Birthday Announcements</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gap: '1rem' }}>
            <Toggle enabled={cfg.birthdayEnabled} onChange={v => set('birthdayEnabled', v)} label="Enable Birthday Announcements" />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
              <div className="form-group" style={{ margin: 0 }}><label className="form-label">Announcement Channel</label><ChannelSelector value={cfg.birthdayChannelId} onChange={v => set('birthdayChannelId', v)} /></div>
              <div className="form-group" style={{ margin: 0 }}><label className="form-label">Birthday Role (24h)</label><RoleSelector value={cfg.birthdayRoleId} onChange={v => set('birthdayRoleId', v)} /></div>
            </div>
            <Table columns={bdayCols} data={bdayData || []} emptyMessage="No birthdays registered." />
          </div>
        </div>
      </div>

      {/* AFK */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header"><h2>💤 Active AFK Users</h2></div>
        <div className="card-body">
          <Table columns={afkCols} data={afkData || []} emptyMessage="No users are currently AFK." />
        </div>
      </div>

      {/* Suggestions */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>💡 Suggestion System</h2>
          <SaveButton onClick={() => save(cfg)} loading={saving} saved={saved} />
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gap: '1rem', marginBottom: '1.5rem' }}>
            <Toggle enabled={cfg.suggestionEnabled} onChange={v => set('suggestionEnabled', v)} label="Enable Suggestions" />
            <div className="form-group" style={{ margin: 0 }}><label className="form-label">Suggestion Channel</label><ChannelSelector value={cfg.suggestionChannelId} onChange={v => set('suggestionChannelId', v)} /></div>
          </div>
          <Table columns={suggestCols} data={suggestData?.suggestions || []} pagination pageSize={10} emptyMessage="No suggestions yet." />
        </div>
      </div>
    </div>
  );
}
