const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antinuke')
    .setDescription('Configure the anti-nuke system')
    .addSubcommand(s => s.setName('enable').setDescription('Enable anti-nuke'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable anti-nuke'))
    .addSubcommand(s =>
      s.setName('config')
        .setDescription('Configure anti-nuke settings')
        .addIntegerOption(o => o.setName('threshold').setDescription('Actions before trigger').setMinValue(1).setMaxValue(20))
        .addStringOption(o =>
          o.setName('action').setDescription('Action to take')
            .addChoices({ name: 'Ban', value: 'ban' }, { name: 'Kick', value: 'kick' }, { name: 'Strip Roles', value: 'strip_roles' })
        )
        .addBooleanOption(o => o.setName('auto_revert').setDescription('Auto-revert destructive actions'))
    )
    .addSubcommand(s => s.setName('status').setDescription('View anti-nuke status'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;

    if (sub === 'enable') {
      await prisma.securityConfig.upsert({
        where: { guildId },
        update: { antiNukeEnabled: true },
        create: { guildId, antiNukeEnabled: true },
      });
      await updateCache(client, prisma, guildId);
      return interaction.editReply({ embeds: [successEmbed('Anti-Nuke Enabled', 'The anti-nuke system is now active.')] });
    }

    if (sub === 'disable') {
      await prisma.securityConfig.upsert({ where: { guildId }, update: { antiNukeEnabled: false }, create: { guildId, antiNukeEnabled: false } });
      await updateCache(client, prisma, guildId);
      return interaction.editReply({ embeds: [successEmbed('Anti-Nuke Disabled', 'The anti-nuke system has been disabled.')] });
    }

    if (sub === 'config') {
      const threshold = interaction.options.getInteger('threshold');
      const action = interaction.options.getString('action');
      const autoRevert = interaction.options.getBoolean('auto_revert');

      const updateData = {};
      if (threshold !== null) updateData.antiNukeThreshold = threshold;
      if (action) updateData.antiNukeAction = action;
      if (autoRevert !== null) updateData.autoRevertEnabled = autoRevert;

      await prisma.securityConfig.upsert({ where: { guildId }, update: updateData, create: { guildId, ...updateData } });
      await updateCache(client, prisma, guildId);
      return interaction.editReply({ embeds: [successEmbed('Anti-Nuke Configured', `Settings updated:\n${Object.entries(updateData).map(([k, v]) => `**${k}:** ${v}`).join('\n')}`)] });
    }

    if (sub === 'status') {
      const cfg = await prisma.securityConfig.findUnique({ where: { guildId } });
      const fields = [
        { name: 'Enabled', value: cfg?.antiNukeEnabled ? '✅ Yes' : '❌ No', inline: true },
        { name: 'Threshold', value: `${cfg?.antiNukeThreshold ?? 5} actions`, inline: true },
        { name: 'Action', value: cfg?.antiNukeAction ?? 'ban', inline: true },
        { name: 'Auto-Revert', value: cfg?.autoRevertEnabled ? '✅ Yes' : '❌ No', inline: true },
      ];
      return interaction.editReply({ embeds: [createEmbed({ title: '🛡️ Anti-Nuke Status', fields, color: 0x3b82f6 })] });
    }
  },
};

async function updateCache(client, prisma, guildId) {
  const cfg = await prisma.securityConfig.findUnique({ where: { guildId } });
  const cache = client.configCache.get(guildId) || {};
  client.configCache.set(guildId, { ...cache, security: cfg });
}
