const { EmbedBuilder } = require('discord.js');
const { buildFromData } = require('../utils/embed');
const logger = require('../utils/logger');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client, prisma) {
    const guildId = member.guild.id;
    const cache = client.configCache.get(guildId);
    if (!cache) return;

    const { community, roles } = cache;

    // ─── Auto Roles ────────────────────────────────────────────────────────
    if (roles?.autoRoleIds?.length > 0) {
      for (const roleId of roles.autoRoleIds) {
        await member.roles.add(roleId).catch(err =>
          logger.warn(`Failed to add auto-role ${roleId}:`, err.message)
        );
      }
    }

    // ─── Unverified Role ──────────────────────────────────────────────────
    if (roles?.verificationEnabled && roles?.unverifiedRoleId) {
      await member.roles.add(roles.unverifiedRoleId).catch(() => {});
    }

    // ─── Welcome Message ──────────────────────────────────────────────────
    if (community?.welcomeEnabled && community?.welcomeChannelId) {
      const channel = member.guild.channels.cache.get(community.welcomeChannelId);
      if (channel) {
        try {
          const msg = (community.welcomeMessage || 'Welcome {user} to {server}!')
            .replace('{user}', `<@${member.id}>`)
            .replace('{server}', member.guild.name)
            .replace('{count}', member.guild.memberCount.toString());

          const embed = community.welcomeEmbedData
            ? buildFromData(community.welcomeEmbedData)
            : new EmbedBuilder()
                .setTitle('👋 Welcome!')
                .setDescription(msg)
                .setColor(0x10b981)
                .setThumbnail(member.user.displayAvatarURL())
                .setTimestamp();

          await channel.send({ content: msg, embeds: [embed] });
        } catch (err) {
          logger.error('Welcome message error:', err.message);
        }
      }
    }

    // ─── Record daily member snapshot ─────────────────────────────────────
    await prisma.memberSnapshot.create({
      data: { guildId, memberCount: member.guild.memberCount },
    }).catch(() => {});
  },
};
