import React, { useState, useEffect, useRef } from 'react';

// ─── Toggle ────────────────────────────────────────────────────────────────
export function Toggle({ enabled, onChange, label, disabled = false }) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.6 : 1 }}>
      <div
        onClick={() => !disabled && onChange(!enabled)}
        style={{
          position: 'relative',
          width: '44px',
          height: '24px',
          background: enabled ? 'var(--primary-500)' : 'var(--bg-elevated)',
          borderRadius: '12px',
          transition: 'background var(--transition-base)',
          flexShrink: 0,
          cursor: disabled ? 'not-allowed' : 'pointer',
        }}
      >
        <div style={{
          position: 'absolute',
          top: '3px',
          left: enabled ? '23px' : '3px',
          width: '18px',
          height: '18px',
          background: '#fff',
          borderRadius: '50%',
          transition: 'left var(--transition-base)',
          boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
        }} />
      </div>
      {label && <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', userSelect: 'none' }}>{label}</span>}
    </label>
  );
}

// ─── StatCard ──────────────────────────────────────────────────────────────
export function StatCard({ icon, label, value, color = 'var(--primary-500)', loading = false }) {
  return (
    <div className="card" style={{ padding: '1.25rem' }}>
      {loading ? (
        <>
          <div className="skeleton" style={{ width: '40px', height: '40px', borderRadius: '50%', marginBottom: '0.75rem' }} />
          <div className="skeleton" style={{ width: '60%', height: '28px', marginBottom: '0.375rem' }} />
          <div className="skeleton" style={{ width: '40%', height: '16px' }} />
        </>
      ) : (
        <>
          <div style={{
            width: '44px',
            height: '44px',
            background: `${color}22`,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '1.25rem',
            marginBottom: '0.75rem',
          }}>
            {icon}
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-primary)', lineHeight: 1.2 }}>{value}</div>
          <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>{label}</div>
        </>
      )}
    </div>
  );
}

// ─── Modal ──────────────────────────────────────────────────────────────────
export function Modal({ isOpen, onClose, title, children, footer }) {
  const overlayRef = useRef(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      className="overlay"
      ref={overlayRef}
      onClick={e => { if (e.target === overlayRef.current) onClose(); }}
    >
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="modal-header">
          <h3 id="modal-title">{title}</h3>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '1.25rem', padding: '0.25rem', minHeight: '44px', minWidth: '44px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >
            ✕
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
}

// ─── Table ──────────────────────────────────────────────────────────────────
export function Table({ columns, data, loading, emptyMessage = 'No data found.', pagination = false, pageSize = 10 }) {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');

  const filtered = data?.filter(row =>
    Object.values(row).some(v => String(v).toLowerCase().includes(search.toLowerCase()))
  ) ?? [];

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paged = pagination ? filtered.slice((page - 1) * pageSize, page * pageSize) : filtered;

  return (
    <div>
      {data?.length > pageSize && (
        <div style={{ marginBottom: '0.75rem' }}>
          <input
            className="form-control"
            placeholder="Search..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            style={{ maxWidth: '280px' }}
          />
        </div>
      )}
      <div className="table-wrapper">
        <table className="table">
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key}>{col.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  {columns.map(col => (
                    <td key={col.key}>
                      <div className="skeleton" style={{ height: '16px', borderRadius: '4px' }} />
                    </td>
                  ))}
                </tr>
              ))
            ) : paged.length === 0 ? (
              <tr>
                <td colSpan={columns.length} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '2rem' }}>
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              paged.map((row, i) => (
                <tr key={row.id || i}>
                  {columns.map(col => (
                    <td key={col.key}>
                      {col.render ? col.render(row[col.key], row) : row[col.key]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {pagination && totalPages > 1 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '1rem', justifyContent: 'flex-end' }}>
          <button className="btn btn-ghost btn-sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
          <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Page {page} of {totalPages}</span>
          <button className="btn btn-ghost btn-sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next →</button>
        </div>
      )}
    </div>
  );
}

// ─── EmbedBuilder ────────────────────────────────────────────────────────────
export function EmbedBuilder({ value = {}, onChange }) {
  const handle = (key, val) => onChange({ ...value, [key]: val });

  return (
    <div style={{ display: 'grid', gap: '1rem' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label">Title</label>
          <input className="form-control" value={value.title || ''} onChange={e => handle('title', e.target.value)} placeholder="Embed title" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label">Color</label>
          <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
            <input
              type="color"
              value={value.color || '#3b82f6'}
              onChange={e => handle('color', e.target.value)}
              style={{ width: '44px', height: '44px', border: 'none', background: 'none', cursor: 'pointer', padding: 0 }}
            />
            <input className="form-control" value={value.color || '#3b82f6'} onChange={e => handle('color', e.target.value)} placeholder="#3b82f6" />
          </div>
        </div>
      </div>

      <div className="form-group" style={{ margin: 0 }}>
        <label className="form-label">Description</label>
        <textarea className="form-control" value={value.description || ''} onChange={e => handle('description', e.target.value)} placeholder="Embed body text..." rows={3} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label">Thumbnail URL</label>
          <input className="form-control" value={value.thumbnail || ''} onChange={e => handle('thumbnail', e.target.value)} placeholder="https://..." />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label">Image URL</label>
          <input className="form-control" value={value.image || ''} onChange={e => handle('image', e.target.value)} placeholder="https://..." />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label">Author Name</label>
          <input className="form-control" value={value.author || ''} onChange={e => handle('author', e.target.value)} placeholder="Author name" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label">Footer Text</label>
          <input className="form-control" value={value.footer || ''} onChange={e => handle('footer', e.target.value)} placeholder="Footer text" />
        </div>
      </div>

      {/* Live Preview */}
      {(value.title || value.description) && (
        <div style={{
          borderLeft: `4px solid ${value.color || '#3b82f6'}`,
          background: '#36393f',
          borderRadius: '0 var(--radius-md) var(--radius-md) 0',
          padding: '0.75rem 1rem',
        }}>
          <div style={{ fontSize: '0.75rem', color: '#b9bbbe', marginBottom: '0.25rem' }}>Preview</div>
          {value.author && <div style={{ fontSize: '0.8125rem', color: '#fff', fontWeight: 600, marginBottom: '0.25rem' }}>{value.author}</div>}
          {value.title && <div style={{ fontSize: '1rem', fontWeight: 700, color: '#fff', marginBottom: '0.25rem' }}>{value.title}</div>}
          {value.description && <div style={{ fontSize: '0.875rem', color: '#dcddde' }}>{value.description}</div>}
          {value.footer && <div style={{ fontSize: '0.75rem', color: '#72767d', marginTop: '0.5rem', borderTop: '1px solid #4f545c', paddingTop: '0.375rem' }}>{value.footer}</div>}
        </div>
      )}
    </div>
  );
}

// ─── ChannelSelector ─────────────────────────────────────────────────────────
export function ChannelSelector({ value, onChange, placeholder = 'Select channel...' }) {
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/info/channels', { credentials: 'include' })
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) setChannels(data.sort((a, b) => a.position - b.position));
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const textChannels = channels.filter(c => c.type === 0 || c.type === 5);

  return (
    <select className="form-control" value={value || ''} onChange={e => onChange(e.target.value)} disabled={loading}>
      <option value="">{loading ? 'Loading channels...' : placeholder}</option>
      {textChannels.map(c => (
        <option key={c.id} value={c.id}>#{c.name}</option>
      ))}
    </select>
  );
}

// ─── RoleSelector ─────────────────────────────────────────────────────────────
export function RoleSelector({ value, onChange, placeholder = 'Select role...', multi = false }) {
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/info/roles', { credentials: 'include' })
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) setRoles(data.filter(r => r.name !== '@everyone').sort((a, b) => b.position - a.position));
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (multi) {
    const selected = Array.isArray(value) ? value : [];
    const toggle = (id) => {
      if (selected.includes(id)) onChange(selected.filter(v => v !== id));
      else onChange([...selected, id]);
    };

    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem', padding: '0.5rem', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', minHeight: '44px' }}>
        {loading ? <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading roles...</span> : (
          roles.map(role => {
            const active = selected.includes(role.id);
            const color = role.color !== 0 ? `#${role.color.toString(16).padStart(6, '0')}` : 'var(--text-muted)';
            return (
              <button
                key={role.id}
                type="button"
                onClick={() => toggle(role.id)}
                style={{
                  padding: '0.2rem 0.625rem',
                  borderRadius: '9999px',
                  border: `1px solid ${active ? color : 'var(--border-color)'}`,
                  background: active ? `${color}22` : 'transparent',
                  color: active ? color : 'var(--text-muted)',
                  fontSize: '0.8125rem',
                  cursor: 'pointer',
                  transition: 'all var(--transition-base)',
                  minHeight: '28px',
                }}
              >
                {role.name}
              </button>
            );
          })
        )}
      </div>
    );
  }

  return (
    <select className="form-control" value={value || ''} onChange={e => onChange(e.target.value)} disabled={loading}>
      <option value="">{loading ? 'Loading roles...' : placeholder}</option>
      {roles.map(r => (
        <option key={r.id} value={r.id}>@{r.name}</option>
      ))}
    </select>
  );
}

// ─── SaveButton ───────────────────────────────────────────────────────────────
export function SaveButton({ onClick, loading, saved }) {
  return (
    <button
      className={`btn ${saved ? 'btn-success' : 'btn-primary'}`}
      onClick={onClick}
      disabled={loading}
      style={{ minWidth: '110px' }}
    >
      {loading ? (
        <span style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
          <span style={{ display: 'inline-block', width: '14px', height: '14px', border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.6s linear infinite' }} />
          Saving...
        </span>
      ) : saved ? '✅ Saved!' : '💾 Save Changes'}
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </button>
  );
}
