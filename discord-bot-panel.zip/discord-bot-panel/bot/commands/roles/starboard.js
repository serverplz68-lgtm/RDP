const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('starboard')
    .setDescription('Configure the starboard')
    .addSubcommand(s => s.setName('enable').setDescription('Enable starboard'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable starboard'))
    .addSubcommand(s =>
      s.setName('config')
        .setDescription('Configure starboard')
        .addChannelOption(o => o.setName('channel').setDescription('Starboard channel').setRequired(false))
        .addIntegerOption(o => o.setName('threshold').setDescription('Minimum stars to post').setMinValue(1).setMaxValue(50).setRequired(false))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;

    if (sub === 'enable') {
      await upsert(prisma, guildId, { starboardEnabled: true });
    } else if (sub === 'disable') {
      await upsert(prisma, guildId, { starboardEnabled: false });
    } else if (sub === 'config') {
      const channel = interaction.options.getChannel('channel');
      const threshold = interaction.options.getInteger('threshold');
      const updateData = {};
      if (channel) updateData.starboardChannelId = channel.id;
      if (threshold) updateData.starboardThreshold = threshold;
      await upsert(prisma, guildId, updateData);
    }

    const cfg = await prisma.roleConfig.findUnique({ where: { guildId } });
    const cache = client.configCache.get(guildId) || {};
    client.configCache.set(guildId, { ...cache, roles: cfg });

    await interaction.editReply({ embeds: [successEmbed('Starboard Updated', 'Starboard settings have been saved.')] });
  },
};

async function upsert(prisma, guildId, data) {
  await prisma.roleConfig.upsert({ where: { guildId }, update: data, create: { guildId, ...data } });
}
