const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antispam')
    .setDescription('Configure anti-spam')
    .addSubcommand(s => s.setName('enable').setDescription('Enable anti-spam'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable anti-spam'))
    .addSubcommand(s =>
      s.setName('config')
        .setDescription('Configure')
        .addIntegerOption(o => o.setName('threshold').setDescription('Message count to trigger').setMinValue(2).setMaxValue(20))
        .addIntegerOption(o => o.setName('interval').setDescription('Time window in ms').setMinValue(1000).setMaxValue(30000))
        .addStringOption(o =>
          o.setName('action').setDescription('Action')
            .addChoices({ name: 'Delete', value: 'delete' }, { name: 'Timeout', value: 'timeout' }, { name: 'Kick', value: 'kick' }, { name: 'Ban', value: 'ban' })
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;

    const updateData = {};
    if (sub === 'enable') updateData.antiSpamEnabled = true;
    if (sub === 'disable') updateData.antiSpamEnabled = false;
    if (sub === 'config') {
      const threshold = interaction.options.getInteger('threshold');
      const interval = interaction.options.getInteger('interval');
      const action = interaction.options.getString('action');
      if (threshold) updateData.spamThreshold = threshold;
      if (interval) updateData.spamInterval = interval;
      if (action) updateData.spamAction = action;
    }

    await prisma.securityConfig.upsert({ where: { guildId }, update: updateData, create: { guildId, ...updateData } });

    const cfg = await prisma.securityConfig.findUnique({ where: { guildId } });
    const cache = client.configCache.get(guildId) || {};
    client.configCache.set(guildId, { ...cache, security: cfg });

    await interaction.editReply({ embeds: [successEmbed('Anti-Spam Updated', `Settings applied.`)] });
  },
};
