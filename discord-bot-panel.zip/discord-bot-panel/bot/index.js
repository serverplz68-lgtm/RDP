require('dotenv').config();
const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const { io } = require('socket.io-client');
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const { PrismaClient } = require('@prisma/client');
const config = require('./config');
const logger = require('./utils/logger');
const socketEmitter = require('./utils/socketEmitter');

// ─── Prisma ────────────────────────────────────────────────────────────────
const prisma = new PrismaClient();

// ─── Discord Client ────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildMessageReactions,
  ],
});

client.commands = new Collection();
client.configCache = new Map();  // guildId -> all configs
client.prisma = prisma;

// ─── Load Events ────────────────────────────────────────────────────────────
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));

for (const file of eventFiles) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client, prisma));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client, prisma));
  }
  logger.info(`Loaded event: ${event.name}`);
}

// ─── Load Commands ──────────────────────────────────────────────────────────
const commandsPath = path.join(__dirname, 'commands');

function loadCommandsRecursive(dir) {
  const items = fs.readdirSync(dir, { withFileTypes: true });
  for (const item of items) {
    if (item.isDirectory()) {
      loadCommandsRecursive(path.join(dir, item.name));
    } else if (item.name.endsWith('.js')) {
      const command = require(path.join(dir, item.name));
      if ('data' in command && 'execute' in command) {
        client.commands.set(command.data.name, command);
        logger.info(`Loaded command: /${command.data.name}`);
      }
    }
  }
}

loadCommandsRecursive(commandsPath);

// ─── Register Slash Commands ─────────────────────────────────────────────────
async function registerCommands() {
  const rest = new REST().setToken(config.token);
  const commands = client.commands.map(cmd => cmd.data.toJSON());
  try {
    logger.info(`Registering ${commands.length} slash commands for guild ${config.guildId}...`);
    await rest.put(
      Routes.applicationGuildCommands(config.clientId, config.guildId),
      { body: commands }
    );
    logger.success('Slash commands registered successfully.');
  } catch (err) {
    logger.error('Failed to register commands:', err);
  }
}

// ─── Socket.io Connection to Server ─────────────────────────────────────────
const socket = io(config.serverUrl, {
  auth: { token: config.botSocketSecret },
  reconnectionAttempts: Infinity,
  reconnectionDelay: 2000,
});

socketEmitter.setSocket(socket);

socket.on('connect', () => {
  logger.success(`Bot connected to server via Socket.io (id: ${socket.id})`);
});

socket.on('connect_error', (err) => {
  logger.warn(`Socket connection error: ${err.message}`);
});

socket.on('disconnect', (reason) => {
  logger.warn(`Socket disconnected: ${reason}`);
});

// Config update events from dashboard → update in-memory cache
socket.on('config:security:update', async ({ guildId, config: cfg }) => {
  const cached = client.configCache.get(guildId) || {};
  client.configCache.set(guildId, { ...cached, security: cfg });
  socket.emit('bot:config:confirmed', { section: 'security', guildId });
  logger.info(`Security config updated for guild ${guildId}`);
});

socket.on('config:moderation:update', async ({ guildId, config: cfg }) => {
  const cached = client.configCache.get(guildId) || {};
  client.configCache.set(guildId, { ...cached, moderation: cfg });
  socket.emit('bot:config:confirmed', { section: 'moderation', guildId });
});

socket.on('config:tickets:update', async ({ guildId, config: cfg }) => {
  const cached = client.configCache.get(guildId) || {};
  client.configCache.set(guildId, { ...cached, tickets: cfg });
  socket.emit('bot:config:confirmed', { section: 'tickets', guildId });
});

socket.on('config:community:update', async ({ guildId, config: cfg }) => {
  const cached = client.configCache.get(guildId) || {};
  client.configCache.set(guildId, { ...cached, community: cfg });
  socket.emit('bot:config:confirmed', { section: 'community', guildId });
});

socket.on('config:roles:update', async ({ guildId, config: cfg }) => {
  const cached = client.configCache.get(guildId) || {};
  client.configCache.set(guildId, { ...cached, roles: cfg });
  socket.emit('bot:config:confirmed', { section: 'roles', guildId });
});

// ─── Performance Stats Emit ───────────────────────────────────────────────
let cpuUsagePrev = process.cpuUsage();

setInterval(() => {
  const memUsage = process.memoryUsage();
  const cpuUsage = process.cpuUsage(cpuUsagePrev);
  cpuUsagePrev = process.cpuUsage();

  const cpuPercent = ((cpuUsage.user + cpuUsage.system) / 10000).toFixed(2);

  socket.emit('bot:stats', {
    ping: client.ws.ping,
    memoryMB: Math.round(memUsage.heapUsed / 1024 / 1024),
    cpuPercent: parseFloat(cpuPercent),
    uptime: process.uptime(),
    guildCount: client.guilds.cache.size,
    userCount: client.users.cache.size,
    timestamp: new Date().toISOString(),
  });
}, 10000);

// ─── Giveaway Background Check ─────────────────────────────────────────────
setInterval(async () => {
  try {
    const now = new Date();
    const ended = await prisma.giveaway.findMany({
      where: { ended: false, endsAt: { lte: now } },
    });

    for (const giveaway of ended) {
      try {
        const guild = client.guilds.cache.get(giveaway.guildId);
        if (!guild) continue;

        const channel = guild.channels.cache.get(giveaway.channelId);
        if (!channel) continue;

        const message = giveaway.messageId
          ? await channel.messages.fetch(giveaway.messageId).catch(() => null)
          : null;

        // Get entries from button interactions stored via socket (simplified: use reaction)
        // In production: store entries in DB via button interaction
        const entries = message
          ? (await message.reactions.cache.get('🎉')?.users.fetch() ?? new Collection())
          : new Collection();

        const eligibleEntries = entries.filter(u => !u.bot);
        const winners = [];

        const pool = [...eligibleEntries.values()];
        const count = Math.min(giveaway.winnersCount, pool.length);

        for (let i = 0; i < count; i++) {
          const idx = Math.floor(Math.random() * pool.length);
          winners.push(pool[idx]);
          pool.splice(idx, 1);
        }

        const winnerMentions = winners.length
          ? winners.map(w => `<@${w.id}>`).join(', ')
          : 'No valid entries';

        await channel.send({
          content: `🎉 **Giveaway Ended!**\nPrize: **${giveaway.prize}**\nWinners: ${winnerMentions}`,
        });

        await prisma.giveaway.update({
          where: { id: giveaway.id },
          data: { ended: true, winnerIds: winners.map(w => w.id) },
        });

        logger.info(`Giveaway ${giveaway.id} ended. Winners: ${winners.map(w => w.username).join(', ')}`);
      } catch (err) {
        logger.error(`Error ending giveaway ${giveaway.id}:`, err.message);
      }
    }
  } catch (err) {
    logger.error('Giveaway check error:', err.message);
  }
}, 60000);

// ─── Reminder Background Check ────────────────────────────────────────────
setInterval(async () => {
  try {
    const now = new Date();
    const due = await prisma.reminder.findMany({
      where: { sent: false, remindAt: { lte: now } },
    });

    for (const reminder of due) {
      try {
        const user = await client.users.fetch(reminder.userId).catch(() => null);
        if (user) {
          const channel = client.channels.cache.get(reminder.channelId);
          if (channel) {
            await channel.send(`<@${reminder.userId}> ⏰ **Reminder:** ${reminder.message}`);
          } else {
            await user.send(`⏰ **Reminder:** ${reminder.message}`).catch(() => {});
          }
        }
        await prisma.reminder.update({ where: { id: reminder.id }, data: { sent: true } });
      } catch (err) {
        logger.error(`Failed to send reminder ${reminder.id}:`, err.message);
      }
    }
  } catch (err) {
    logger.error('Reminder check error:', err.message);
  }
}, 30000);

// ─── Birthday Daily Check ─────────────────────────────────────────────────
cron.schedule('0 0 * * *', async () => {
  const today = new Date();
  const day = today.getUTCDate();
  const month = today.getUTCMonth() + 1;

  try {
    const birthdays = await prisma.birthday.findMany({
      where: { day, month },
      include: { guild: { include: { communityConfig: true } } },
    });

    for (const birthday of birthdays) {
      const cfg = birthday.guild.communityConfig;
      if (!cfg?.birthdayEnabled || !cfg?.birthdayChannelId) continue;

      const guild = client.guilds.cache.get(birthday.guildId);
      if (!guild) continue;

      const channel = guild.channels.cache.get(cfg.birthdayChannelId);
      if (!channel) continue;

      const member = guild.members.cache.get(birthday.userId);
      if (!member) continue;

      await channel.send(`🎂 Happy Birthday <@${birthday.userId}>! 🎉`);

      if (cfg.birthdayRoleId) {
        try {
          await member.roles.add(cfg.birthdayRoleId);
          // Remove after 24 hours
          setTimeout(async () => {
            await member.roles.remove(cfg.birthdayRoleId).catch(() => {});
          }, 24 * 60 * 60 * 1000);
        } catch (err) {
          logger.error(`Failed to assign birthday role:`, err.message);
        }
      }
    }
  } catch (err) {
    logger.error('Birthday check error:', err.message);
  }
}, { timezone: 'UTC' });

// ─── Login ────────────────────────────────────────────────────────────────
(async () => {
  await registerCommands();
  await client.login(config.token);
  logger.bot('Bot is starting...');
})();

module.exports = { client, prisma };
