const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { successEmbed, warnEmbed } = require('../../utils/embed');
const { emitDMLog } = require('../../utils/socketEmitter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dmall')
    .setDescription('DM every member in the server (use with extreme caution)')
    .addStringOption(o => o.setName('message').setDescription('Message to send').setRequired(true))
    .addStringOption(o => o.setName('confirm').setDescription('Type CONFIRM to proceed').setRequired(true))
    .addStringOption(o => o.setName('embed_title').setDescription('Optional embed title'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });

    const confirm = interaction.options.getString('confirm');
    if (confirm !== 'CONFIRM') {
      return interaction.editReply({ embeds: [warnEmbed('Confirmation Required', 'You must type `CONFIRM` exactly to use this command.')] });
    }

    const message = interaction.options.getString('message');
    const embedTitle = interaction.options.getString('embed_title');

    const guild = interaction.guild;
    await guild.members.fetch();
    const members = guild.members.cache.filter(m => !m.user.bot);

    let sent = 0, failed = 0;

    await interaction.editReply({ content: `📤 Sending to ${members.size} members... This may take a while.` });

    const membersArray = [...members.values()];
    for (let i = 0; i < membersArray.length; i += 10) {
      const batch = membersArray.slice(i, i + 10);

      await Promise.all(batch.map(async (member) => {
        try {
          const payload = {};
          if (embedTitle) {
            payload.embeds = [new EmbedBuilder().setTitle(embedTitle).setDescription(message).setColor(0x3b82f6).setFooter({ text: guild.name }).setTimestamp()];
          } else {
            payload.content = message;
          }
          await member.send(payload);
          sent++;
        } catch {
          failed++;
        }
      }));

      if (i + 10 < membersArray.length) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }

    await prisma.dMLog.create({
      data: { guildId: interaction.guildId, senderId: interaction.user.id, targetType: 'all', content: message, sentCount: sent, failedCount: failed },
    });

    emitDMLog({ guildId: interaction.guildId, targetType: 'all', content: message, sentCount: sent, failedCount: failed });

    await interaction.editReply({ embeds: [successEmbed('DM All Complete', `✅ Sent: **${sent}**\n❌ Failed: **${failed}**`)] });
  },
};
