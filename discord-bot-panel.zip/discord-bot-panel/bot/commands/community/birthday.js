const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { successEmbed, errorEmbed, createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('birthday')
    .setDescription('Manage your birthday')
    .addSubcommand(s =>
      s.setName('set').setDescription('Set your birthday')
        .addIntegerOption(o => o.setName('day').setDescription('Day (1-31)').setRequired(true).setMinValue(1).setMaxValue(31))
        .addIntegerOption(o => o.setName('month').setDescription('Month (1-12)').setRequired(true).setMinValue(1).setMaxValue(12))
    )
    .addSubcommand(s => s.setName('remove').setDescription('Remove your birthday'))
    .addSubcommand(s => s.setName('check').setDescription('Check your registered birthday'))
    .addSubcommand(s => s.setName('list').setDescription('List upcoming birthdays')),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;
    const userId = interaction.user.id;

    if (sub === 'set') {
      const day = interaction.options.getInteger('day');
      const month = interaction.options.getInteger('month');

      await prisma.birthday.upsert({
        where: { guildId_userId: { guildId, userId } },
        update: { day, month },
        create: { guildId, userId, day, month },
      });

      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return interaction.editReply({ embeds: [successEmbed('Birthday Set', `Your birthday is set to **${day} ${months[month - 1]}**! 🎂`)] });
    }

    if (sub === 'remove') {
      await prisma.birthday.deleteMany({ where: { guildId, userId } });
      return interaction.editReply({ embeds: [successEmbed('Birthday Removed', 'Your birthday has been removed.')] });
    }

    if (sub === 'check') {
      const bday = await prisma.birthday.findUnique({ where: { guildId_userId: { guildId, userId } } });
      if (!bday) return interaction.editReply({ embeds: [errorEmbed('Not Set', 'You have not set a birthday.')] });

      const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return interaction.editReply({ embeds: [createEmbed({ title: '🎂 Your Birthday', description: `**${bday.day} ${months[bday.month - 1]}**`, color: 0xf59e0b })] });
    }

    if (sub === 'list') {
      const birthdays = await prisma.birthday.findMany({ where: { guildId }, take: 10 });
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

      const fields = birthdays.map(b => ({
        name: `<@${b.userId}>`,
        value: `${b.day} ${months[b.month - 1]}`,
        inline: true,
      }));

      return interaction.editReply({
        embeds: [createEmbed({ title: '🎂 Upcoming Birthdays', fields: fields.length ? fields : [{ name: 'None', value: 'No birthdays registered.' }], color: 0xf59e0b })],
      });
    }
  },
};
