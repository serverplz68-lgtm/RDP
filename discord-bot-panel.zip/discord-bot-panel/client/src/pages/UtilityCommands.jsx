import React, { useState } from 'react';
import { Table, Modal, EmbedBuilder, Toggle, ChannelSelector } from '../components/UI.jsx';
import { useApi } from '../hooks/useApi.js';
import { showToast } from '../components/Toast.jsx';

export default function UtilityCommands() {
  const { data: cmdsData, loading: cmdsLoading, refetch: refetchCmds } = useApi('/api/utility/commands');
  const { data: monitorsData, loading: monitorsLoading, refetch: refetchMonitors } = useApi('/api/utility/monitors');
  const { data: giveawaysData } = useApi('/api/utility/giveaways');
  const { data: remindersData, loading: remindersLoading, refetch: refetchReminders } = useApi('/api/utility/reminders');

  // Custom Command Modal
  const [cmdModal, setCmdModal] = useState(null); // null | { mode: 'add'|'edit', data: {} }
  const [cmdForm, setCmdForm] = useState({ trigger: '', response: '', embedData: null, showEmbed: false });
  const [cmdSaving, setCmdSaving] = useState(false);

  // Monitor Modal
  const [monitorModal, setMonitorModal] = useState(false);
  const [monitorForm, setMonitorForm] = useState({ name: '', url: '', notifyChannel: '' });
  const [monitorSaving, setMonitorSaving] = useState(false);

  // Checking website
  const [checkingId, setCheckingId] = useState(null);

  const openAddCmd = () => {
    setCmdForm({ trigger: '', response: '', embedData: null, showEmbed: false });
    setCmdModal({ mode: 'add' });
  };

  const openEditCmd = (cmd) => {
    setCmdForm({ trigger: cmd.trigger, response: cmd.response, embedData: cmd.embedData, showEmbed: !!cmd.embedData });
    setCmdModal({ mode: 'edit', id: cmd.id });
  };

  const saveCmd = async () => {
    if (!cmdForm.trigger.trim() || !cmdForm.response.trim()) return showToast('Trigger and response are required', 'error');
    setCmdSaving(true);
    try {
      const body = { trigger: cmdForm.trigger, response: cmdForm.response, embedData: cmdForm.showEmbed ? cmdForm.embedData : null };
      const url = cmdModal.mode === 'edit' ? `/api/utility/commands/${cmdModal.id}` : '/api/utility/commands';
      const method = cmdModal.mode === 'edit' ? 'PATCH' : 'POST';
      const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify(body) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      showToast(`Command ${cmdModal.mode === 'edit' ? 'updated' : 'created'}!`, 'success');
      setCmdModal(null);
      refetchCmds();
    } catch (err) { showToast(`Failed: ${err.message}`, 'error'); }
    finally { setCmdSaving(false); }
  };

  const deleteCmd = async (id) => {
    if (!window.confirm('Delete this command?')) return;
    const r = await fetch(`/api/utility/commands/${id}`, { method: 'DELETE', credentials: 'include' });
    if (r.ok) { showToast('Command deleted', 'success'); refetchCmds(); }
    else showToast('Failed to delete', 'error');
  };

  const saveMonitor = async () => {
    if (!monitorForm.name.trim() || !monitorForm.url.trim()) return showToast('Name and URL are required', 'error');
    setMonitorSaving(true);
    try {
      const r = await fetch('/api/utility/monitors', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify(monitorForm) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      showToast('Monitor added!', 'success');
      setMonitorModal(false);
      setMonitorForm({ name: '', url: '', notifyChannel: '' });
      refetchMonitors();
    } catch (err) { showToast(`Failed: ${err.message}`, 'error'); }
    finally { setMonitorSaving(false); }
  };

  const deleteMonitor = async (id) => {
    if (!window.confirm('Remove this monitor?')) return;
    await fetch(`/api/utility/monitors/${id}`, { method: 'DELETE', credentials: 'include' });
    showToast('Monitor removed', 'success');
    refetchMonitors();
  };

  const checkMonitor = async (id) => {
    setCheckingId(id);
    try {
      const r = await fetch(`/api/utility/monitors/${id}/check`, { method: 'POST', credentials: 'include' });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      showToast(`Status: ${data.status}`, data.status === 'online' ? 'success' : 'error');
      refetchMonitors();
    } catch (err) { showToast(`Check failed: ${err.message}`, 'error'); }
    finally { setCheckingId(null); }
  };

  const deleteReminder = async (id) => {
    await fetch(`/api/utility/reminders/${id}`, { method: 'DELETE', credentials: 'include' });
    showToast('Reminder deleted', 'success');
    refetchReminders();
  };

  const cmdCols = [
    { key: 'trigger', label: 'Trigger', render: v => <code style={{ background: 'var(--bg-tertiary)', padding: '0.125rem 0.375rem', borderRadius: 'var(--radius-sm)', fontSize: '0.8125rem' }}>!{v}</code> },
    { key: 'response', label: 'Response', render: v => <span style={{ maxWidth: '250px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>{v}</span> },
    { key: 'embedData', label: 'Embed', render: v => v ? <span className="badge badge-info">✅ Yes</span> : <span className="text-muted">—</span> },
    { key: 'createdAt', label: 'Created', render: v => new Date(v).toLocaleDateString() },
    { key: 'id', label: 'Actions', render: (_, row) => (
      <div style={{ display: 'flex', gap: '0.375rem' }}>
        <button className="btn btn-ghost btn-sm" onClick={() => openEditCmd(row)}>✏️</button>
        <button className="btn btn-danger btn-sm" onClick={() => deleteCmd(row.id)}>🗑️</button>
      </div>
    )},
  ];

  const statusColors = { online: 'var(--success)', offline: 'var(--danger)', degraded: 'var(--warning)', unknown: 'var(--text-muted)' };
  const statusIcons = { online: '🟢', offline: '🔴', degraded: '🟡', unknown: '⚪' };

  const reminderCols = [
    { key: 'userId', label: 'User', render: v => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{v}</span> },
    { key: 'message', label: 'Message', render: v => <span style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>{v}</span> },
    { key: 'channelId', label: 'Channel', render: v => <span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>#{v}</span> },
    { key: 'remindAt', label: 'Due At', render: v => new Date(v).toLocaleString() },
    { key: 'id', label: '', render: (_, r) => <button className="btn btn-danger btn-sm" onClick={() => deleteReminder(r.id)}>🗑️</button> },
  ];

  return (
    <div>
      <div className="page-header"><h1>🔧 Utility Commands</h1><p>Manage custom commands, website monitors, giveaways and reminders.</p></div>

      {/* Custom Commands */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>⚙️ Custom Commands</h2>
          <button className="btn btn-primary btn-sm" onClick={openAddCmd}>+ Add Command</button>
        </div>
        <div className="card-body">
          <Table columns={cmdCols} data={cmdsData || []} loading={cmdsLoading} pagination pageSize={10} emptyMessage="No custom commands yet. Add one above!" />
        </div>
      </div>

      {/* Website Monitors */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header">
          <h2>🌐 Website Monitors</h2>
          <button className="btn btn-primary btn-sm" onClick={() => setMonitorModal(true)}>+ Add Monitor</button>
        </div>
        <div className="card-body">
          {monitorsLoading ? (
            <div style={{ color: 'var(--text-muted)' }}>Loading monitors...</div>
          ) : !monitorsData?.length ? (
            <div style={{ color: 'var(--text-muted)', padding: '1rem 0' }}>No website monitors configured.</div>
          ) : (
            <div style={{ display: 'grid', gap: '0.75rem' }}>
              {monitorsData.map(m => (
                <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: '1rem', padding: '0.875rem 1rem', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                  <span style={{ fontSize: '1.25rem' }}>{statusIcons[m.status] || '⚪'}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{m.name}</div>
                    <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.url}</div>
                    {m.lastChecked && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Last checked: {new Date(m.lastChecked).toLocaleTimeString()}</div>}
                  </div>
                  <span style={{ color: statusColors[m.status], fontWeight: 600, fontSize: '0.875rem', flexShrink: 0 }}>{m.status}</span>
                  <div style={{ display: 'flex', gap: '0.375rem', flexShrink: 0 }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => checkMonitor(m.id)} disabled={checkingId === m.id}>
                      {checkingId === m.id ? '...' : '🔄 Check'}
                    </button>
                    <button className="btn btn-danger btn-sm" onClick={() => deleteMonitor(m.id)}>🗑️</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Active Giveaways */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="card-header"><h2>🎉 Active Giveaways</h2></div>
        <div className="card-body">
          {!giveawaysData?.length ? (
            <div style={{ color: 'var(--text-muted)', padding: '1rem 0' }}>No active giveaways. Use <code>/giveaway start</code> in Discord.</div>
          ) : (
            <div className="table-wrapper">
              <table className="table">
                <thead><tr><th>Prize</th><th>Winners</th><th>Ends At</th><th>Channel</th></tr></thead>
                <tbody>
                  {giveawaysData.map(g => (
                    <tr key={g.id}>
                      <td>{g.prize}</td>
                      <td><span className="badge badge-info">{g.winnersCount}</span></td>
                      <td>{new Date(g.endsAt).toLocaleString()}</td>
                      <td><span style={{ fontFamily: 'monospace', fontSize: '0.8125rem' }}>{g.channelId}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Reminders */}
      <div className="card">
        <div className="card-header"><h2>⏰ Active Reminders</h2></div>
        <div className="card-body">
          <Table columns={reminderCols} data={remindersData || []} loading={remindersLoading} pagination pageSize={10} emptyMessage="No active reminders." />
        </div>
      </div>

      {/* Custom Command Modal */}
      <Modal
        isOpen={!!cmdModal}
        onClose={() => setCmdModal(null)}
        title={cmdModal?.mode === 'edit' ? '✏️ Edit Command' : '➕ Add Custom Command'}
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setCmdModal(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={saveCmd} disabled={cmdSaving}>
              {cmdSaving ? 'Saving...' : 'Save Command'}
            </button>
          </>
        }
      >
        <div style={{ display: 'grid', gap: '1rem' }}>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Trigger (without prefix)</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
              <span style={{ color: 'var(--text-muted)', fontFamily: 'monospace' }}>!</span>
              <input className="form-control" value={cmdForm.trigger} onChange={e => setCmdForm(p => ({ ...p, trigger: e.target.value.toLowerCase().replace(/\s+/g, '') }))} placeholder="mycommand" />
            </div>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Response Text</label>
            <textarea className="form-control" value={cmdForm.response} onChange={e => setCmdForm(p => ({ ...p, response: e.target.value }))} placeholder="Bot reply..." rows={3} />
          </div>
          <Toggle enabled={cmdForm.showEmbed} onChange={v => setCmdForm(p => ({ ...p, showEmbed: v }))} label="Include Embed" />
          {cmdForm.showEmbed && (
            <EmbedBuilder value={cmdForm.embedData || {}} onChange={v => setCmdForm(p => ({ ...p, embedData: v }))} />
          )}
        </div>
      </Modal>

      {/* Monitor Modal */}
      <Modal
        isOpen={monitorModal}
        onClose={() => setMonitorModal(false)}
        title="🌐 Add Website Monitor"
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setMonitorModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={saveMonitor} disabled={monitorSaving}>
              {monitorSaving ? 'Saving...' : 'Add Monitor'}
            </button>
          </>
        }
      >
        <div style={{ display: 'grid', gap: '1rem' }}>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Display Name</label>
            <input className="form-control" value={monitorForm.name} onChange={e => setMonitorForm(p => ({ ...p, name: e.target.value }))} placeholder="My Website" />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">URL</label>
            <input className="form-control" value={monitorForm.url} onChange={e => setMonitorForm(p => ({ ...p, url: e.target.value }))} placeholder="https://example.com" />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label">Alert Channel (optional)</label>
            <ChannelSelector value={monitorForm.notifyChannel} onChange={v => setMonitorForm(p => ({ ...p, notifyChannel: v }))} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
