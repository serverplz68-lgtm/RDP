#!/usr/bin/env node
/**
 * run.js — Zero-dependency process launcher
 * Replaces `concurrently` — works in Termux, Render, Linux, macOS
 * No npm packages needed. Pure Node.js built-ins only.
 *
 * Usage:
 *   node run.js          → server + bot + frontend (dev)
 *   node run.js --prod   → server + bot only (Render / production)
 */

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const ROOT = __dirname;
const isProd = process.argv.includes('--prod');

// ─── ANSI colors ─────────────────────────────────────────────────────────────
const C = {
  reset:   '\x1b[0m',
  cyan:    '\x1b[36m',
  magenta: '\x1b[35m',
  yellow:  '\x1b[33m',
  red:     '\x1b[31m',
  green:   '\x1b[32m',
  gray:    '\x1b[90m',
};

// ─── Services to launch ───────────────────────────────────────────────────────
const services = [
  {
    name: 'SERVER',
    color: C.cyan,
    cmd: 'node',
    args: ['server/index.js'],
    cwd: ROOT,
  },
  {
    name: 'BOT   ',
    color: C.magenta,
    cmd: 'node',
    args: ['bot/index.js'],
    cwd: ROOT,
  },
];

// Add frontend only in dev mode
if (!isProd) {
  // Detect npm/npx path in Termux vs standard Linux
  const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  services.push({
    name: 'CLIENT',
    color: C.yellow,
    cmd: npmCmd,
    args: ['run', 'dev'],
    cwd: path.join(ROOT, 'client'),
  });
}

// ─── Logger ───────────────────────────────────────────────────────────────────
function log(name, color, line) {
  const time = new Date().toLocaleTimeString('en', { hour12: false });
  process.stdout.write(`${C.gray}${time}${C.reset} ${color}[${name}]${C.reset} ${line}\n`);
}

function logErr(name, color, line) {
  process.stderr.write(`${C.gray}${new Date().toLocaleTimeString('en', { hour12: false })}${C.reset} ${color}[${name}]${C.reset} ${C.red}${line}${C.reset}\n`);
}

// ─── Banner ───────────────────────────────────────────────────────────────────
console.log(`\n${C.cyan}╔══════════════════════════════════════╗`);
console.log(`║     Discord Bot Panel Launcher       ║`);
console.log(`║     Mode: ${isProd ? 'PRODUCTION (server+bot)' : 'DEV (server+bot+ui)'}  ║`);
console.log(`╚══════════════════════════════════════╝${C.reset}\n`);

// ─── Spawn each service ───────────────────────────────────────────────────────
const procs = [];

services.forEach(({ name, color, cmd, args, cwd }) => {
  log(name, color, `Starting → ${cmd} ${args.join(' ')}`);

  const proc = spawn(cmd, args, {
    cwd,
    env: { ...process.env },
    stdio: 'pipe',
    shell: false,
  });

  procs.push({ name, color, proc });

  proc.stdout.on('data', (data) => {
    String(data).trimEnd().split('\n').forEach(line => log(name, color, line));
  });

  proc.stderr.on('data', (data) => {
    String(data).trimEnd().split('\n').forEach(line => logErr(name, color, line));
  });

  proc.on('close', (code) => {
    log(name, color, `Process exited with code ${code}`);
    // If any critical process dies, kill all others and exit
    if (code !== 0 && code !== null) {
      console.error(`\n${C.red}[FATAL] ${name.trim()} crashed (exit ${code}). Shutting down all services.${C.reset}\n`);
      killAll();
      process.exit(1);
    }
  });

  proc.on('error', (err) => {
    logErr(name, color, `Failed to start: ${err.message}`);
    if (err.code === 'ENOENT') {
      logErr(name, color, `Command not found: ${cmd} — is it installed?`);
    }
    killAll();
    process.exit(1);
  });
});

// ─── Graceful shutdown ────────────────────────────────────────────────────────
function killAll() {
  procs.forEach(({ name, color, proc }) => {
    if (!proc.killed) {
      log(name, color, 'Stopping...');
      proc.kill('SIGTERM');
    }
  });
}

process.on('SIGINT',  () => { console.log(`\n${C.yellow}Caught SIGINT — shutting down...${C.reset}`); killAll(); process.exit(0); });
process.on('SIGTERM', () => { console.log(`\n${C.yellow}Caught SIGTERM — shutting down...${C.reset}`); killAll(); process.exit(0); });

console.log(`${C.green}All services starting. Press Ctrl+C to stop.${C.reset}\n`);
