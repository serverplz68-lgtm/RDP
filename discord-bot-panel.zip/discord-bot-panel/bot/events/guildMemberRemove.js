const { EmbedBuilder } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member, client, prisma) {
    const guildId = member.guild.id;
    const cache = client.configCache.get(guildId);
    if (!cache) return;

    const { community } = cache;

    if (community?.goodbyeEnabled && community?.goodbyeChannelId) {
      const channel = member.guild.channels.cache.get(community.goodbyeChannelId);
      if (!channel) return;

      try {
        const msg = (community.goodbyeMessage || 'Goodbye {user}, we hope to see you again!')
          .replace('{user}', member.user.username)
          .replace('{server}', member.guild.name)
          .replace('{count}', member.guild.memberCount.toString());

        const embed = new EmbedBuilder()
          .setTitle('👋 Farewell')
          .setDescription(msg)
          .setColor(0xef4444)
          .setThumbnail(member.user.displayAvatarURL())
          .setTimestamp();

        await channel.send({ embeds: [embed] });
      } catch (err) {
        logger.error('Goodbye message error:', err.message);
      }
    }

    // Record member snapshot
    await prisma.memberSnapshot.create({
      data: { guildId, memberCount: member.guild.memberCount },
    }).catch(() => {});
  },
};
