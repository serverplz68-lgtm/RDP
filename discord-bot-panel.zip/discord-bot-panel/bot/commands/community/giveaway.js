const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Manage giveaways')
    .addSubcommand(s =>
      s.setName('start')
        .setDescription('Start a giveaway')
        .addStringOption(o => o.setName('prize').setDescription('Prize').setRequired(true))
        .addStringOption(o => o.setName('duration').setDescription('Duration e.g. 1h, 30m, 1d').setRequired(true))
        .addIntegerOption(o => o.setName('winners').setDescription('Number of winners').setMinValue(1).setMaxValue(20).setRequired(false))
        .addRoleOption(o => o.setName('required_role').setDescription('Required role to enter').setRequired(false))
        .addChannelOption(o => o.setName('channel').setDescription('Channel for giveaway').setRequired(false))
    )
    .addSubcommand(s =>
      s.setName('end')
        .setDescription('End a giveaway early')
        .addStringOption(o => o.setName('message_id').setDescription('Giveaway message ID').setRequired(true))
    )
    .addSubcommand(s =>
      s.setName('reroll')
        .setDescription('Reroll giveaway winners')
        .addStringOption(o => o.setName('giveaway_id').setDescription('Giveaway DB ID').setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();

    if (sub === 'start') {
      const prize = interaction.options.getString('prize');
      const durationStr = interaction.options.getString('duration');
      const winnersCount = interaction.options.getInteger('winners') ?? 1;
      const requiredRole = interaction.options.getRole('required_role');
      const channel = interaction.options.getChannel('channel') || interaction.channel;

      const ms = parseDuration(durationStr);
      if (!ms) return interaction.editReply({ embeds: [errorEmbed('Invalid Duration', 'Use formats like `1h`, `30m`, `2d`.')] });

      const endsAt = new Date(Date.now() + ms);

      const embed = new EmbedBuilder()
        .setTitle('🎉 GIVEAWAY')
        .setDescription(`**Prize:** ${prize}\n**Winners:** ${winnersCount}\n**Ends:** <t:${Math.floor(endsAt.getTime() / 1000)}:R>${requiredRole ? `\n**Required Role:** ${requiredRole}` : ''}`)
        .setColor(0x3b82f6)
        .setFooter({ text: `Hosted by ${interaction.user.username}` })
        .setTimestamp(endsAt);

      const giveaway = await prisma.giveaway.create({
        data: {
          guildId: interaction.guildId,
          channelId: channel.id,
          prize,
          winnersCount,
          requiredRole: requiredRole?.id || null,
          endsAt,
        },
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`giveaway_enter:${giveaway.id}`)
          .setLabel('🎉 Enter Giveaway')
          .setStyle(ButtonStyle.Primary)
      );

      const msg = await channel.send({ embeds: [embed], components: [row] });
      await prisma.giveaway.update({ where: { id: giveaway.id }, data: { messageId: msg.id } });

      await interaction.editReply({ embeds: [successEmbed('Giveaway Started', `Giveaway for **${prize}** started in ${channel}!`)] });
    }

    if (sub === 'end') {
      const messageId = interaction.options.getString('message_id');
      const giveaway = await prisma.giveaway.findFirst({ where: { messageId, guildId: interaction.guildId } });
      if (!giveaway) return interaction.editReply({ embeds: [errorEmbed('Not Found', 'Giveaway not found.')] });

      await prisma.giveaway.update({ where: { id: giveaway.id }, data: { endsAt: new Date(), ended: false } });
      return interaction.editReply({ embeds: [successEmbed('Giveaway Ending', 'Giveaway will end within the next check cycle (up to 1 minute).')] });
    }

    if (sub === 'reroll') {
      const giveawayId = interaction.options.getString('giveaway_id');
      const giveaway = await prisma.giveaway.findUnique({ where: { id: giveawayId } });
      if (!giveaway || !giveaway.ended) return interaction.editReply({ embeds: [errorEmbed('Not Found', 'Ended giveaway not found.')] });

      const channel = interaction.guild.channels.cache.get(giveaway.channelId);
      if (!channel) return interaction.editReply({ embeds: [errorEmbed('Channel Not Found', 'Giveaway channel no longer exists.')] });

      await interaction.guild.members.fetch();
      const eligible = interaction.guild.members.cache.filter(m => !m.user.bot);
      const pool = [...eligible.values()];
      const newWinners = [];

      const count = Math.min(giveaway.winnersCount, pool.length);
      for (let i = 0; i < count; i++) {
        const idx = Math.floor(Math.random() * pool.length);
        newWinners.push(pool[idx]);
        pool.splice(idx, 1);
      }

      const mentions = newWinners.map(m => `<@${m.id}>`).join(', ');
      await channel.send({ content: `🎉 **Giveaway Reroll!**\nNew winner(s) for **${giveaway.prize}**: ${mentions}` });

      await interaction.editReply({ embeds: [successEmbed('Rerolled', `New winner(s): ${mentions}`)] });
    }
  },
};

function parseDuration(str) {
  const match = str.match(/^(\d+)(s|m|h|d|w)$/);
  if (!match) return null;
  const [, num, unit] = match;
  const map = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000 };
  return parseInt(num) * map[unit];
}
