const logger = require('./logger');

// In-memory snapshots for destructive action reversion
const snapshots = {
  channels: new Map(),   // channelId -> channel data before deletion
  roles: new Map(),      // roleId -> role data before deletion
  bans: new Map(),       // guildId -> Set of recently banned user IDs
};

/**
 * Save a channel snapshot before deletion
 */
function snapshotChannel(channel) {
  snapshots.channels.set(channel.id, {
    id: channel.id,
    name: channel.name,
    type: channel.type,
    parentId: channel.parentId,
    position: channel.position,
    permissionOverwrites: channel.permissionOverwrites.cache.map(po => ({
      id: po.id,
      type: po.type,
      allow: po.allow.bitfield.toString(),
      deny: po.deny.bitfield.toString(),
    })),
    topic: channel.topic,
    nsfw: channel.nsfw,
    rateLimitPerUser: channel.rateLimitPerUser,
    deletedAt: Date.now(),
  });

  // Auto-cleanup after 5 minutes
  setTimeout(() => snapshots.channels.delete(channel.id), 5 * 60 * 1000);
}

/**
 * Save a role snapshot before deletion
 */
function snapshotRole(role) {
  snapshots.roles.set(role.id, {
    id: role.id,
    name: role.name,
    color: role.color,
    hoist: role.hoist,
    position: role.position,
    permissions: role.permissions.bitfield.toString(),
    mentionable: role.mentionable,
    deletedAt: Date.now(),
  });

  setTimeout(() => snapshots.roles.delete(role.id), 5 * 60 * 1000);
}

/**
 * Track a ban for potential reversion
 */
function trackBan(guildId, userId) {
  if (!snapshots.bans.has(guildId)) {
    snapshots.bans.set(guildId, new Set());
  }
  snapshots.bans.get(guildId).add(userId);
}

/**
 * Revert recent destructive actions caused by a specific user
 * Called when anti-nuke threshold is exceeded
 */
async function revertActions(guild, perpetratorId) {
  const reverted = [];

  try {
    // Restore deleted channels
    for (const [channelId, snap] of snapshots.channels.entries()) {
      // Check if this channel was recently deleted (within last 60 seconds)
      if (Date.now() - snap.deletedAt < 60000) {
        try {
          const restored = await guild.channels.create({
            name: snap.name,
            type: snap.type,
            parent: snap.parentId,
            position: snap.position,
            topic: snap.topic,
            nsfw: snap.nsfw,
            rateLimitPerUser: snap.rateLimitPerUser,
          });
          reverted.push(`Restored channel #${snap.name}`);
          snapshots.channels.delete(channelId);
        } catch (err) {
          logger.error(`Failed to restore channel ${snap.name}:`, err.message);
        }
      }
    }

    // Restore deleted roles
    for (const [roleId, snap] of snapshots.roles.entries()) {
      if (Date.now() - snap.deletedAt < 60000) {
        try {
          await guild.roles.create({
            name: snap.name,
            color: snap.color,
            hoist: snap.hoist,
            permissions: BigInt(snap.permissions),
            mentionable: snap.mentionable,
          });
          reverted.push(`Restored role @${snap.name}`);
          snapshots.roles.delete(roleId);
        } catch (err) {
          logger.error(`Failed to restore role ${snap.name}:`, err.message);
        }
      }
    }

    // Unban recently banned members in the guild
    const guildBans = snapshots.bans.get(guild.id);
    if (guildBans && guildBans.size > 0) {
      for (const userId of guildBans) {
        try {
          await guild.members.unban(userId, `Anti-nuke auto-revert: ban by ${perpetratorId} reversed`);
          reverted.push(`Unbanned user ${userId}`);
        } catch (err) {
          logger.error(`Failed to unban ${userId}:`, err.message);
        }
      }
      snapshots.bans.delete(guild.id);
    }

  } catch (err) {
    logger.error('Error during revertActions:', err);
  }

  return reverted;
}

module.exports = { snapshotChannel, snapshotRole, trackBan, revertActions };
