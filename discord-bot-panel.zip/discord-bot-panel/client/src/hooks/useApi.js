import { useState, useEffect, useCallback } from 'react';
import { showToast } from '../components/Toast.jsx';

/**
 * Generic data fetching hook
 */
export function useApi(url, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refetch = useCallback(() => {
    if (!url) return;
    setLoading(true);
    fetch(url, { credentials: 'include' })
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(d => { setData(d); setError(null); })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [url, ...deps]); // eslint-disable-line

  useEffect(() => { refetch(); }, [refetch]);

  return { data, loading, error, refetch, setData };
}

/**
 * Save state manager for config forms
 */
export function useSave(url, method = 'PATCH') {
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const save = useCallback(async (body) => {
    setSaving(true);
    setSaved(false);
    try {
      const r = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        const err = await r.json().catch(() => ({}));
        throw new Error(err.error || `HTTP ${r.status}`);
      }
      const data = await r.json();
      setSaved(true);
      showToast('Changes saved!', 'success');
      setTimeout(() => setSaved(false), 2500);
      return data;
    } catch (err) {
      showToast(`Failed to save: ${err.message}`, 'error');
      throw err;
    } finally {
      setSaving(false);
    }
  }, [url, method]);

  return { save, saving, saved };
}
