const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { emitDMLog } = require('../../utils/socketEmitter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dm')
    .setDescription('Send a DM to a specific user')
    .addUserOption(o => o.setName('user').setDescription('User to DM').setRequired(true))
    .addStringOption(o => o.setName('message').setDescription('Message content').setRequired(true))
    .addStringOption(o => o.setName('embed_title').setDescription('Embed title (optional)'))
    .addStringOption(o => o.setName('embed_color').setDescription('Embed hex color e.g. #3b82f6'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });

    const target = interaction.options.getUser('user');
    const message = interaction.options.getString('message');
    const embedTitle = interaction.options.getString('embed_title');
    const embedColor = interaction.options.getString('embed_color');

    try {
      const payload = { content: message };

      if (embedTitle) {
        const embed = new EmbedBuilder()
          .setTitle(embedTitle)
          .setDescription(message)
          .setColor(embedColor ? parseInt(embedColor.replace('#', ''), 16) : 0x3b82f6)
          .setFooter({ text: `Sent from ${interaction.guild.name}` })
          .setTimestamp();
        payload.embeds = [embed];
        payload.content = undefined;
      }

      await target.send(payload);

      await prisma.dMLog.create({
        data: {
          guildId: interaction.guildId,
          senderId: interaction.user.id,
          targetType: 'user',
          targetId: target.id,
          content: message,
          sentCount: 1,
          failedCount: 0,
        },
      });

      emitDMLog({ guildId: interaction.guildId, targetType: 'user', targetId: target.id, content: message, sentCount: 1, failedCount: 0 });

      await interaction.editReply({ embeds: [successEmbed('DM Sent', `Message delivered to **${target.tag}**.`)] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('DM Failed', `Could not DM ${target.tag}: ${err.message}`)] });
    }
  },
};
