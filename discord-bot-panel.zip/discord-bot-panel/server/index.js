require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const session = require('express-session');
const passport = require('passport');
const { PrismaClient } = require('@prisma/client');
const ConnectPgSimple = require('connect-pg-simple');

const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const securityRoutes = require('./routes/security');
const moderationRoutes = require('./routes/moderation');
const dmRoutes = require('./routes/dm');
const ticketsRoutes = require('./routes/tickets');
const communityRoutes = require('./routes/community');
const utilityRoutes = require('./routes/utility');
const rolesRoutes = require('./routes/roles');
const infoRoutes = require('./routes/info');

const { setupPassport } = require('./routes/auth');
const socketHandlers = require('./socket/handlers');
const rateLimiter = require('./middleware/rateLimiter');

const prisma = new PrismaClient();
const app = express();
const httpServer = http.createServer(app);

// ─── Socket.io ──────────────────────────────────────────────────────────────
const io = new Server(httpServer, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:5173',
    credentials: true,
  },
});

global.io = io;
global.botSocket = null;

// ─── Middleware ──────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true,
}));

app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── Session ──────────────────────────────────────────────────────────────
const PgSession = ConnectPgSimple(session);

app.use(session({
  store: new PgSession({
    conString: process.env.DATABASE_URL,
    tableName: 'Session',
    createTableIfMissing: false,
  }),
  secret: process.env.SESSION_SECRET || 'change_this_in_production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  },
}));

// ─── Passport ────────────────────────────────────────────────────────────────
setupPassport(passport);
app.use(passport.initialize());
app.use(passport.session());

// ─── Rate Limiting ────────────────────────────────────────────────────────
app.use('/api/', rateLimiter.global);

// ─── Routes ──────────────────────────────────────────────────────────────
app.use('/auth', authRoutes(passport));
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/security', securityRoutes);
app.use('/api/moderation', moderationRoutes);
app.use('/api/dm', dmRoutes);
app.use('/api/tickets', ticketsRoutes);
app.use('/api/community', communityRoutes);
app.use('/api/utility', utilityRoutes);
app.use('/api/roles', rolesRoutes);
app.use('/api/info', infoRoutes);

// ─── Health Check ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

// ─── Socket.io Handlers ───────────────────────────────────────────────────
socketHandlers(io, prisma);

// ─── Start ────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`\x1b[32m[SERVER]\x1b[0m Running on http://localhost:${PORT}`);
  console.log(`\x1b[32m[SERVER]\x1b[0m Dashboard: ${process.env.CLIENT_URL || 'http://localhost:5173'}`);
});

module.exports = { app, io, prisma };
