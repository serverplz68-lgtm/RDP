import React from 'react';
import { useApi } from '../hooks/useApi.js';
import { useSocket } from '../context/SocketContext.jsx';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

function InfoRow({ label, value }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.625rem 0', borderBottom: '1px solid var(--border-color)' }}>
      <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{label}</span>
      <span style={{ color: 'var(--text-primary)', fontWeight: 500, fontSize: '0.875rem', textAlign: 'right', maxWidth: '60%', wordBreak: 'break-word' }}>{value ?? '—'}</span>
    </div>
  );
}

function formatUptime(seconds) {
  if (!seconds) return '—';
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
}

const VERIFICATION_LEVELS = ['None', 'Low', 'Medium', 'High', 'Very High'];
const BOOST_TIERS = ['None', 'Tier 1', 'Tier 2', 'Tier 3'];

export default function Information() {
  const { data: guildData, loading: guildLoading } = useApi('/api/info/guild');
  const { data: snapshotData } = useApi('/api/info/member-snapshots?days=30');
  const { latestStats, perfData } = useSocket();

  const latestPerf = perfData[perfData.length - 1];

  const chartData = (snapshotData || []).map(s => ({
    date: new Date(s.recordedAt).toLocaleDateString([], { month: 'short', day: 'numeric' }),
    members: s.memberCount,
  }));

  const iconUrl = guildData?.icon
    ? `https://cdn.discordapp.com/icons/${guildData.id}/${guildData.icon}.png?size=128`
    : null;

  return (
    <div>
      <div className="page-header"><h1>ℹ️ Information</h1><p>View server and bot statistics.</p></div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.5rem', marginBottom: '1.5rem' }}>
        {/* Server Info */}
        <div className="card">
          <div className="card-header"><h2>🏠 Server Information</h2></div>
          <div className="card-body">
            {guildLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.625rem 0', borderBottom: '1px solid var(--border-color)' }}>
                  <div className="skeleton" style={{ width: '35%', height: '16px' }} />
                  <div className="skeleton" style={{ width: '45%', height: '16px' }} />
                </div>
              ))
            ) : (
              <>
                {iconUrl && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                    <img src={iconUrl} alt="Guild icon" style={{ width: '56px', height: '56px', borderRadius: 'var(--radius-md)', objectFit: 'cover' }} />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '1.0625rem' }}>{guildData?.name}</div>
                      <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{guildData?.id}</div>
                    </div>
                  </div>
                )}
                <InfoRow label="Owner ID" value={guildData?.owner_id} />
                <InfoRow label="Created" value={guildData?.id ? new Date((BigInt(guildData.id) >> 22n) + 1420070400000n).toLocaleDateString() : '—'} />
                <InfoRow label="Members" value={guildData?.approximate_member_count?.toLocaleString()} />
                <InfoRow label="Channels" value={guildData?.approximate_channel_count ?? '—'} />
                <InfoRow label="Roles" value={guildData?.roles?.length} />
                <InfoRow label="Boost Level" value={BOOST_TIERS[guildData?.premium_tier ?? 0]} />
                <InfoRow label="Boosts" value={guildData?.premium_subscription_count ?? 0} />
                <InfoRow label="Verification" value={VERIFICATION_LEVELS[guildData?.verification_level ?? 0]} />
                {guildData?.features?.length > 0 && (
                  <div style={{ paddingTop: '0.75rem' }}>
                    <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginBottom: '0.375rem' }}>Features</div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem' }}>
                      {guildData.features.map(f => (
                        <span key={f} style={{ fontSize: '0.75rem', padding: '0.125rem 0.5rem', background: 'var(--bg-tertiary)', borderRadius: '9999px', color: 'var(--text-secondary)' }}>{f}</span>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Bot Stats */}
        <div className="card">
          <div className="card-header"><h2>🤖 Bot Statistics</h2></div>
          <div className="card-body">
            <InfoRow label="WebSocket Ping" value={latestStats?.ping != null ? `${latestStats.ping}ms` : '—'} />
            <InfoRow label="Uptime" value={formatUptime(latestStats?.uptime)} />
            <InfoRow label="Memory Usage" value={latestPerf?.memoryMB != null ? `${latestPerf.memoryMB} MB` : '—'} />
            <InfoRow label="CPU Usage" value={latestPerf?.cpuPercent != null ? `${latestPerf.cpuPercent}%` : '—'} />
            <InfoRow label="Servers" value={latestStats?.guildCount} />
            <InfoRow label="Users Cached" value={latestStats?.userCount?.toLocaleString()} />
            <InfoRow label="Node.js" value={typeof process !== 'undefined' ? process.version : 'N/A'} />
            <InfoRow label="Status" value={latestStats ? (latestStats.ping < 100 ? '🟢 Excellent' : latestStats.ping < 300 ? '🟡 Good' : '🔴 Degraded') : '⚫ Offline'} />
          </div>
        </div>
      </div>

      {/* Member Count Chart */}
      <div className="card">
        <div className="card-header"><h2>📈 Member Count (Last 30 Days)</h2></div>
        <div className="card-body">
          {chartData.length < 2 ? (
            <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
              Not enough data yet. Member count is recorded as members join and leave.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                <XAxis dataKey="date" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', color: 'var(--text-primary)' }}
                  labelStyle={{ color: 'var(--text-muted)' }}
                />
                <Line type="monotone" dataKey="members" stroke="var(--primary-500)" strokeWidth={2} dot={false} name="Members" />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
