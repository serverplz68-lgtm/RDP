import React, { Component } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { SocketProvider } from './context/SocketContext.jsx';

import Sidebar from './components/Sidebar.jsx';
import Toast from './components/Toast.jsx';

import Login from './pages/Login.jsx';
import Unauthorized from './pages/Unauthorized.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Security from './pages/Security.jsx';
import Moderation from './pages/Moderation.jsx';
import DMSystem from './pages/DMSystem.jsx';
import Tickets from './pages/Tickets.jsx';
import Community from './pages/Community.jsx';
import UtilityCommands from './pages/UtilityCommands.jsx';
import Information from './pages/Information.jsx';
import RoleManagement from './pages/RoleManagement.jsx';

// ─── Error Boundary ───────────────────────────────────────────────────────
class ErrorBoundary extends Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: '2rem' }}>
          <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
            <div className="card-header">
              <h2>⚠️ Something went wrong</h2>
            </div>
            <div className="card-body">
              <p style={{ color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                An unexpected error occurred in this section.
              </p>
              <pre style={{ fontSize: '0.8125rem', color: 'var(--danger)', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                {this.state.error?.message}
              </pre>
              <button className="btn btn-primary mt-4" onClick={() => this.setState({ hasError: false, error: null })}>
                Try Again
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ─── Protected Layout ─────────────────────────────────────────────────────
function ProtectedLayout() {
  const { user, isAdmin, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>🤖</div>
          <p style={{ color: 'var(--text-secondary)' }}>Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;
  if (!isAdmin) return <Navigate to="/unauthorized" replace />;

  return (
    <SocketProvider>
      <div className="app-layout">
        <Sidebar />
        <main className="main-content">
          <ErrorBoundary>
            <Routes>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/security" element={<Security />} />
              <Route path="/moderation" element={<Moderation />} />
              <Route path="/dm" element={<DMSystem />} />
              <Route path="/tickets" element={<Tickets />} />
              <Route path="/community" element={<Community />} />
              <Route path="/utility" element={<UtilityCommands />} />
              <Route path="/information" element={<Information />} />
              <Route path="/roles" element={<RoleManagement />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </ErrorBoundary>
        </main>
        <Toast />
      </div>
    </SocketProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/unauthorized" element={<Unauthorized />} />
          <Route path="/*" element={<ProtectedLayout />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
