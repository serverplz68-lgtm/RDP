const { routerRoles } = require('./roles_info');
module.exports = routerRoles;
