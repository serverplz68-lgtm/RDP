const { SlashCommandBuilder } = require('discord.js');
const { createEmbed, errorEmbed } = require('../../utils/embed');
const axios = require('axios');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('currency')
    .setDescription('Convert between currencies')
    .addNumberOption(o => o.setName('amount').setDescription('Amount to convert').setRequired(true))
    .addStringOption(o => o.setName('from').setDescription('Source currency (e.g. USD)').setRequired(true))
    .addStringOption(o => o.setName('to').setDescription('Target currency (e.g. EUR)').setRequired(true)),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const amount = interaction.options.getNumber('amount');
    const from = interaction.options.getString('from').toUpperCase();
    const to = interaction.options.getString('to').toUpperCase();

    try {
      // ExchangeRate-API free tier
      const url = config.exchangeRateKey
        ? `https://v6.exchangerate-api.com/v6/${config.exchangeRateKey}/pair/${from}/${to}/${amount}`
        : `https://open.er-api.com/v6/latest/${from}`;

      const { data } = await axios.get(url);

      let rate, converted;
      if (config.exchangeRateKey) {
        rate = data.conversion_rate;
        converted = data.conversion_result;
      } else {
        rate = data.rates?.[to];
        if (!rate) throw new Error(`Currency ${to} not found`);
        converted = amount * rate;
      }

      const embed = createEmbed({
        title: '💱 Currency Conversion',
        fields: [
          { name: 'From', value: `**${amount.toLocaleString()} ${from}**`, inline: true },
          { name: 'To', value: `**${converted.toFixed(2).toLocaleString()} ${to}**`, inline: true },
          { name: 'Rate', value: `1 ${from} = ${rate.toFixed(6)} ${to}`, inline: false },
        ],
        color: 0x10b981,
        footer: 'Rates may be slightly delayed',
        timestamp: true,
      });

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Conversion Failed', `Could not convert ${from} → ${to}. Check the currency codes.`)] });
    }
  },
};
