const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roleinfo')
    .setDescription('Get info about a role')
    .addRoleOption(o => o.setName('role').setDescription('The role').setRequired(true)),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const role = interaction.options.getRole('role');

    const embed = new EmbedBuilder()
      .setTitle(`@${role.name}`)
      .setColor(role.color || 0x3b82f6)
      .addFields(
        { name: '🆔 ID', value: role.id, inline: true },
        { name: '🎨 Color', value: role.hexColor, inline: true },
        { name: '📅 Created', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '👥 Members', value: role.members.size.toString(), inline: true },
        { name: '📌 Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
        { name: '💬 Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
        { name: '🤖 Managed', value: role.managed ? 'Yes' : 'No', inline: true },
        { name: '📊 Position', value: role.position.toString(), inline: true },
      )
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};
