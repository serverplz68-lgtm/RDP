const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Get information about the server'),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();
    const guild = interaction.guild;
    await guild.fetch();

    const owner = await guild.fetchOwner();
    const channels = guild.channels.cache;
    const verificationLevels = ['None', 'Low', 'Medium', 'High', 'Very High'];
    const boostTiers = ['None', 'Tier 1', 'Tier 2', 'Tier 3'];

    const embed = new EmbedBuilder()
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
      .setColor(0x3b82f6)
      .addFields(
        { name: '👑 Owner', value: owner.user.tag, inline: true },
        { name: '🆔 ID', value: guild.id, inline: true },
        { name: '📅 Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '👥 Members', value: guild.memberCount.toString(), inline: true },
        { name: '📢 Channels', value: channels.size.toString(), inline: true },
        { name: '🎭 Roles', value: guild.roles.cache.size.toString(), inline: true },
        { name: '💎 Boost Level', value: boostTiers[guild.premiumTier] ?? 'None', inline: true },
        { name: '🚀 Boosts', value: guild.premiumSubscriptionCount?.toString() ?? '0', inline: true },
        { name: '🔒 Verification', value: verificationLevels[guild.verificationLevel], inline: true },
      )
      .setImage(guild.bannerURL({ size: 1024 }) || null)
      .setTimestamp();

    if (guild.features.length > 0) {
      embed.addFields({ name: '✨ Features', value: guild.features.map(f => `\`${f}\``).join(', ') });
    }

    await interaction.editReply({ embeds: [embed] });
  },
};
