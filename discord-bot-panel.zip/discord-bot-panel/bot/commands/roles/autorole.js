const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, createEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autorole')
    .setDescription('Manage auto-roles assigned on member join')
    .addSubcommand(s => s.setName('add').setDescription('Add an auto-role').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove an auto-role').addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List auto-roles'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction, client, prisma) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;

    const current = await prisma.roleConfig.findUnique({ where: { guildId } });
    const autoRoles = current?.autoRoleIds || [];

    if (sub === 'list') {
      const roleMentions = autoRoles.length ? autoRoles.map(id => `<@&${id}>`).join(', ') : 'No auto-roles configured.';
      return interaction.editReply({ embeds: [createEmbed({ title: '🎭 Auto-Roles', description: roleMentions, color: 0x3b82f6 })] });
    }

    const role = interaction.options.getRole('role');
    let updated;

    if (sub === 'add') {
      if (autoRoles.includes(role.id)) return interaction.editReply({ embeds: [errorEmbed('Already Added', 'This role is already an auto-role.')] });
      updated = [...autoRoles, role.id];
    } else {
      updated = autoRoles.filter(id => id !== role.id);
    }

    await prisma.roleConfig.upsert({
      where: { guildId },
      update: { autoRoleIds: updated },
      create: { guildId, autoRoleIds: updated },
    });

    const cfg = await prisma.roleConfig.findUnique({ where: { guildId } });
    const cache = client.configCache.get(guildId) || {};
    client.configCache.set(guildId, { ...cache, roles: cfg });

    await interaction.editReply({ embeds: [successEmbed('Auto-Roles Updated', `${sub === 'add' ? 'Added' : 'Removed'} ${role} ${sub === 'add' ? 'to' : 'from'} auto-roles.`)] });
  },
};
