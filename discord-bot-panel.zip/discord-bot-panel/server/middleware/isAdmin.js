function isAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.status(403).json({ error: 'Forbidden: Administrator access required.' });
}

module.exports = isAdmin;
