const { EmbedBuilder } = require('discord.js');

const Colors = {
  PRIMARY: 0x3b82f6,
  SUCCESS: 0x10b981,
  WARNING: 0xf59e0b,
  DANGER: 0xef4444,
  INFO: 0x3b82f6,
  DEFAULT: 0x334155,
};

/**
 * Creates a standard embed with consistent styling
 */
function createEmbed({ title, description, color = Colors.PRIMARY, fields = [], thumbnail, image, footer, author, timestamp = true } = {}) {
  const embed = new EmbedBuilder()
    .setColor(color)
    .setTimestamp(timestamp ? new Date() : null);

  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (fields.length) embed.addFields(fields);
  if (thumbnail) embed.setThumbnail(thumbnail);
  if (image) embed.setImage(image);
  if (footer) embed.setFooter(typeof footer === 'string' ? { text: footer } : footer);
  if (author) embed.setAuthor(typeof author === 'string' ? { name: author } : author);

  return embed;
}

function successEmbed(title, description) {
  return createEmbed({ title: `✅ ${title}`, description, color: Colors.SUCCESS });
}

function errorEmbed(title, description) {
  return createEmbed({ title: `❌ ${title}`, description, color: Colors.DANGER });
}

function warnEmbed(title, description) {
  return createEmbed({ title: `⚠️ ${title}`, description, color: Colors.WARNING });
}

function infoEmbed(title, description) {
  return createEmbed({ title: `ℹ️ ${title}`, description, color: Colors.INFO });
}

/**
 * Build an embed from a raw embed data object (from DB/dashboard)
 */
function buildFromData(data) {
  if (!data) return null;
  return createEmbed({
    title: data.title,
    description: data.description,
    color: data.color ? parseInt(data.color.replace('#', ''), 16) : Colors.PRIMARY,
    thumbnail: data.thumbnail,
    image: data.image,
    footer: data.footer,
    author: data.author,
    fields: data.fields || [],
  });
}

module.exports = { createEmbed, successEmbed, errorEmbed, warnEmbed, infoEmbed, buildFromData, Colors };
