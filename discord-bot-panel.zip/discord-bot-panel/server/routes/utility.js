const express = require('express');
const { PrismaClient } = require('@prisma/client');
const axios = require('axios');
const isAuthenticated = require('../middleware/isAuthenticated');
const isAdmin = require('../middleware/isAdmin');

const router = express.Router();
const prisma = new PrismaClient();
const GUILD_ID = process.env.DISCORD_GUILD_ID;

router.use(isAuthenticated, isAdmin);

const discordApi = axios.create({
  baseURL: 'https://discord.com/api/v10',
  headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` },
});

// ─── Custom Commands ──────────────────────────────────────────────────────
router.get('/commands', async (req, res) => {
  try {
    const commands = await prisma.customCommand.findMany({ where: { guildId: GUILD_ID }, orderBy: { createdAt: 'desc' } });
    res.json(commands);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/commands', async (req, res) => {
  try {
    const { trigger, response, embedData } = req.body;
    if (!trigger || !response) return res.status(400).json({ error: 'trigger and response are required' });
    const cmd = await prisma.customCommand.create({ data: { guildId: GUILD_ID, trigger: trigger.toLowerCase(), response, embedData } });
    if (global.botSocket) global.botSocket.emit('dashboard:action', { type: 'reload_custom_commands', guildId: GUILD_ID });
    res.json(cmd);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/commands/:id', async (req, res) => {
  try {
    const cmd = await prisma.customCommand.update({ where: { id: req.params.id }, data: req.body });
    if (global.botSocket) global.botSocket.emit('dashboard:action', { type: 'reload_custom_commands', guildId: GUILD_ID });
    res.json(cmd);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/commands/:id', async (req, res) => {
  try {
    await prisma.customCommand.delete({ where: { id: req.params.id } });
    if (global.botSocket) global.botSocket.emit('dashboard:action', { type: 'reload_custom_commands', guildId: GUILD_ID });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Website Monitors ─────────────────────────────────────────────────────
router.get('/monitors', async (req, res) => {
  try {
    const monitors = await prisma.websiteMonitor.findMany({ where: { guildId: GUILD_ID } });
    res.json(monitors);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/monitors', async (req, res) => {
  try {
    const monitor = await prisma.websiteMonitor.create({ data: { guildId: GUILD_ID, ...req.body } });
    res.json(monitor);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/monitors/:id', async (req, res) => {
  try {
    await prisma.websiteMonitor.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/monitors/:id/check', async (req, res) => {
  try {
    const monitor = await prisma.websiteMonitor.findUnique({ where: { id: req.params.id } });
    if (!monitor) return res.status(404).json({ error: 'Monitor not found' });

    let status = 'offline';
    try {
      const start = Date.now();
      const r = await axios.get(monitor.url, { timeout: 10000 });
      const elapsed = Date.now() - start;
      status = r.status >= 200 && r.status < 400 ? (elapsed > 3000 ? 'degraded' : 'online') : 'offline';
    } catch { status = 'offline'; }

    const updated = await prisma.websiteMonitor.update({
      where: { id: req.params.id },
      data: { status, lastChecked: new Date() },
    });

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Giveaways ────────────────────────────────────────────────────────────
router.get('/giveaways', async (req, res) => {
  try {
    const giveaways = await prisma.giveaway.findMany({ where: { guildId: GUILD_ID, ended: false }, orderBy: { endsAt: 'asc' } });
    res.json(giveaways);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Reminders ────────────────────────────────────────────────────────────
router.get('/reminders', async (req, res) => {
  try {
    const reminders = await prisma.reminder.findMany({ where: { guildId: GUILD_ID, sent: false }, orderBy: { remindAt: 'asc' } });
    res.json(reminders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/reminders/:id', async (req, res) => {
  try {
    await prisma.reminder.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
