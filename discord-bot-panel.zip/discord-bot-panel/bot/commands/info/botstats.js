const { SlashCommandBuilder, EmbedBuilder, version: djsVersion } = require('discord.js');

function formatUptime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botstats')
    .setDescription('View bot performance statistics'),

  async execute(interaction, client, prisma) {
    await interaction.deferReply();

    const mem = process.memoryUsage();
    const uptime = process.uptime() * 1000;

    const embed = new EmbedBuilder()
      .setTitle(`📊 ${client.user.username} Statistics`)
      .setThumbnail(client.user.displayAvatarURL())
      .setColor(0x3b82f6)
      .addFields(
        { name: '⚡ WebSocket Ping', value: `${client.ws.ping}ms`, inline: true },
        { name: '⏱️ Uptime', value: formatUptime(uptime), inline: true },
        { name: '🖥️ Memory', value: `${Math.round(mem.heapUsed / 1024 / 1024)} MB / ${Math.round(mem.heapTotal / 1024 / 1024)} MB`, inline: true },
        { name: '🌐 Servers', value: client.guilds.cache.size.toString(), inline: true },
        { name: '👥 Users Cached', value: client.users.cache.size.toString(), inline: true },
        { name: '⚙️ Commands', value: client.commands.size.toString(), inline: true },
        { name: '🟢 Node.js', value: process.version, inline: true },
        { name: '📦 Discord.js', value: `v${djsVersion}`, inline: true },
        { name: '🔀 Channels', value: client.channels.cache.size.toString(), inline: true },
      )
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};
