const { routerInfo } = require('./roles_info');
module.exports = routerInfo;
