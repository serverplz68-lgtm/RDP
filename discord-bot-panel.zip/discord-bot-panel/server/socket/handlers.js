// Performance ring buffer - 30 data points
const perfBuffer = [];
const MAX_PERF_POINTS = 30;

// Activity log - last 20 bot actions
const activityLog = [];
const MAX_ACTIVITY = 20;

function pushPerf(data) {
  perfBuffer.push(data);
  if (perfBuffer.length > MAX_PERF_POINTS) perfBuffer.shift();
}

function pushActivity(data) {
  activityLog.unshift(data);
  if (activityLog.length > MAX_ACTIVITY) activityLog.pop();
}

function getPerfBuffer() { return [...perfBuffer]; }
function getActivityLog() { return [...activityLog]; }

function socketHandlers(io, prisma) {
  io.on('connection', (socket) => {
    const token = socket.handshake.auth?.token;
    const isBotConnection = token === process.env.BOT_SOCKET_SECRET;

    if (isBotConnection) {
      console.log(`\x1b[34m[SOCKET]\x1b[0m Bot connected: ${socket.id}`);
      global.botSocket = socket;

      socket.on('bot:stats', (data) => {
        pushPerf({ ...data, time: new Date().toISOString() });
        socket.broadcast.emit('bot:stats:update', data);
      });

      socket.on('bot:action', (data) => {
        pushActivity(data);
        socket.broadcast.emit('bot:action:new', data);
      });

      socket.on('bot:ticket:create', (data) => { socket.broadcast.emit('ticket:created', data); });
      socket.on('bot:ticket:update', (data) => { socket.broadcast.emit('ticket:updated', data); });
      socket.on('bot:warning:add', (data) => { socket.broadcast.emit('warning:added', data); });
      socket.on('bot:dm:log', (data) => { socket.broadcast.emit('dm:logged', data); });
      socket.on('bot:config:confirmed', (data) => { socket.broadcast.emit(`config:${data.section}:confirmed`, data); });

      socket.on('disconnect', () => {
        console.log('\x1b[33m[SOCKET]\x1b[0m Bot disconnected');
        if (global.botSocket?.id === socket.id) global.botSocket = null;
      });

    } else {
      console.log(`\x1b[36m[SOCKET]\x1b[0m Dashboard client connected: ${socket.id}`);

      // Send snapshots on join
      socket.emit('perf:snapshot', perfBuffer);
      socket.emit('activity:snapshot', activityLog);

      socket.on('dashboard:action', (data) => {
        if (global.botSocket) global.botSocket.emit('dashboard:action', data);
      });

      socket.on('disconnect', () => {
        console.log(`\x1b[36m[SOCKET]\x1b[0m Dashboard client disconnected: ${socket.id}`);
      });
    }
  });
}

module.exports = socketHandlers;
module.exports.getPerfBuffer = getPerfBuffer;
module.exports.getActivityLog = getActivityLog;
