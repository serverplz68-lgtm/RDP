export { Tickets as default } from './CommunityPages.jsx';
